---
description: "Private reusable voice runtime for browser and server applications."
kind: "package-reference"
---

# VoiceMesh Composer

English | [中文](README.zh.md)

## Summary

This private library owns speech recognition and synthesis interfaces/providers, speech pipeline coordination, realtime protocols, lifecycle, transcript assembly, browser audio, and preview playback/cache coordination. The harness voice plugins consume it. The intended package is @voicemesh/composer. This local package is private pending registry ownership and licensing confirmation.

StreamingConversation, exported from /pipeline, combines bounded in-memory context, the shared listener-cue prompt and SpeculativeTurn with an application-supplied model transport. It emits model-generated cues while listening and streams or reuses the final answer. SpeculativeTurn coalesces changed partial transcripts into one active generation. A cue belongs to the turn rather than to one revision of it: interim rewrites, re-punctuation and dropped words never cancel a cue that generation produces, because a filler that arrives a moment late is harmless while discarding it wastes the model call. Only the answer draft requires an exact final-transcript match, and final-response cancellation is forwarded. The consumer owns model requests, tool execution, and quiet playback; drafts never execute application actions. Speech-pipeline preparation is enabled by the backchannel preference and requires interim recognition. Requests can consume additional tokens even when their drafts are discarded.

StreamingConversation requires cueIntent (acknowledgment, encouragement, or silence) for listener playback. prepare(text, speechState) accepts speaking by default; paused must come from observed speech activity. The pipeline reports paused only during its existing hold for an unfinished clause and reports speaking when speech resumes. Encouragement is admitted only while paused. Hosts using paused preparation must supply stopCue to cancel listener audio on resumption. A cue must stay a tiny reactive filler — "Mm-hmm", "I see", "Uh-huh", "Oh no", "Oh really?", "No way" — so validation discards anything empty, the silent token, longer than 24 characters, more than four words, or phrased as a conversational question; a brief reaction question is the only question allowed. Speculation should offer the cue tool alone, so a partial transcript can never trigger a coding dispatch. Repeated acknowledgments within one turn are suppressed; successful final responses reset that turn's repetition record. A cue confirmed at device output is excluded only when a matching STT frame arrives in the same utterance, keeping listener audio out of user transcripts without dropping unrelated overlapping speech. The application owns cue classification. The playground independently classifies free-form cues before returning them to Composer; neutral nonverbal cues skip that extra model request. This adds latency and model usage and does not guarantee semantic relevance.

## Entry points

| Import | Runtime | Responsibilities |
| --- | --- | --- |
| @voicemesh/composer | Browser or Node | STT/TTS interfaces and providers, lifecycle, captions, Live delegation, injected preview cache |
| @voicemesh/composer/pipeline | Browser or Node | PCM input, VAD, recognition finalization, conversation, speech cancellation and state callbacks |
| @voicemesh/composer/browser | Browser | Microphone capture, WebRTC media, realtime controller, PCM playback, preview player |
| @voicemesh/composer/server | Node | Realtime provider translation, authenticated signaling, bounded WebSocket channel, Live sample generation |

Applications supply credentials, conversation/task operations, transcript persistence, UI state, signaling routes, and status feedback. LiveDelegation accepts application task receipts, transcript callbacks, and explicit wording policy. The browser controller receives resolved media settings and an application signaling adapter; no harness URL or session type is embedded in the library.

The harness owns coding tools and prompts in the separate private @dsh-voice/harness-policy package. It also owns credential-service integration, permission enforcement, settings UI, model/voice discovery, local model installation, and session-history projection. CacheStorage is a browser application adapter; the library accepts a storage interface. None of these services is required to import the runtime.

Pipeline and native realtime retain different media capabilities. GPT-Live uses native WebRTC playback without constructing a PCM player. Server consumers can provide PCM media independently of browser capture. Telephone signaling and carrier adapters are not implemented here. The browser status stays connecting until microphone acquisition, WebRTC media, and provider readiness complete; early audio activity cannot mark the session ready.

prepareTranscriptHistory selects the newest complete provider-neutral speech rows within UTF-8 and message limits, then combines adjacent rows from the same speaker with newline separators. Realtime adapters encode those messages as native startup turns; Gemini establishes that context without closing a turn, while the shared channel sends post-setup turns before reporting readiness and omits them during connection replacement. Persisted display rows and application event access remain consumer-owned.

Provider catalogs are available from the server entry point through discoverVoices, listStsModels and listRealtimeTranscriptionModels. Applications supply credentials and cancellation deadlines. Voice catalogs report API or official-documentation provenance and fail when extraction cannot establish a catalog; there is no bundled fallback list.

## Command outcomes

Live thinking, commentary, and instruction appends reserve a bounded pending entry by event ID. `send()` completes after durable recording and socket transmission. `command()` additionally exposes an acceptance promise; consumers must not await that promise inside `owner.receive`, which serializes inbound delivery. Neither completion establishes spoken output or audible playback. Consumers supply fresh command IDs or let the provider generate them.

Acknowledgment tracking is enabled by default. Applications can set `commandAcknowledgments: false` in `StsChannelSettings` to make `send()` and `sendWhen()` transmission-only; `command()` then rejects because acceptance tracking is disabled. This choice does not change the provider adapter's acknowledgment support.

Providers with acknowledgment tracking enabled require `commands.timeoutMs` and `commands.maxPending`. `send()` and `command()` deadlines include queued transmission; expired commands are not sent. `sendWhen()` rechecks eligibility after persistence and reserves acceptance with its deadline only when transmission remains eligible. Missing correlation IDs and mismatched acknowledgment types cannot settle another command. Timeout, disconnect, replacement, and local teardown reject acceptance with an unknown outcome; queue saturation rejects admission. No outcome retries a command or application task. `commandOutcome` receives sanitized acceptance evidence independently of the transmission promise.

Live error events are sanitized before recording and remain recoverable after readiness. Startup errors, malformed envelopes, and failed transports are terminal. The documented protocol does not enumerate fatal error codes; session closure and its reason establish termination independently. Codes may be null and correlation IDs may be absent. Error messages, parameters, and raw error payloads are excluded. Other providers retain their terminal-error default and existing input-transcription exception.

## Graceful shutdown and usage

`standby()` parks an active session on demand: the pipeline loop and the realtime controller release the microphone, the streaming recognizer, and any speech still playing, then publish standby without waiting for the inactivity deadline or for the mode to become idle. The loop stays armed and bound to its session, so the next `start` resumes it with elapsed time preserved. Hosts that offer a manual pause surface it through their own control.

Realtime failures report a stable reason. `createStsController` accepts either fixed failure text or a formatter that receives `{ reason, detail }`: the failing step (socket, socket-closed, start, signaling, media, playback, audio, protocol, renew, channel, connection-lost, caption, or queue) plus bounded transport evidence such as a socket close code, a DOMException name, or the failed renewal step. Local exception text is truncated and provider payloads and credentials are never included.

`finish()` stops new input and requests provider finalization; `close()` aborts immediately. Providers with `closeEvent` require a positive integer `closeTimeoutMs`. The receiver drains until a recorded final event or that deadline. Repeated finish calls share one request and completion. Consumers must keep the primary transport alive while waiting; browser media can suspend capture and local playback independently.

`finalization.seconds` holds the latest cumulative duration, never the sum of updates; null means no observation. Only the provider final event sets `confirmed` and its `reason`, including connection-loss finalization. Socket closure alone leaves usage unconfirmed. The channel records a `session.finalized` summary after callbacks drain. Application task lifetimes remain consumer-owned and are not cancelled by channel closure.

## Delegation context and revisions

LiveDelegation retains the latest delegation while persisted transcript fragments arrive. Transcript fragments from one speaker keep a stable display row across pauses; a completed fragment from the other speaker establishes the next row. Overlapping backchannels do not divide the interrupted speaker's row. Each application commentary append also establishes a new assistant response, so injected task results cannot update an earlier acknowledgment bubble. Consumers supply positive integer `waitMs` and `quietMs`, with quiet no greater than wait. A fresh user fragment followed by the quiet interval permits admission; relevant fragments reset that interval without extending the deadline. The deadline requests clarification if no fresh user text is available. Timing cannot establish semantic completeness or a provider turn boundary. Text alone never requests work, and duplicate delegation IDs never repeat admission. Admission never waits for provider command acknowledgments: a stalled append delays only its own delivery, so newly delegated work is still admitted on time.

A newer delegation replaces an unadmitted request and invalidates older spoken results. Application task states expose `revision` and the `resultRevision` that produced their text. Completed results require matching revisions; stopped work never forwards previous success text. Consumers must recheck the supplied eligibility predicate at transmission, including after persistence, and persist withheld commands. Closing discards waiting context, drains active admission, and leaves application work running.

## Result delivery

Terminal results use the consumer’s factual summary. Appends preserve complete sentences when they fit, then words and graphemes; an oversized grapheme splits only at Unicode code points. A conservative 400-byte UTF-8 content bound stays below the Live append limit. Segmentation preserves the supplied text and does not summarize, remove Markdown, or interpret task success. Each piece rechecks the current task revision and connection lifetime before transmission. A rejected speech append remains retryable without repeating context the provider already accepted. Result delivery distinguishes pending transmission, provider acceptance, and completed playback supported by a fresh native speech interval plus assistant caption text; acceptance alone is not a playback receipt.

## Spoken lines

`LiveSpeech.say(text)` makes the agent speak a given line word for word. Live commentary paraphrases, so with a `SpeechSynthesizer` the line is rendered and played through the application's `AgentAudioOutput` while the model's own audio is held; the model is first told, as unspoken thinking context, that the line is being said for it. Without a synthesizer the line is sent as commentary and may be reworded. `interrupt()` ends the line at once: the output drops unheard audio, the model is released, and `say()` resolves with `interrupted` without waiting on the network. The output receives whole PCM16 samples only. `say()` never rejects; it returns `played`, `interrupted`, or `failed`, and reports failures through `diagnostic`. Synthesizer `stop()` cancels the response reader, because Node's fetch can leave a read pending after an abort once the body has arrived.

## Application context

LiveContext accepts complete factual snapshots with explicit byte, quiet-interval and maximum-wait limits. It retains one active delivery and the latest replacement, coalesces bursts, and skips unchanged text. Consumers can supply the snapshot already seeded at session creation to avoid appending it again. Consumers supply durable delivery and recheck eligibility per chunk; failure is reported without retry. Close cancels pending context and drains active delivery. LiveDelegation.invalidate() suppresses pending admission and obsolete results when the application has already routed external input.

The browser application's optional watchContext subscription starts after media/provider readiness and is disposed when voice closes. Application facts, trust instructions, selection meaning, and typed-message routing remain consumer-owned.

## Validation

Run from this directory:

```sh
npm ci --ignore-scripts
npm run build
npm run check:boundaries
npm run test:consumers
```

The consumer check requires an installed Playwright Chromium browser; VOICE_CHROMIUM can select its executable. It packs the built package and installs it into a temporary project with only declared runtime and explicit test dependencies. TypeScript 5.9 checks every public entry point under NodeNext and bundler resolution with library checking enabled. The independent application backend, browser capture/playback/transcript/preview consumer, and server PCM/delegation consumer run against the installed artifact. Installation requires registry access; temporary files are removed after the check. No harness package or credential is imported. Dependency checks compile browser code without Node types and server code without DOM types, and reject harness imports.

The harness and Playground are independent consumers of the exported package. The harness owns its dependency installation and source-test configuration.

## Scope

The independent server consumer verifies reusable media and application callbacks. Telephone adapters, consumer VoiceMesh integration, and a public compatibility promise are outside this implementation. See [the migration plan](LIBRARY_MIGRATION_PLAN.md) for publication decisions.

For coding agents adapting Composer to an agent harness, see [Integrating VoiceMesh Composer with an agent harness](INTEGRATING_HARNESSES.md). It uses the current DeepSeek Harness adapter as a source-grounded example and marks its unpublished, harness-specific wiring separately.

The browser entry exports SileroVad and createPipelinePlayback from the harness extraction. Pipeline playback shares a persistent PCM device, quiet listener channel, parser-based speech cleanup and device-paced captions. Realtime PCM fades its opening and post-underrun recovery chunks, never continuous chunk boundaries. Applications supply synthesis transport and caption projection; they do not implement audio scheduling.

### Browser audio visualization

`subscribeVoiceAudio(listener)` from `@voicemesh/composer/browser` reports nine waveform amplitudes per direction (`input` and `output`) from live Composer audio sources in the current page. Subscribe while the visualizer is visible and voice is active, and dispose the subscription when hidden, stopped, or parked. Observers do not store audio or change speaker routing. PCM routes tap existing nodes; WebRTC meters use the existing tracks without acquiring another microphone. The last unsubscribe releases analysers, meter-only contexts, and animation-frame polling.

Realtime WebSocket transport recovery shares one attempt across concurrent socket error, close, and send-failure notifications. Composer first uses a provider-issued resumption handle when available. Otherwise, if the provider supports startup history and the owner supplies completed transcript rows, Composer opens a fresh connection and restores that context before queued input resumes. A negotiated WebRTC connection never switches to a standalone WebSocket. Stopping voice cancels pending recovery.

Transport diagnostics report provider close codes, fixed close-reason categories, connection age, socket state, and receipt of Gemini GoAway. Gemini tool responses and client-content messages report transmission after the socket send completes. Diagnostics omit raw provider reasons, payloads, resumption handles, and transcript text.

Gemini interruption immediately marks user speech active, before delivering the cancelled response. The cancelled model turn’s completion does not end that user turn. Queued tool results remain withheld until the user finishes and response/playback conditions permit delivery.

The public Gemini provider selects private function-calling adapters by exact documented model ID. Gemini 3.1 and the known Gemini 2.5 native-audio IDs declare blocking functions; `gemini-3.8-live` declares non-blocking functions. Only a non-blocking session accepts `SILENT` on an individual function result, which updates its context without starting a reply. Both adapters share authentication, audio, transcript, resumption, and tool-result translation. Unknown IDs omit a function behavior and use the provider default.

Automatic standby retains its inactivity deadline while audio blocks parking and checks it again on the lifecycle clock. The realtime controller rearms inactivity when user speech ends, including turns that produce no assistant response.
# Desktop settings integration

The existing Composer package also ships desktop support. Import
`settingsReady`, `dismissSettings` and `SettingsWindowApi` from
`@voicemesh/composer/desktop`. Signal readiness after the settings shell mounts;
no fixed delay or remote catalog fetch is required before revealing the window.
Dismissal allows preview cleanup a bounded interval before closing the process.

Node hosts import `desktopSystemTheme`, `spawnBackground` and
`backgroundProcessOptions` from `@voicemesh/composer/desktop/server`. These detect
the host platform automatically. Background child processes and Windows registry
theme queries use `windowsHide: true` on Windows, preventing repeated console and
taskbar flashes. Mac and Linux keep their platform commands and launch behavior.
Applications resolve explicit user theme preferences before the shared OS lookup.
Use these helpers for desktop background work; arbitrary application-owned child
process calls are not intercepted.

The same npm package includes a native Tauri helper at
`native/settings-window`. Its ready/reveal and focus-loss dismissal behavior is
shared across Windows and macOS. The consuming application supplies the URL,
window position, dimensions, title, and capability scope. See the native helper's
README for builder and single-instance integration. Desktop modules are optional
exports and do not add Node or Tauri dependencies to browser voice consumers.

Run `npm run test:desktop` for platform and cleanup tests. The native focus-state
tests can run independently with `rustc --test native/settings-window/src/window_state.rs`.
