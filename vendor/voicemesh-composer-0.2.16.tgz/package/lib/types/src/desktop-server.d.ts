/** Optional Node desktop integration; never imported by browser voice code. */
export * from './server/desktop.ts';
