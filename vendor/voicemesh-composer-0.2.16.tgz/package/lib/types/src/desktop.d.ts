/** Native popup lifecycle, independent of the consuming application's UI. */
export interface SettingsWindowApi {
    app: {
        exit: (code: number) => Promise<void>;
    };
    window: {
        getCurrentWindow: () => {
            close: () => Promise<void>;
        };
    };
    core?: {
        invoke: (command: string) => Promise<unknown>;
    };
}
/** Call after the settings shell has mounted; native positioning happens first. */
export declare function settingsReady(native: SettingsWindowApi | undefined): Promise<void>;
/** A stalled preview cleanup must not keep a native popup open. */
export declare function dismissSettings(native: SettingsWindowApi | undefined, cleanup: () => Promise<void>, timeoutMs?: number): Promise<void>;
