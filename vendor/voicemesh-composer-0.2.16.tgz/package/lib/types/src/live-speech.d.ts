/**
 * say(): the agent speaks a given text word for word.
 *
 * A Live model cannot speak an exact script: commentary is information the model speaks "paraphrasing
 * the appended text", and for exact wording OpenAI advises to "play a verified recording or rendered clip
 * through your application" (live-conversations). So a line is rendered by a SpeechSynthesizer and played
 * as the agent's audio while the model's own audio is held. The model is first told, as unspoken context,
 * that the line is being said for it, so it does not say its own version.
 *
 * Transport-free: where the audio goes is the application's AgentAudioOutput. Without a synthesizer the
 * model speaks the line as commentary, and may reword it.
 *
 * An interruption ends the line at once: the output drops what has not been heard, the model is released,
 * and say() resolves. Nothing on that path waits on the network.
 */
import type { SpeechSynthesizer } from './providers/speech.ts';
/** Where the agent's audio goes; the application implements it for its transport. */
export interface AgentAudioOutput {
    /**
     * Play one chunk of the line as the agent's audio.
     * @param pcm16 - mono PCM16 little-endian, whole samples.
     * @param sampleRate - the synthesizer's output rate in Hz.
     * @returns completion when the next chunk may be sent (the output's pacing).
     */
    play(pcm16: Uint8Array, sampleRate: number): void | Promise<void>;
    /** Block (true) or release (false) the model's own audio. */
    holdModel(held: boolean): void;
    /** Interrupted: drop line audio that has not been heard. */
    stop(): void;
    /** Completion once everything played so far has been heard. */
    playedOut(): Promise<void>;
}
/** The slice of the realtime channel say() uses: acknowledged session commands. */
export interface LiveSpeechChannel {
    command(event: Readonly<Record<string, unknown>>): {
        transmitted: Promise<void>;
        accepted: Promise<void>;
    };
}
export interface LiveSpeechOptions {
    /** Renders lines word for word; null makes the model speak them as commentary. */
    readonly speech: SpeechSynthesizer | null;
    readonly output: AgentAudioOutput;
    /** Sanitized diagnostics; say() reports failures here rather than throwing. */
    readonly diagnostic?: (message: string, detail?: Readonly<Record<string, unknown>>) => void;
}
/** How a line ended. */
export type LineOutcome = 'played' | 'interrupted' | 'failed';
export declare class LiveSpeech {
    private readonly channel;
    private readonly options;
    private line;
    constructor(channel: LiveSpeechChannel, options: LiveSpeechOptions);
    /** Whether a line is playing and the model's audio is held. */
    get speaking(): boolean;
    /**
     * Speak `text` as the agent. A new line replaces one still playing.
     * @returns how the line ended; never rejects.
     */
    say(text: string): Promise<LineOutcome>;
    /** The listener spoke: end the current line now and release the model. */
    interrupt(): void;
    private commentary;
    private render;
    /** Unspoken context for the model; a failure is reported, and the line goes on. */
    private tell;
}
