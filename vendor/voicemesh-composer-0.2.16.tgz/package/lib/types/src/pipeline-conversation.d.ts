import { type SpokenRequestRoute } from './classification-tool.ts';
/** Host operations and request policy owned by the voice transport. */
export interface PipelineConversationDeps {
    request(body: Record<string, unknown>, signal: AbortSignal): Promise<Response>;
    tool(name: string, args: unknown, callId: string, signal: AbortSignal): Promise<unknown>;
    /** Optional direct route for each completed user turn. Omit it to preserve the existing conversation flow. */
    classify?(utterance: string, context: string, signal: AbortSignal): Promise<SpokenRequestRoute>;
    /** Harness handoff when a coding route was confirmed but the model did not call its dispatch tool. */
    dispatchCodingRequest?(utterance: string, signal: AbortSignal): Promise<unknown>;
    /** The harness supplies its coding policy and the words used for result summaries. */
    system(kind: 'user' | 'coding-result' | 'coding-progress'): string;
    /** OpenAI-compatible function definitions, with harness-owned tool semantics. */
    tools(): {
        type: 'function';
        function: {
            name: string;
            description: string;
            parameters: Record<string, unknown>;
        };
    }[];
    /** A tool that admits a coding request; no other voice tool is treated as a dispatch. */
    dispatchToolName?: string;
    contextTurns(): number;
    toolRounds(): number;
    /** Start tool-free speech at the first complete phrase. Defaults to true. */
    streamFirstPhrase?: boolean;
}
/** One active voice conversation; retained context contains no database history. */
export declare class PipelineConversation {
    private readonly deps;
    private exchanges;
    private speechState;
    private readonly draft;
    private readonly cues;
    constructor(deps: PipelineConversationDeps);
    private onCue;
    /** Prepare without executing tools or recording an exchange.
     * @param text - Current partial transcript.
     * @param cue - Quiet listener playback.
     */
    prepare(text: string, cue: (text: string, started: () => void) => Promise<void>, speechState?: 'speaking' | 'paused'): void;
    /** Stop mid-speech cues while retaining a candidate for final recognition. */
    finishPreparation(): void;
    /** Discard drafts after voice stops or conversation context changes. */
    cancelPreparation(): void;
    private tools;
    private system;
    /** Generate speech and execute complete tool calls; coding results cannot invoke tools. */
    run(text: string, kind: 'user' | 'coding-result' | 'coding-progress', emit: (text: string) => void, signal: AbortSignal, requestEnd?: () => void, afterSpeech?: (handoff: () => Promise<void>) => void): Promise<string>;
}
