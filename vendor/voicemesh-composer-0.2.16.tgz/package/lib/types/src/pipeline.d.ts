/** PCM speech pipeline with application-owned recognition, conversation, synthesis, and state projection. */
import { createVoiceLifecycle } from './voice-lifecycle.ts';
import { type Vad } from './vad.ts';
import type { VoicePhase, VoiceLifecycleSink } from './voice-lifecycle.ts';
/** Application projection required by the speech pipeline. */
export interface VoiceRuntimeStore extends VoiceLifecycleSink {
    getSnapshot(): {
        phase: VoicePhase;
        transcript: string;
        lastReply: string;
    };
    setTranscript(text: string): void;
    setLastReply(text: string): void;
}
/** Spoken when the gatekeeper cannot classify an utterance (a degenerate
 * forward:false with no response) — the voice says it instead of staying silent
 * or forwarding an incomplete clause to the application. */
export declare const CATCH_FALLBACK = "I didn't catch that. Could you say that again?";
/** Whether [text] sounds like an incomplete clause (the speaker paused mid-thought). */
export declare function isIncompleteClause(text: string): boolean;
/** Whether [text] is a non-speech hallucination (markers with no real words). */
export declare function looksLikeNonSpeech(text: string): boolean;
/** A live STT stream: feed chunks, observe partial transcripts, end for the final. */
export interface SttStreamHandle {
    /** Feed one live PCM16 chunk. */
    feed(chunk: Uint8Array): void;
    /** Observe interim transcripts as Deepgram produces them. */
    onPartial(handler: (text: string) => void): void;
    /**
     * Finalize the current turn and resolve with its final transcript. The
     * stream stays open for the next turn (the connection is persistent, so the
     * Deepgram socket is not torn down between utterances).
     */
    end(): Promise<string>;
    /** Abandon the stream. */
    close(): void;
}
/** A live, in-history submission echo for the spoken transcript. */
export interface TranscriptEcho {
    /** Replace the rendered interim text (no-op once committed or abandoned). */
    update(text: string): void;
    /** Commit the final transcript as a queued prompt, retiring the echo. */
    commit(text: string): Promise<void>;
    /** Retire the echo as failed without prompting (empty/abandoned utterance). */
    abandon(): void;
}
/**
 * The gatekeeper's decision for one spoken utterance, matching the Flutter
 * `AckDecision` (`lib/src/voice/ack_router.dart`).
 */
export interface VoiceAckDecision {
    /** Whether the utterance must be handed to the application. */
    forward: boolean;
    /** A short spoken acknowledgment, or null to stay silent. */
    reply: string | null;
    /** A substantive answer drawn from what was previously spoken, or null. */
    answer: string | null;
    /** Whether the user only asked to hear the last answer again. */
    repeatLast: boolean;
    /** Whether the user only asked to hear the last code/tool output again. */
    readBackOutput: boolean;
}
/** The injected host seam the loop drives. */
/** A factual coding-agent update that may be spoken while the linked task remains active. */
export interface VoiceProgressUpdate {
    /** Display-ready text derived from a durable coding-agent event. */
    readonly text: string;
    /** Whether this update still belongs to the active coding task when playback begins. */
    readonly current?: () => boolean;
}
export interface VoiceLoopHost {
    /**
     * Prepare from provisional speech and detector activity; tools and answers remain held.
     * `cueStarted` identifies listener audio that recognition must not render as user speech.
     */
    prepareConversation?(text: string, sessionId: string, speechState?: 'speaking' | 'paused', cueStarted?: (text: string) => void): void;
    /** Stop listener cues while the final transcript is being obtained. */
    finishPreparation?(): void;
    /** Cancel drafts and listener audio on mute, standby, stop, or a new utterance. */
    cancelPreparation?(): void;
    /** Stream conversational speech and execute requested application tools. */
    conversation?(text: string, sessionId: string, kind: 'user' | 'application-result' | 'application-progress', emit: (text: string) => void, signal: AbortSignal, requestEnd?: () => void, afterSpeech?: (handoff: () => Promise<void>) => void): Promise<string>;
    /** Release microphone, playback, and recognition after the spoken goodbye finishes. */
    endConversation?(): void;
    /** Forget the active conversational context when a voice chat ends. */
    resetConversation?(): void;
    /** Consume text while audio plays; a session id enables playback-paced history. Cancellation discards queued synthesis. */
    ttsStream?(texts: AsyncIterable<string>, onStart: () => void, signal: AbortSignal, sessionId?: string): Promise<void>;
    /** Transcribe one PCM16 utterance → transcript text. */
    stt(pcm16: Uint8Array, sessionId: string): Promise<string>;
    /**
     * Start a streaming STT session: feed live PCM16 chunks and receive partial
     * transcripts as they form (words appear while the user speaks), then `end()`
     * for the final transcript. If the stream is unavailable the caller falls back
     * to the one-shot {@link stt}.
     */
    sttStream?(sessionId: string, signal?: AbortSignal): Promise<SttStreamHandle>;
    /**
     * Begin a live, in-history submission echo for the utterance the loop is
     * about to capture, so the interim transcript renders inside the message
     * history as the user speaks. The loop drives {@link TranscriptEcho.update}
     * on each partial and commits at utterance end. Absent → the loop shows
     * interim text only in the dock and submits the transcript at the end.
     */
    openTranscriptEcho?(sessionId: string): Promise<TranscriptEcho | null>;
    /** Persist a conversational exchange without dispatching a application task. */
    recordExchange?(sessionId: string, user: string, assistant: string): Promise<void>;
    /** Submit a transcript to the session (queue = agent follow-up, steer = interrupt). */
    prompt(sessionId: string, text: string, mode: 'queue' | 'steer'): Promise<void>;
    /** Observe completed application results, coding progress, and cancellation; returns a disposer. */
    onReply(sessionId: string, handler: (text: string) => void, onCancelled?: () => void, onProgress?: (update: VoiceProgressUpdate) => void): () => void;
    /** Speak text and retain playback-paced history for the optional session.
     * onStart follows device output and completion waits for playback.
     */
    tts(text: string, onStart?: () => void, sessionId?: string): Promise<void>;
    /** Cut the in-flight TTS playback (barge-in). Absent → TTS is not interruptible. */
    stopTts?(): Promise<void>;
    /** Resume the audio context inside a user gesture (autoplay unlock). */
    unlock(): Promise<void>;
    /** Acquire and unlock microphone and playback resources for activation. */
    startCapture?(): Promise<void>;
    /** Release microphone capture on standby or explicit stop. */
    stopCapture?(): void;
    /** Convert an agent reply into what should be spoken (verbatim or a
     * conversational-LLM digest). Absent → speak the reply verbatim. */
    rewriteReply?(text: string, sessionKey?: string): Promise<string>;
    /** Decide how to handle a decoded utterance (Flutter AckRouter parity):
     * forward to the agent, answer from spoken memory, repeat the last answer, or
     * speak a brief acknowledgment. Absent → the loop forwards every turn and
     * never acknowledges (no gatekeeper). Any error yields the safe forward. */
    decideUtterance?(text: string, sessionKey?: string): Promise<VoiceAckDecision>;
    /** Return the most recent assistant/tool output for the session (read-back),
     * or null when none exists. Read-back replays the agent's stored output from
     * the session instead of forwarding, so the agent never redoes the work
     * (Flutter `DshAdapter.lastCodeOutput` parity). Absent → read-back falls
     * through to the safe forward. */
    readBackLastOutput?(sessionId: string): Promise<string | null>;
    /** The most recent SPOKEN value for a session (post-rewrite), or '' when
     * nothing has been spoken yet. "Repeat that" replays this value verbatim
     * (Flutter `spoken.latest` parity) — it is the durable spoken memory, not the
     * raw reply. Absent → repeat falls back to the in-memory last reply. */
    lastSpoken?(sessionId: string): string;
}
/** Live reads the loop consults on each chunk. */
export interface VoiceLoopRead {
    /** Whether the mic is muted (capture suppressed, loop stays armed). */
    readonly muted: boolean;
    /** Whether to speak the agent's reply back. */
    readonly readBack: boolean;
    /** VAD silence pause (seconds) before an utterance ends. */
    readonly vadSilenceSec?: number;
    /** Seconds of inactivity before the connection drops into standby (0 = off). */
    readonly voiceStandbySec?: number;
    /** Whether lifecycle transitions play status feedback. */
    readonly statusSounds?: boolean;
    /** Whether quiet acknowledgments are emitted while the user talks. */
    readonly backchannelEnabled?: boolean;
    /** Reply converter id (verbatim | digest). */
    readonly replyConverter?: string;
    /** Whether to rewrite the reply through the conversational model / digest. */
    readonly conversationalEnabled?: boolean;
    /** Speak a short digest instead of the full reply. */
    readonly spokenDigest?: boolean;
    /** Condense the reply to a terse summary. */
    readonly terseVoice?: boolean;
}
/** The running loop handle. */
export interface VoiceLoop {
    /** Arm the loop for one session (subscribe to its replies). */
    start(sessionId: string): Promise<void>;
    /** Reevaluate the inactivity duration after settings change. */
    settingsChanged(): void;
    /** Disarm the loop and reset to idle. */
    stop(): void;
    /**
     * Park immediately (manual pause): release the microphone, the streaming
     * recognizer, and any speech still playing, then publish standby. The loop
     * stays armed and bound to its session, so `start` resumes it with elapsed
     * time preserved. The same release the inactivity deadline performs; unlike
     * that deadline it applies while input or reply work is still in flight.
     */
    standby(): void;
    /** Feed a PCM16 chunk from the mic. */
    feed(pcm16: Uint8Array): void;
    /**
     * Speak `text` through the interruptible reply path (same phase gating + barge-in
     * arming as a live reply). Used by the controller for read-back / test TTS so a
     * barge-in can cut it. Returns a promise that settles when playback ends (or is
     * cut). Absent → the controller falls back to a plain `host.tts`.
     */
    speak?(text: string): Promise<void>;
    /** Whether the loop is armed. */
    readonly active: boolean;
    /** The session currently bound, if any. */
    readonly sessionId: string | null;
}
/**
 * A factory that produces the {@link Vad} the loop drives. The loop is
 * detector-agnostic: the default is the energy {@link EnergyVad}, but a caller
 * (the web transport) supplies a model-based VAD (Silero) so speech onset/offset
 * and barge-in are decided by speech content, not energy. Echo cancellation
 * slots in *below* the VAD (a reference-cancelled feed), so this seam does not
 * need to change when AEC is added — any provider behaves identically.
 * @param hangoverMs - seconds of trailing silence before an utterance ends.
 */
export type VadBuilder = (hangoverMs: number) => Vad;
export interface VoiceLoopOptions {
    /** Provider PCM input clock in Hz, shared with capture and energy VAD. */
    sampleRate?: number;
    /** Shared lifecycle implementation, optionally supplied by the composition. */
    lifecycle?: ReturnType<typeof createVoiceLifecycle>;
    /** Optional VAD builder. Defaults to the energy VAD. */
    vad?: VadBuilder;
}
/**
 * Build a running voice loop.
 * @param host - the injected STT / prompt / reply / TTS seam.
 * @param store - the shared voice runtime store this loop publishes to.
 * @param read - live mute / read-back reads (from the persisted config).
 * @param opts - optional VAD builder override.
 */
export declare function buildVoiceLoop(host: VoiceLoopHost, store: VoiceRuntimeStore, read: () => VoiceLoopRead, opts?: VoiceLoopOptions): VoiceLoop;
/** Concatenate PCM16 chunks into one buffer. */
export declare function joinBytes(chunks: readonly Uint8Array[]): Uint8Array;
export { StreamingConversation, type ConversationReply, type ConversationRequest, type StreamingConversationOptions } from './streaming-conversation.ts';
export { PipelineConversation, type PipelineConversationDeps } from './pipeline-conversation.ts';
export { EnergyVad } from './vad.ts';
