import type { VoiceCatalog } from './voice-catalog.ts';
/** The v2 catalog contains Flux STT and TTS models missing from Deepgram's v1 catalog. */
export declare function listDeepgramFluxCatalog(signal?: AbortSignal, request?: typeof fetch): Promise<{
    sttModels: {
        id: string;
        label: string;
    }[];
    ttsModels: {
        id: string;
        label: string;
    }[];
    voices: VoiceCatalog;
}>;
