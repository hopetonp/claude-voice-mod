/** Platform defaults for background desktop workers and system theme polling. */
import { type SpawnOptions } from 'node:child_process';
/** Suppress Windows console/taskbar flashes without changing other platforms. */
export declare function backgroundProcessOptions<T extends object>(options: T, platform?: NodeJS.Platform): T & {
    windowsHide?: boolean;
};
/** Start a background worker with the platform defaults applied. */
export declare function spawnBackground(command: string, args: string[], options?: SpawnOptions): import("child_process").ChildProcess;
export type SystemThemeRunner = (command: string, args: string[], options?: {
    windowsHide?: boolean;
}) => Promise<{
    stdout: string;
}>;
/** Follow the OS preference; applications resolve their own explicit theme first. */
export declare function desktopSystemTheme(platform?: NodeJS.Platform, run?: SystemThemeRunner): Promise<'dark' | 'light'>;
