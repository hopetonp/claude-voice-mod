export interface LivePreviewSession {
    readonly closed: boolean;
    speak(phrase: string, signal: AbortSignal, onAudio?: (pcm: Buffer) => void): Promise<{
        audio: string;
        sampleRate: number;
    }>;
    close(): void;
}
/** Open a reusable GPT Live connection. Closing or cancelling a sample closes the connection. */
export declare function openLivePreviewSession(key: string, model: string, voice: string, timeoutMs?: number, maxBytes?: number): Promise<LivePreviewSession>;
/** Backward compatible one-shot preview for clients without a settings-dialog lifecycle. */
export declare function previewLive(key: string, model: string, voice: string, phrase: string, signal: AbortSignal, timeoutMs: number, maxBytes: number, onAudio?: (pcm: Buffer) => void): Promise<{
    audio: string;
    sampleRate: number;
}>;
