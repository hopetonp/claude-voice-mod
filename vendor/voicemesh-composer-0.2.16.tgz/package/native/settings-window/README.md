# Shared desktop settings window

This native helper ships inside the existing `@voicemesh/composer` npm package.
It provides ready/reveal and dismiss-on-focus-loss behavior on Windows and macOS.
It does not select the consuming application's screen, dimensions, title or URL.

Tauri consumers depend on this directory as a Cargo path dependency. Apply
`voicemesh_desktop::configure_settings_window` to their Tauri builder, create a
window named `settings` with `visible(false)` and `focused(false)`, and position it
before revealing it. Declare `settings_ready` in the application's Tauri build
manifest and grant `allow-settings-ready` to the settings page's capability.
The page calls `settingsReady` from `@voicemesh/composer/desktop` after mounting.

For single-instance navigation, call `SettingsState::prepare_reload()` before
hiding/navigating the existing window. A loading or never-focused window does not
dismiss itself. Once focused, losing focus closes the popup. The default Tauri
last-window behavior exits the settings process. Applications with a different
exit policy keep responsibility for their process lifetime.

`configure_settings_window` owns the invoke handler. Consumers adding other
commands should register a combined handler including `voicemesh_desktop::commands::settings_ready`.
