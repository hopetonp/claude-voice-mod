use tauri::Manager;
mod window_state;
pub use window_state::SettingsState;

pub mod commands {
    use super::SettingsState;
    #[tauri::command]
    pub fn settings_ready(window: tauri::WebviewWindow, state: tauri::State<'_, SettingsState>) -> Result<(), String> {
        state.mark_ready();
        window.show().map_err(|error| error.to_string())?;
        window.set_focus().map_err(|error| error.to_string())
    }
}

/// Install the common ready/reveal and outside-click dismissal behavior.
/// Consumers position their window while hidden and signal after their UI mounts.
pub fn configure_settings_window(builder: tauri::Builder<tauri::Wry>) -> tauri::Builder<tauri::Wry> {
    builder
        .manage(SettingsState::default())
        .invoke_handler(tauri::generate_handler![commands::settings_ready])
        .on_window_event(|window, event| {
            if window.label() == "settings" {
                if let tauri::WindowEvent::Focused(focused) = event {
                    if window.state::<SettingsState>().should_dismiss_on_focus_change(*focused) {
                        let _ = window.close();
                    }
                }
            }
        })
}
