---
description: "A source-grounded guide to adapting VoiceMesh Composer to an agent harness."
kind: "integration-guide"
---

# Integrating VoiceMesh Composer with an agent harness

VoiceMesh Composer supplies reusable speech and realtime machinery. A harness supplies identity, authentication, task execution, persistence, UI, and deployment composition. This guide uses the current DeepSeek Harness integration as a worked example; it is not a promise that a stock or released Harness can install the integration unchanged.

## Start with the right package surface

Composer is currently private (`@voicemesh/composer`, version `0.2.0`). Its public entry points are:

| Import | Use in a harness adapter |
| --- | --- |
| `@voicemesh/composer` | STT/TTS interfaces and factories, lifecycle, captions, `LiveDelegation`, `LiveContext`, transcript-history preparation |
| `@voicemesh/composer/pipeline` | Browser or Node PCM/VAD pipeline when the harness runs a conventional STT → task → TTS loop |
| `@voicemesh/composer/browser` | microphone capture, realtime controller, WebRTC/PCM playback, browser transport and preview player |
| `@voicemesh/composer/server` | provider adapters, channel orchestration, model and voice discovery, optional local model installer, and OpenAI-compatible conversation endpoints |
| `@voicemesh/composer/wake` | readiness evaluation for an optional wake-word adapter |

Do not make Composer the owner of the harness session or its agent loop. In DeepSeek Harness, `packages/host/voice-host` maps Composer callbacks to one existing Session, while `packages/client/voice-client` maps Composer browser controls to the existing conversation view and settings. The coding prompts, tool policy, task receipts, access control, and conversation projection remain DeepSeek code.

## Responsibilities to preserve

| Composer owns | The harness adapter owns |
| --- | --- |
| audio capture/playback primitives, VAD/pipeline coordination, STT/TTS provider implementations, local runtime/model installation, OpenAI-compatible conversational transport and endpoint presets, realtime provider protocol translation, channel queueing/finalization, transcript assembly helpers, listener-cue and Live delegation mechanics | session and task IDs; mapping speech to an existing conversation; model prompts and tools; credential lookup and authorization; durable event schema and audio retention policy; WebSocket/HTTP authentication; routes; settings persistence, localization and deployment/package composition |

Keep provider keys in the host-side credential service. The DeepSeek client asks its authenticated host to save or query a credential slot, then receives only `{ configured: boolean }`. Its realtime server resolves the key after connection authentication and passes it into Composer’s provider settings. Composer’s channel recorder is designed to receive redacted provider events; it must not be given a credential, raw provider error body, or browser persistence responsibility.

## Setup UI is a harness adapter

Composer keeps an optional React settings editor in the separately packaged `@voicemesh/settings-editor`. A harness may use it or supply its own UI, as DeepSeek does. The shared editor calls a `VoiceSettingsBackend` adapter for storage, credential status, discovery, previews, and local installation; it never stores keys. Composer's server export supplies `LocalInstaller`, `LocalVoice`, `listPipelineEngines`, `conversationProviders`, `listConversationModels`, and `requestPipelineConversation`. The harness chooses private runtime/model directories, authenticates its routes, resolves credentials, and streams the selected Composer result. DeepSeek's existing `VoiceSettings` remains unchanged.

The optional spoken-request classifier is a routing-advice tool, not a second voice pipeline. When enabled, the harness supplies a separate Jev or OpenAI selection, model, and credential to `classifySpokenRequest` from `@voicemesh/composer/server`. Both providers share that Composer function signature; Composer translates Jev to TypeSafe's typed-choice API and OpenAI to its Decisions API. The harness advertises `spokenRequestClassifierTool` to a realtime model, or provides `PipelineConversationDeps.classify` for a pipeline model. The voice model asks the classifier about the latest completed user request, then chooses whether to answer, clarify, or call the harness coding tool. Omit the tool and callback when the option is off; Composer's prior routing remains in place. The harness owns the enabled setting and credential store.

Treat credential entry separately from ordinary preferences. DeepSeek sends keys through an authenticated, write-only host request and keeps only configured status in browser state. A different harness should use its own credential service and expose a comparable status or setup error without returning the secret to Composer’s browser adapter. Setup should not silently choose a paid provider or start recording audio.

## Worked example: DeepSeek Harness

The DeepSeek integration has two adapters.

1. `packages/host/voice-host` validates the browser start message, authenticates the connection, resolves provider credentials, opens `openStsChannel`, and owns the channel callbacks. Its recorder writes selected `voice/sts/event` and `voice/sts/transcript` Session events. Optional development audio recording stores raw PCM separately and references it from events. `StsTasks` turns a voice tool call into a harness task and records receipt/outcome state. `LiveDelegation` and `LiveContext` are given harness callbacks for task admission, transcript persistence, and delivery eligibility.
2. `packages/client/voice-client` retains the browser settings/runtime state and invokes `createStsController` or the pipeline adapter. It supplies the authenticated RPC and signaling adapter, projects transcript events with a chat-node renderer, and registers controls in the Harness’s documented UI slots.

The provider channel is deliberately narrower than a task runtime. `StsChannelOwner.record()` must make an event durable before transmission; `receive()` consumes a validated event. `send()` proves durable recording and socket transmission, while `command()` separately reports provider acceptance. Neither proves that speech was played. Keep those three states distinct in harness task/result records.

### Lifecycle and transcript routing

Use one cancellation owner for each live voice connection, and close it when the linked session, transport, or authenticated browser connection ends. A typical adapter sequence is:

1. Start only after the user gesture has acquired browser media and the authenticated server has accepted the connection.
2. Resolve the linked harness session and provider configuration; open a Composer realtime channel or pipeline.
3. Persist provider-neutral transcript rows as they arrive. Update a stable display row for interim text; finalize the same row when the provider completes the utterance. Do not turn every interim revision into an agent prompt.
4. For a coding request, let the voice model call a harness-owned dispatch function. Record intent and receipt before/with task admission; retain an owed terminal result until it is actually delivered to the voice model.
5. Route ordinary voice answers and task results through the harness’s normal chat/session projection. TTS/playback uses the resulting text, but audible playback remains a separate client-side fact.
6. On finish, request provider finalization and keep the primary transport alive until Composer drains. On immediate stop, abort capture/playback and close the channel. Do not cancel a durable harness task merely because voice closed unless that is an explicit product rule.

DeepSeek optionally feeds completed, speaker-labelled rows through `prepareTranscriptHistory()` before a realtime connection starts. This is voice context, not a replacement for the harness’s own session history or authorization rules.

### Minimal adapter outline

This is pseudocode: the names at the edges are intentionally harness-defined. The Composer calls and ownership split are real.

```ts
const channel = await openStsChannel(resolvedSettings, {
  async record(direction, event, signal) {
    // Persist a redacted event in the linked harness session before delivery.
    await sessionVoiceLog.append({ direction, event }, signal)
  },
  async receive(event, signal) {
    // Convert validated provider events into transcript rows, tool calls, and playback work.
    await routeProviderEventToHarness(event, signal)
  },
}, connection.signal, provider)

// A task tool callback is harness policy, not Composer policy.
async function dispatchCodingTask(instruction: string, signal: AbortSignal) {
  const receipt = await harnessTasks.admit({ sessionId, instruction, signal })
  await sendTaskReceiptThroughVoice(receipt)
  return receipt
}
```

The real adapter must validate browser payloads and provider settings before these calls, bound queues and stored audio, serialize state transitions that can race, and redact before persistence.

## Ordered integration checklist

1. Choose pipeline speech, realtime speech, or both. Select only the Composer entry points required by that mode.
2. Define the harness-owned session mapping and cancellation rules. Voice must attach to an existing session identity rather than inventing a parallel task model.
3. Implement host routes/signaling behind the harness’s existing authentication and authorization mechanism.
4. Add a host credential adapter that resolves keys server-side; expose status, never secret values, to the client.
5. Define durable voice event and transcript records, including interim-to-final row replacement and audio-reference retention if raw audio is stored.
6. Implement the channel owner: durable redacted recording, provider-event routing, task/tool callbacks, result eligibility, and finalization handling.
7. Implement the browser adapter: user-gesture media acquisition, lifecycle state projection, signaling, captions, controls, and cleanup on unmount/session switch.
8. Add harness-owned setup UI for required selections, credential status, discovery, previews or probes, and actionable failures. Mount it and the voice controls through public extension points; do not patch a harness’s composer, chat, or session core merely to place a microphone control.
9. Package the host and client adapters with explicit runtime dependencies. Treat local tarballs, symlinks, and unpublished harness packages as development-only wiring.
10. Verify the installed artifact in the target profile, not only a source checkout.

## DeepSeek-specific installation status and limitations

DeepSeek currently contains `dsh-voice-bundle`, a private `@hopeton/dsh-voice` bundle. It inserts the host row and relies on the DeepSeek web bundle to insert the client row. Its README documents a local-checkout command and states that the bundle, Composer, and the DeepSeek voice halves are not published. The current DeepSeek voice package manifests point at content-hashed local Composer tarballs. This is evidence of one development installation path, not a supported general-purpose installation recipe.

The active DeepSeek working tree also contains unreleased modifications outside the voice adapters: session-core recognition of `voice/sts` events and a custom `conversation.input.emptyAction` slot for the mic button. The published Harness does not provide that mic slot. Those are Harness implementation changes under development, not Composer requirements. Another harness should use its own public UI extension points and durable-event facilities; it should not copy or depend on those DeepSeek changes.

## Focused validation

- Build Composer, then typecheck a small host and browser consumer against the packed artifact and the entry points it imports.
- Verify the host rejects unauthenticated signaling and malformed start/settings payloads; verify the browser never receives provider keys.
- Exercise one final user transcript, one interim-to-final caption update, one task dispatch/receipt/result path, and one ordinary spoken reply.
- Exercise stop, browser disconnect, session switch, and provider-finalization paths. Confirm tasks and transcripts follow the product’s stated retention and cancellation rules.
- Check that persisted channel events are redacted and any audio references resolve under the configured bounds.
- Install the actual adapter/package/profile and verify its resolved dependencies and UI mount once. Do not infer a successful installation from a source-level test.

For Composer’s own package checks, run `npm run build`, `npm run check:boundaries`, and `npm run test:consumers`. They validate the built package’s exported boundaries and independent consumers; they do not certify a particular harness integration.
