"""Install optional English/Chinese model packs; voice names come from provider metadata."""
import argparse
import html
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import tarfile
import urllib.request
import zipfile
import shutil
import subprocess
import tempfile
import time
import sys
import hashlib

BASE = "https://alphacephei.com/vosk/models/"
KOKORO = "kokoro-{precision}multi-lang-"
KOKORO_SOURCE = "https://k2-fsa.github.io/sherpa/onnx/tts/all/Chinese-English/kokoro-multi-lang-"
PARAKEET = "sherpa-onnx-nemo-parakeet-tdt-0.6b-"
PARAKEET_SOURCE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
PARAKEET_DOCS = "https://k2-fsa.github.io/sherpa/onnx/pretrained_models/offline-transducer/nemo-transducer-models.html"
# Parakeet is an English-plus-European recognizer; it carries no Chinese.
PARAKEET_LANGUAGES = {"v2": ["en-US"], "v3": ["en-US", "fr-FR", "de-DE", "es-ES", "it-IT", "pt-BR", "nl-NL", "pl-PL"]}
# Open-vocabulary keyword spotting. The keywords themselves are supplied at run time,
# so a pack is a small general spotter rather than a list of fixed wake words.
KWS_SOURCE = "https://github.com/k2-fsa/sherpa-onnx/releases/download/kws-models/"
KWS_DOCS = "https://k2-fsa.github.io/sherpa/onnx/kws/pretrained_models/index.html"
# The canonical phrase encoder. `sentencepiece` and `pypinyin` are imported lazily by
# text2token, so they must be installed even though the wheel does not require them.
TOKENIZER_PACKAGES = ["sherpa-onnx", "sentencepiece", "pypinyin"]
KWS_PACKS = {
    "en": ("sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01", "English", "en-US"),
    "zh": ("sherpa-onnx-kws-zipformer-wenetspeech-3.3M-2024-01-01", "Chinese", "zh-CN"),
}


def kws_assets(directory):
    """Read the transducer, token and BPE assets an extracted KWS pack contains.

    A KWS pack ships both fp32 and int8 graphs, so unlike the Parakeet helper this
    one prefers the fp32 file and accepts an int8-only pack rather than demanding a
    single match.
    """
    assets = {}
    for key in ("encoder", "decoder", "joiner"):
        matches = sorted(path.name for path in directory.glob(f"{key}*.onnx"))
        preferred = [name for name in matches if not name.endswith(".int8.onnx")]
        chosen = preferred[0] if preferred else (matches[0] if matches else None)
        if chosen is None:
            raise ValueError(f"KWS model pack does not contain a {key} graph")
        assets[key] = chosen
    if not (directory / "tokens.txt").is_file():
        raise ValueError("KWS model pack has no tokens.txt")
    assets["tokens"] = "tokens.txt"
    # The shipped packs model BPE units, and the spotter needs the vocabulary to
    # tokenise a keyword into the same units.
    if (directory / "bpe.model").is_file():
        assets["bpe"] = "bpe.model"
    return assets


def parakeet_assets(directory):
    """Read the transducer file names an extracted NeMo Parakeet pack contains."""
    assets = {}
    for key, pattern in (("encoder", "encoder*.onnx"), ("decoder", "decoder*.onnx"), ("joiner", "joiner*.onnx")):
        matches = sorted(path.name for path in directory.glob(pattern))
        if len(matches) != 1:
            raise ValueError(f"Parakeet model pack does not contain exactly one {pattern}")
        assets[key] = matches[0]
    if not (directory / "tokens.txt").is_file():
        raise ValueError("Parakeet model pack has no tokens.txt")
    assets["tokens"] = "tokens.txt"
    return assets


def install_tokenizer(runtime):
    """Create the tokeniser's own virtual environment and install its packages.

    Kept in a venv under the runtime directory rather than installed into the interpreter the
    installer happens to run under, so nothing outside this app home is touched. `sentencepiece`
    and `pypinyin` are imported lazily by `text2token`, so all four packages must be present or
    the first call fails with a "please install" message instead of an install-time error.
    """
    venv = runtime / ".tokenizer-venv"
    python = venv / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
    if not python.exists():
        import venv as venv_module
        progress("tokenizer")
        venv_module.EnvBuilder(with_pip=True).create(venv)
    marker = venv / ".installed"
    if marker.exists():
        return python
    progress("tokenizer")
    subprocess.run([str(python), "-m", "pip", "install", "--quiet", "--disable-pip-version-check",
                    *TOKENIZER_PACKAGES], check=True)
    marker.write_text(" ".join(TOKENIZER_PACKAGES))
    return python


def progress(phase, downloaded=0, total=0):
    print(json.dumps({"phase": phase, "downloaded": downloaded, "total": total}), flush=True)


def write_capabilities(runtime):
    """Record the operations the installed runtime advertises.

    The list is derived from the manifest of the artifact actually sitting in the
    runtime directory, so the record describes what was installed rather than what
    the installer assumed. Readiness reads this instead of testing that worker.mjs
    exists, because a file can exist and still lack the operation.
    """
    manifest = json.loads((runtime / "package.json").read_text(encoding="utf-8"))
    (runtime / ".capabilities.json").write_text(json.dumps({
        "version": manifest.get("version", ""),
        "ops": manifest.get("dshVoice", {}).get("capabilities", []),
        "writtenAt": datetime.now(timezone.utc).isoformat(),
    }, indent=2) + "\n", encoding="utf-8")


def install(root, name, url):
    target = root / name
    if target.is_dir():
        return target
    with tempfile.TemporaryDirectory(prefix=".install-", dir=root) as temp:
        staging = Path(temp)
        archive = staging / url.rsplit("/", 1)[1]
        progress("downloading")
        with urllib.request.urlopen(url, timeout=60) as response, archive.open("wb") as output:
            total = int(response.headers.get("Content-Length", 0))
            count, last = 0, 0
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
                count += len(chunk)
                if time.monotonic() - last > 0.25:
                    progress("downloading", count, total)
                    last = time.monotonic()
            progress("downloading", count, total)
        progress("extracting")
        if archive.suffix == ".zip":
            with zipfile.ZipFile(archive) as source:
                for member in source.namelist():
                    if not (staging / member).resolve().is_relative_to(staging.resolve()):
                        raise ValueError("Archive contains an unsafe path")
                source.extractall(staging)
        else:
            with tarfile.open(archive) as source:
                source.extractall(staging, filter="data")
        extracted = staging / name
        if not extracted.is_dir():
            raise ValueError("Archive does not contain the selected model")
        extracted.rename(target)
    return target


def voice_metadata(page):
    """Read provider speaker IDs; prefix conventions supply locale and gender."""
    locales = {
        "a": ("en-US", "American"), "b": ("en-GB", "British"),
        "z": ("zh-CN", "Chinese"), "e": ("es-ES", "Spanish"),
        "f": ("fr-FR", "French"), "h": ("hi-IN", "Indian"),
        "i": ("it-IT", "Italian"), "j": ("ja-JP", "Japanese"),
        "p": ("pt-BR", "Brazilian"),
    }
    voices = []
    for sid, code in re.findall(r"<td>(\d+) -> ([a-z]{2}_[a-z0-9_]+)</td>", html.unescape(page)):
        prefix, name = code.split("_", 1)
        locale, region = locales[prefix[0]]
        label = name.replace("_", " ").title() if not name.isdigit() else code.upper().replace("_", " ")
        voices.append({"id": sid, "name": label, "languages": [locale],
                       "gender": "female" if prefix[1] == "f" else "male", "region": region})
    if not voices or len({v["id"] for v in voices}) != len(voices):
        raise ValueError("Provider voice metadata is missing or ambiguous")
    return voices


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--kind", choices=["stt", "tts", "kws", "both"], default="both")
    parser.add_argument("--runtime", type=Path)
    parser.add_argument("--languages", nargs="+", choices=["en", "zh"], default=["en", "zh"])
    parser.add_argument("--stt-engine", choices=["vosk", "parakeet"], default="vosk")
    parser.add_argument("--parakeet-version", choices=["v2", "v3"], default="v2")
    parser.add_argument("--kokoro-version", choices=["v1_0", "v1_1"], default="v1_0")
    parser.add_argument("--precision", choices=["fp32", "int8"], default="fp32")
    args = parser.parse_args()
    args.directory.mkdir(parents=True, exist_ok=True)
    if args.stt_engine == "parakeet" and any(language != "en" for language in args.languages if args.kind != "tts"):
        raise RuntimeError("Parakeet is an English and European recognizer; it carries no Chinese model")
    if args.runtime:
        progress("runtime")
        npm = shutil.which("npm")
        if not npm:
            raise RuntimeError("Node.js and npm are required to install local speech")
        fingerprint = hashlib.sha256((args.runtime / "package-lock.json").read_bytes()).hexdigest()
        marker = args.runtime / ".installed-lock"
        if not marker.exists() or marker.read_text() != fingerprint or not (args.runtime / "node_modules").is_dir():
            subprocess.run([npm, "ci", "--no-audit", "--no-fund"], cwd=args.runtime,
                           stdout=sys.stderr, stderr=sys.stderr, check=True)
            marker.write_text(fingerprint)
        # Record what this runtime can actually do, derived from the manifest of the
        # artifact that was just installed. Readiness checks the capability, not mere
        # file existence: an old worker.mjs can exist and still lack an operation.
        write_capabilities(args.runtime)

    if args.kind == "kws":
        if args.runtime:
            install_tokenizer(args.runtime)
        for language in args.languages:
            model, label, locale = KWS_PACKS[language]
            directory = install(args.directory, model, KWS_SOURCE + model + ".tar.bz2")
            (directory / "voice-model.json").write_text(json.dumps({
                "kind": "kws", "name": "Keyword spotter " + label + " (Zipformer 3.3M)",
                "languages": [locale], "sourceUrl": KWS_DOCS, "kws": kws_assets(directory),
            }, indent=2) + "\n", encoding="utf-8")
        progress("complete")
        return
    for language in (args.languages if args.kind != "tts" else []):
        if args.stt_engine == "parakeet":
            model = PARAKEET + args.parakeet_version + "-int8"
            directory = install(args.directory, model, PARAKEET_SOURCE + model + ".tar.bz2")
            (directory / "voice-model.json").write_text(json.dumps({
                "kind": "stt", "engine": "parakeet",
                "name": "Parakeet TDT 0.6B " + args.parakeet_version + " (English)",
                "languages": PARAKEET_LANGUAGES[args.parakeet_version],
                "sourceUrl": PARAKEET_DOCS, "parakeet": parakeet_assets(directory),
            }, indent=2) + "\n", encoding="utf-8")
            continue
        model, name, locale = (
            ("vosk-model-small-en-us-0.15", "Vosk English (US), small", "en-US")
            if language == "en" else ("vosk-model-small-cn-0.22", "Vosk Chinese, small", "zh-CN")
        )
        directory = install(args.directory, model, BASE + model + ".zip")
        (directory / "voice-model.json").write_text(json.dumps({
            "kind": "stt", "engine": "vosk", "name": name, "languages": [locale], "sourceUrl": BASE,
        }, indent=2) + "\n", encoding="utf-8")
    if args.kind == "stt":
        progress("complete")
        return
    model_id = KOKORO.format(precision="int8-" if args.precision == "int8" else "") + args.kokoro_version
    source_url = KOKORO_SOURCE + args.kokoro_version + ".html"
    directory = install(args.directory, model_id,
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/" + model_id + ".tar.bz2")
    with urllib.request.urlopen(source_url, timeout=30) as response:
        voices = voice_metadata(response.read().decode())
    (directory / "voice-model.json").write_text(json.dumps({
        "kind": "tts", "name": "Kokoro " + args.kokoro_version.replace("_", ".") + " " + args.precision.upper(), "languages": sorted({locale for voice in voices for locale in voice["languages"]}),
        "sourceUrl": source_url, "voices": voices,
        "kokoro": {"model": "model.int8.onnx" if args.precision == "int8" else "model.onnx", "voices": "voices.bin", "tokens": "tokens.txt",
                   "dataDir": "espeak-ng-data", "lexicon": "lexicon-us-en.txt,lexicon-zh.txt", "dictDir": "dict"},
    }, indent=2) + "\n", encoding="utf-8")
    progress("complete")


if __name__ == "__main__":
    if sys.version_info < (3, 12):
        raise RuntimeError("Python 3.12 or newer is required")
    if len(sys.argv) < 2 or sys.argv[1].startswith("-"):
        main()
    else:
        root = Path(sys.argv[1])
        root.mkdir(parents=True, exist_ok=True)
        with (root / ".install.lock").open("a+b") as lock:
            if sys.platform == "win32":
                import msvcrt
                lock.write(b"0")
                lock.flush()
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            main()
