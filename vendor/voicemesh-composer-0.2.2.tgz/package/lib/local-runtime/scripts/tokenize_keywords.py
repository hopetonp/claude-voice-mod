"""Turn wake phrases into a keywords file using the canonical sherpa tokenizer.

Why this exists and why it is Python: a phrase must be encoded in the pack's BPE units exactly
as the shipped examples are. Rounds 36-45 measured the alternatives — greedy longest-match over
`tokens.txt` reproduces 7 of 9 known phrases and silently mangles the rest; a hand-written BPE
over `bpe.model` scored 4 of 9; the installed Node runtime has no tokenizer at all. The sherpa
tokenizer reproduces **9 of 9**, so it is the only correct choice.

It calls the Python interface rather than the `sherpa-onnx-cli` binary: the CLI needs `click`,
which the wheel does not pull in, while `sherpa_onnx.text2token` needs neither `click` nor a
subprocess. `sentencepiece` and `pypinyin` are imported lazily by that function, so they must be
installed alongside the wheel or the first call fails.

None of this is on the wake path: it runs once per phrase change, host-side.

Emits one JSON line per event, like install_models.py.
Exit codes: 0 written, 2 bad input, 3 tokenizer unavailable, 4 tokenizer failed.
"""
import argparse
import json
import sys
from pathlib import Path

#: Imported lazily so the module can report a missing tokenizer instead of failing to start.
TOKENIZER_HINT = "pip install sherpa-onnx sentencepiece pypinyin"
#: Keep keyword expansion small enough that alternatives do not materially increase false triggers.
MAX_KEYWORD_VARIANTS = 8
#: A split must leave two letters on each side; short words are already stable tokenizer inputs.
MIN_COMPOUND_PART_LENGTH = 2
#: Only longer words can plausibly be spoken as two words; keep ordinary short words exact.
MIN_COMPOUND_WORD_LENGTH = 6


def emit(payload):
    """One progress line on stdout."""
    print(json.dumps(payload), flush=True)


def decorate(tokens, boost, threshold):
    """Render one token list as a keywords-file line, with optional score and threshold."""
    parts = [' '.join(tokens)]
    if boost is not None:
        parts.append(f":{boost}")
    if threshold is not None:
        parts.append(f"#{threshold}")
    return ' '.join(parts)


def compound_word_variants(phrase, limit=MAX_KEYWORD_VARIANTS):
    """Return an exact phrase plus bounded one-word ASCII compound splits.

    The keyword spotter can distinguish BPE units that ordinary speech does not. Splitting one
    sufficiently long ASCII word supplies common spoken compounds without changing the saved
    phrase. CJK and short words have no unambiguous space boundary, so they remain exact.
    """
    variants = [phrase]
    words = phrase.split()
    for index, word in enumerate(words):
        if not (word.isascii() and word.isalpha() and len(word) >= MIN_COMPOUND_WORD_LENGTH):
            continue
        for split in range(MIN_COMPOUND_PART_LENGTH, len(word) - MIN_COMPOUND_PART_LENGTH + 1):
            variants.append(' '.join(words[:index] + [word[:split], word[split:]] + words[index + 1:]))
            if len(variants) >= limit:
                return variants
    return variants


def encode_keyword_variants(phrases, encode):
    """Encode bounded phrase alternatives and deduplicate equal token sequences."""
    variants = []
    for phrase in phrases:
        variants.extend(compound_word_variants(phrase))
    encoded = encode(variants)
    if len(encoded) != len(variants):
        raise ValueError(f"asked for {len(variants)} phrases but tokenized {len(encoded)}")
    unique = []
    seen = set()
    for tokens in encoded:
        key = tuple(str(token) for token in tokens)
        if key not in seen:
            seen.add(key)
            unique.append(key)
    return unique, len(variants)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pack", type=Path, help="extracted keyword-spotting pack directory")
    parser.add_argument("--phrase", action="append", default=[], help="a wake phrase; repeatable")
    parser.add_argument("--phrases-file", type=Path, help="file with one phrase per line")
    parser.add_argument("--output", type=Path, help="where to write (default: pack/keywords.txt)")
    parser.add_argument("--boost", type=float, help="boosting score applied to every phrase")
    parser.add_argument("--threshold", type=float, help="trigger threshold applied to every phrase")
    args = parser.parse_args()

    phrases = list(args.phrase)
    if args.phrases_file is not None:
        phrases += [line.strip() for line in args.phrases_file.read_text(encoding="utf-8").splitlines() if line.strip()]
    phrases = [phrase for phrase in phrases if phrase]
    if not phrases:
        emit({"error": "no-phrases", "detail": "give at least one --phrase or a --phrases-file"})
        return 2

    tokens_file = args.pack / "tokens.txt"
    if not tokens_file.is_file():
        emit({"error": "model-invalid", "detail": f"no tokens.txt in {args.pack}"})
        return 2

    # A pack whose vocabulary carries no lowercase piece cannot encode a phrase typed in the
    # ordinary way: the gigaspeech pack is 500 uppercase pieces, and the tokeniser does not
    # normalise case for us. Decide from the vocabulary rather than assuming a language, and
    # say so, because the alternative is a wake word that silently never fires.
    # Special pieces are lowercase by convention (`<unk>`, `<blk>`, `<sos/eos>`) and say
    # nothing about the language, so they are excluded before the check.
    pieces = [line.split()[0] for line in tokens_file.read_text(encoding="utf-8", errors="replace").splitlines()
              if line.split() and not line.startswith("<")]
    uppercased = not any(character.islower() for piece in pieces for character in piece)
    if uppercased:
        phrases = [phrase.upper() for phrase in phrases]

    try:
        from sherpa_onnx import text2token
    except ImportError as error:
        # A named reason, so the host surfaces "install the tokenizer" rather than a failed spawn.
        emit({"error": "tokenizer-missing", "detail": f"{error}; {TOKENIZER_HINT}"})
        return 3

    bpe_model = args.pack / "bpe.model"
    emit({"phase": "tokenizing", "phrases": len(phrases), "uppercased": uppercased})
    try:
        encoded, variants = encode_keyword_variants(
            phrases,
            lambda candidates: text2token(candidates, str(tokens_file), tokens_type="bpe",
                                          **({"bpe_model": str(bpe_model)} if bpe_model.is_file() else {})),
        )
    except Exception as error:  # noqa: BLE001 - surfaced verbatim to the host
        emit({"error": "tokenizer-failed", "detail": str(error)[:400]})
        return 4

    output = args.output or (args.pack / "keywords.txt")
    lines = [decorate(tokens, args.boost, args.threshold) for tokens in encoded]
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    emit({"phase": "complete", "written": str(output), "phrases": len(lines), "variants": variants,
          "uppercased": uppercased})
    return 0


if __name__ == "__main__":
    sys.exit(main())
