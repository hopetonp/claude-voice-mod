/**
 * The ack-router decision: what to say out loud, and whether the utterance must
 * be forwarded to the coding agent.
 *
 * This is purely client-side and best-effort. Any error or timeout yields the
 * safe default of "forward to the agent, no filler" so the voice is never
 * blocked and a real task is never dropped.
 *
 * Ported from the Flutter `ack_router.dart`. The load-bearing logic, carried
 * verbatim:
 *
 * - **Answer-from-memory implies not-forwarded.** If the router composed an
 *   answer from what the assistant already said, forwarding the utterance would
 *   make the agent redo the very work the memory existed to avoid.
 * - **A malformed decision forwards.** An unparseable or non-JSON reply is
 *   treated as a spoken filler with `forward: true`, so a real task is never
 *   dropped.
 * - **The fallback is silent.** On any error or timeout, hand the utterance to
 *   the agent and say nothing.
 */
export declare class AckDecision {
    readonly reply: string | null;
    readonly forward: boolean;
    readonly repeatLast: boolean;
    readonly readBackOutput: boolean;
    readonly answer: string | null;
    constructor(reply: string | null, forward: boolean, repeatLast?: boolean, readBackOutput?: boolean, answer?: string | null);
    /** Whether this decision answers the question from memory. */
    get answersFromMemory(): boolean;
    /** The safe fallback when the router cannot be reached or understood. */
    static readonly forwardFallback: AckDecision;
}
/** Strip a surrounding ```json ... ``` fence if present. */
export declare function stripCodeFence(content: string): string;
/**
 * Parse a model reply into an [AckDecision].
 *
 * A well-formed JSON object drives both fields; a plain-text reply (not JSON)
 * is treated as a spoken filler with a safe `forward: true` so a real task is
 * never dropped.
 */
export declare function parseAckDecisionJson(content: string): AckDecision;
