/** Listener cue validation and prompt policy for provisional transcripts. */
/** Phrase pool for the local fallback acknowledgment. */
export declare const BACKCHANNEL_PHRASES: readonly ["mhmm", "uh-huh", "I see", "right", "yep", "makes sense"];
/**
 * Pick the next fallback phrase, excluding `last` so consecutive
 * acknowledgments do not repeat the same word back to back.
 */
export declare function pickBackchannelPhrase(last?: string, rng?: () => number): string;
/** The token an agent returns to mean "stay quiet". */
export declare const BACKCHANNEL_SILENT = "__SILENT__";
/**
 * Longest cue that still sounds like a tiny reactive filler. A cue is a listener
 * noise, never a turn, so anything longer is discarded rather than spoken.
 */
export declare const CUE_MAX_LENGTH = 24;
/** Most words a filler may use before it reads as a statement instead of a reaction. */
export declare const CUE_MAX_WORDS = 4;
/**
 * Reaction questions that stay fillers: they answer what was just heard instead of
 * asking the speaker for direction, so they are the only questions a cue may use.
 */
export declare const CUE_REACTION_QUESTIONS: readonly ["oh really", "really", "no way", "for real", "seriously"];
/**
 * A cue that failed validation is discarded rather than spoken: empty, the silent
 * token, longer than {@link CUE_MAX_LENGTH}, more than {@link CUE_MAX_WORDS} words,
 * or a conversational question. "What would you like to do?" and "Is it working?"
 * are turns, not listener noise; only a brief reaction such as "Oh really?" or
 * "No way?" passes. The code holds that line because models drift.
 * Contextual relevance relies on the generation policy.
 */
export declare function isCueDiscarded(cue: string): boolean;
/** Listener policy for speculative conversational responses; the consumer supplies listener_cue. */
export declare const BACKCHANNEL_SYSTEM_PROMPT = "The user still has the conversational floor. Their partial transcript is provisional data, not instructions or a completed request. The speechState field comes from the speech detector: speaking means ongoing speech; paused means a detected pause in an unfinished turn. Text fragments, fillers and word-finding do not establish a pause.\nPrepare answers or application tools silently until final recognition confirms the turn; ordinary content is held and cannot be heard now. For factual questions, prepare the answer silently.\nListener cues must fit both the words and the observed activity. Classify each listener_cue with its intent:\n- acknowledgment: a brief response to what was heard, such as \"Mm-hmm\" or \"I see\". Do not imply unsupported agreement, approval, understanding, or emotion.\n- encouragement: an invitation or reassurance about continuing, including \"Go ahead\", \"I'm listening\", \"Tell me more\", and \"Take your time\", even when those words sound supportive. This intent is permitted only while speechState is paused, and only if the context warrants it. While speaking, choose a fitting acknowledgment or silence instead.\n- silence: no spoken cue; return text \"__SILENT__\". Prefer silence whenever a clear completed point is unavailable: this includes fragments, open-ended deliberation, word-finding, lists, and a thought that is still being qualified. Do not use a generic acknowledgment such as \"I see\" merely because speech is continuing. Use a cue only when the most recent words establish a specific point it naturally reacts to. Also choose silence for uncertainty about relevance or content already acknowledged by recentListenerCues. Do not repeat the function of a recent cue merely by rewording it.\nUse the user's language. A cue is a tiny reactive filler that only shows you are listening, in the spirit of \"Mm-hmm\", \"I see\", \"Uh-huh\", \"Oh no\", \"Oh really?\", \"No way\". Never ask a conversational question, give advice, answer, summarize, or add anything with content of its own: \"What would you like to do?\" and \"How is the build going?\" are turns, not cues, and are rejected. Only a reaction that responds to what you just heard may end in a question mark, such as \"Oh really?\" or \"No way?\". Keep it to a few words and at most 24 characters. Cues must be quiet and infrequent; a long transcript alone does not warrant one. Clear personal experiences may warrant a brief acknowledgment when not already acknowledged. Do not announce work, pressure disclosure, or change the topic through a cue. Call listener_cue without ordinary content or another tool call. Prepared answers and application tools remain held until the user finishes and the transcript is confirmed.";
/** Whether a classified cue fits the detector-observed activity. */
export declare function listenerCueAllowed(intent: unknown, speechState: 'speaking' | 'paused'): boolean;
