import type { AudioSink } from '../providers/deepgram-aura.ts';
/** A PCM16 sink plus an autoplay-unlock verb and a barge-in stop. */
export interface PcmSink {
    sink: AudioSink;
    /** Set the source rate before supplying audio for a response. */
    setSampleRate(rate: number): void;
    /** Create/resume the AudioContext inside a user gesture. */
    unlock(): Promise<void>;
    /**
     * Stop the in-flight playback immediately (barge-in): silences the source
     * node, resolves the pending chunk promise, and resets the schedule so the
     * next usable play restarts cleanly. After a stop, further `sink()` calls are
     * no-ops until `reset()` re-arms the sink.
     */
    stop(): void;
    /** Re-arm the sink after a barge-in stop so the next playback plays again. */
    reset(): void;
    /** Release playback nodes and the device context after voice stops. @returns device closure completion. */
    close(): Promise<void>;
    /** Audio duration received and milliseconds rendered by the output device since reset. */
    position(): {
        playedMs: number;
        durationMs: number;
    };
    /**
     * Observe the exact samples this sink plays to the speakers — the acoustic
     * echo reference. The AEC uses this far-end signal to cancel the reply out of
     * the mic capture. Optional; absent means no reference tap.
     */
    onPlayback?(handler: (samples: Float32Array) => void): () => void;
}
/**
 * Build a PCM16 playback sink.
 * @param onAudio - optional diagnostics observer (chunk byte length, context state).
 * @param fadeInFrames - opening fade length in samples.
 * @param volume - Playback amplitude, sampled when each chunk is decoded.
 * @param onStart - notification once the first non-silent samples reach the output device.
 */
export declare function createPcmSink(onAudio?: (bytes: number, ctxState: string) => void, fadeInFrames?: number, onStart?: () => void, volume?: () => number): PcmSink;
