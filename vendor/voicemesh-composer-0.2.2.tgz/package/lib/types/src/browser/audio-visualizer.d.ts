/** Optional browser audio observation. Taps never connect to the speakers. */
export interface VoiceAudioLevels {
    /** Microphone waveform amplitudes, normalized to 0..1. */
    readonly input: readonly number[];
    /** Rendered reply waveform amplitudes, normalized to 0..1. */
    readonly output: readonly number[];
}
type Direction = 'input' | 'output';
/** Observe an existing audio node without changing its output routing.
 * @param source - Live capture or playback source.
 * @param direction - Microphone or reply audio.
 * @returns Disposer to call before disconnecting the source.
 */
export declare function observeVoiceNode(source: AudioNode, direction: Direction): () => void;
/** Observe native WebRTC audio only while a visualizer subscribes.
 * @param stream - Existing media tracks; observation never stops them.
 * @param direction - Microphone or reply audio.
 * @returns Disposer to call before releasing the stream.
 */
export declare function observeVoiceStream(stream: MediaStream, direction: Direction): () => void;
/** Subscribe to audio from Composer's live browser sources in this page.
 * No audio is retained; the last unsubscribe releases all analyser nodes and polling.
 * @param listener - Receives current input/output waveform levels each animation frame.
 * @returns Unsubscribe function.
 */
export declare function subscribeVoiceAudio(listener: (levels: VoiceAudioLevels) => void): () => void;
export {};
