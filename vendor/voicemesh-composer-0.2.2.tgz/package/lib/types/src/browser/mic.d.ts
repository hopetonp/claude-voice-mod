/**
 * Browser microphone capture → PCM16 feed.
 *
 * getUserMedia + a single-channel AudioContext at the requested sample rate, downsampled into
 * little-endian signed 16-bit PCM and handed to an `onPcm16` callback (the
 * voice loop's `feed`). Owns the live MediaStream and the WebAudio graph and
 * releases them on stop. This is the only browser-hardware boundary in the
 * client surface; the loop above it is fully injectable and unit-tested.
 */
export interface MicHandle {
    /** Acquire the mic and begin streaming PCM16. Rejects on permission/hardware errors. */
    start(): Promise<void>;
    /** Stop capture, detach callbacks, and release microphone tracks and the audio context. Safe to call twice. */
    stop(): Promise<void>;
    /** Whether capture is currently running. */
    readonly running: boolean;
    /** Resume (or create) the audio context inside a user gesture (autoplay unlock). */
    unlock(): Promise<void>;
}
/**
 * Create a mic capture handle.
 * @param onPcm16 - receives each PCM16 chunk as a fresh `Uint8Array`.
 * @param sampleRate - provider PCM input clock in Hz; defaults to the requested sample rate.
 * @throws {Error} when getUserMedia or the audio graph is unavailable.
 */
export declare function createMicCapture(onPcm16: (pcm16: Uint8Array) => void, sampleRate?: number): MicHandle;
/** Convert an interleaved float32 buffer ([-1, 1]) to little-endian signed 16-bit PCM16. */
export declare function encodeFloatToPcm16(f32: Float32Array): Uint8Array;
