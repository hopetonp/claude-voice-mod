/** Shared opening envelope for PCM speech playback. */
/**
 * Ramp only the opening chunk of a reply from silence; callers own reply state.
 * @param samples - decoded PCM samples, modified in place.
 * @param frames - maximum fade length at the output sample rate; zero disables it.
 */
export declare function fadePcmOpening(samples: Float32Array, frames: number): void;
