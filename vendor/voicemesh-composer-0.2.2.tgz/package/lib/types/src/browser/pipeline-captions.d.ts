/** One visible prefix of a spoken response. */
export interface SpeechCaption {
    text: string;
    phase: 'start' | 'update' | 'final';
    interrupted: boolean;
}
/**
 * Keep persistence off the audio scheduling path while retaining the final heard prefix.
 * @param position - Audio-device progress since the response began.
 * @param charactersPerSecond - Shared caption estimate during synthesis.
 * @param write - Persist a caption using the response's stable identity.
 * @returns Text, synthesis-completion, and playback-completion callbacks.
 */
export declare function createPipelineCaptions(position: () => {
    playedMs: number;
    durationMs: number;
}, charactersPerSecond: number, write: (caption: SpeechCaption) => Promise<void>): {
    append(chunk: string): void;
    generated(): void;
    finish(interrupted: boolean): Promise<void>;
};
