/** Browser composition extracted from DeepSeek's pipeline controller. */
import { type VoiceLoop, type VoiceLoopHost, type VoiceLoopOptions, type VoiceLoopRead, type VoiceRuntimeStore } from '../pipeline.ts';
import { type MicHandle } from './mic.ts';
export interface BrowserPipelineOptions extends VoiceLoopOptions {
    /** Inject a capture for deterministic tests or an alternative browser device. */
    capture?: (feed: (pcm16: Uint8Array) => void, sampleRate: number) => MicHandle;
    /** Release the host's playback device after microphone capture ends. */
    closeAudio?: () => Promise<void>;
}
/** Bind Composer's voice loop to browser capture, retaining standby/resume behavior. */
export declare function createBrowserPipelineController(host: VoiceLoopHost, store: VoiceRuntimeStore, read: () => VoiceLoopRead, options?: BrowserPipelineOptions): {
    loop: VoiceLoop;
    close(): Promise<void>;
};
