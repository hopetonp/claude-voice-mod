import { type SpeechCaption } from './pipeline-captions.ts';
/** Application-owned synthesis transport; audio chunks can split PCM samples. */
export interface PipelinePlaybackOptions {
    synthesize(text: string, audio: (pcm: Uint8Array, sampleRate: number) => void, signal: AbortSignal): Promise<void>;
    synthesizeStream?(texts: AsyncIterable<string>, audio: (pcm: Uint8Array, sampleRate: number) => void, signal: AbortSignal): Promise<void>;
    caption(caption: SpeechCaption, responseId: string): Promise<void>;
    charactersPerSecond: number;
    cueVolume: number;
    outputVolume?(): number;
    cueStarted?(): void;
}
/** Persistent response and listener sinks with shared interruption and caption behavior.
 * @param options - Application synthesis and caption projection.
 * @returns Playback operations for the pipeline host.
 */
export declare function createPipelinePlayback(options: PipelinePlaybackOptions): {
    unlock: () => Promise<void>;
    play: (texts: AsyncIterable<string> | Iterable<string>, started?: () => void, signal?: AbortSignal, quiet?: boolean, caption?: (caption: SpeechCaption, responseId: string) => Promise<void>, nativeStream?: boolean) => Promise<void>;
    cue(text: string, signal?: AbortSignal, started?: () => void): Promise<void>;
    stopCue(): void;
    stop(): void;
    close(): Promise<void>;
};
