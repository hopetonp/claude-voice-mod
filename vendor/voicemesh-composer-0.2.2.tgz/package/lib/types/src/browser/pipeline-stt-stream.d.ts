/** Browser recognition stream extracted from DeepSeek's pipeline transport. */
import type { SttStreamHandle } from '../pipeline.ts';
/** Connect to an authenticated harness WebSocket backed by a Composer recognizer. */
export declare function openPipelineSttStream(url: string, signal?: AbortSignal, timeoutMs?: number): Promise<SttStreamHandle>;
