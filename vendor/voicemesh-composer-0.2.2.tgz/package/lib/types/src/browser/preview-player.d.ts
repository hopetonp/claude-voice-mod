/** Streaming PCM preview playback independent of UI and provider transport. */
export interface PreviewSample {
    readonly audio: string;
    readonly sampleRate: number;
}
/** One cancellable preview; completion includes the last scheduled audio sample. */
export declare class VoicePreviewPlayer {
    private readonly request;
    private readonly audio;
    private readonly drained;
    private pending;
    private complete;
    private nextStart;
    private closing;
    /** @param createContext - browser device factory, replaceable for testing. */
    constructor(createContext?: () => AudioContext);
    /**
     * Play provider audio as it arrives and wait for device playback to finish.
     * @param generate - application-authorized synthesis transport.
     * @param started - notification after audio has been scheduled.
     * @param volume - Playback gain; listener cues may use a quieter level.
     * @returns completion after playback, cancellation, or a synthesis failure.
     */
    play(generate: (signal: AbortSignal, append: (sample: PreviewSample) => void) => Promise<void>, started: () => void, volume?: number): Promise<void>;
    /** Abort synthesis and release the device; repeated calls share completion. */
    close(): Promise<void>;
}
