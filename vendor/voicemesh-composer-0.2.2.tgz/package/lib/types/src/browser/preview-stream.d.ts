/** Read the shared PCM preview response incrementally for browser playback. */
export interface PcmPreviewSample {
    audio: string;
    sampleRate: number;
}
/** Deliver each complete PCM16 chunk before the HTTP response finishes. */
export declare function readPcmPreview(response: Response, onAudio: (sample: PcmPreviewSample) => void, signal?: AbortSignal, maxBytes?: number): Promise<void>;
