import type { VadEvent } from '@fluidinference/fluidvad';
import { EnergyVad, type Vad, type VadEvent as CoreVadEvent } from '../vad.ts';
/** A minimal console-style logger (via the harness `ctx.logger`, else `console`). */
export interface VoiceLogger {
    warn(...args: unknown[]): void;
    error(...args: unknown[]): void;
    info(...args: unknown[]): void;
    debug?(...args: unknown[]): void;
}
export interface SileroVadOptions {
    /** Sample rate of the incoming stream; detection input is converted to the model’s 16 kHz clock. */
    sampleRate?: number;
    /** Minimum normalised speech probability to declare speech (Silero default 0.5). */
    threshold?: number;
    /** Silence (ms) after the last voiced frame before emitting `utteranceEnd`. */
    silenceMs?: number;
    /** Optional prebuilt classifier (tests inject a fake; omitted → the FluidVad runner). */
    runner?: SileroRunner;
    /** Optional runner factory override (tests inject a throwing one to exercise the fallback). */
    createRunner?: (opts: {
        threshold: number;
        silenceMs: number;
    }) => Promise<SileroRunner>;
    /** Logger for degrade/error diagnostics. Defaults to `console`. */
    logger?: VoiceLogger;
    /** Report VAD health (ready vs. degraded) so the UI can surface it. */
    onVadStatus?: (status: {
        engine: 'silero' | 'energy';
        degradedReason: string | null;
    }) => void;
}
/** The 512-sample Silero inference window (32 ms at 16 kHz, 64 ms at 8 kHz). */
export declare const SILERO_WINDOW_SAMPLES = 512;
/**
 * The loop-facing boundary-event classifier behind {@link SileroVad}: feed
 * normalized samples, get back `{type:'speechStart'}` / `{type:'utteranceEnd'}`
 * events as they're decided. Tests inject a fake; the real one wraps a FluidVad.
 */
export interface SileroRunner {
    /** Feed a chunk of normalized samples and return boundary events emitted for it. */
    push(samples: Float32Array): CoreVadEvent[];
    /** Clear the threaded state (called on a VAD reset). */
    reset(): void;
    /** Release the underlying model/runtime. */
    dispose(): void;
}
export declare class SileroVad implements Vad {
    readonly sampleRate: number;
    private readonly threshold;
    private readonly silenceMs;
    private readonly windowSize;
    private readonly injectedRunner;
    private readonly createRunner;
    private readonly logger;
    private readonly onVadStatus;
    private runner;
    private runnerPromise;
    /**
     * If Silero cannot load (WASM unavailable / bundler restriction / offline) we
     * fall back to the core energy VAD by delegating the whole feed/onEvent
     * contract to it, so the voice loop never stops detecting speech.
     */
    private energyVad;
    /** Pending boundary events queued until the runner resolves a `speechStart`. */
    private resamplePhase;
    private inSpeech;
    private closed;
    private readonly listeners;
    constructor(options?: SileroVadOptions);
    onEvent(listener: (event: CoreVadEvent) => void): () => void;
    get inSpeechNow(): boolean;
    reset(): void;
    close(): void;
    /** The cached energy-fallback runner (created once when Silero fails to load). */
    private energyRunnerCache;
    /** Get (or lazily start) the boundary-event runner; on failure, switch to the energy VAD. */
    ready(): Promise<SileroRunner>;
    /**
     * Eagerly start the model load (and report the resulting VAD status) so the
     * UI can show "silero / energy (degraded)" without waiting for the first
     * audio feed. Fire-and-forget; safe to call multiple times. Returns a promise
     * so callers can await readiness if needed.
     */
    warm(): Promise<SileroRunner>;
    /** An energy-VAD-backed runner (the fallback) that emits boundaries itself. */
    private energyRunner;
    feed(samples: ArrayLike<number>): void;
    private forward;
}
/**
 * Build a {@link SileroRunner} backed by a FluidVad. FluidVad already buffers
 * partial frames and emits its own `{isStart/isEnd,...}` boundaries, so we
 * translate each boundary into the loop-facing `speechStart`/`utteranceEnd`
 * events. Its internal `minSpeechDuration`/`minSilenceDuration` (hysteresis +
 * hangover) replace a hand-rolled onset/silence state machine here.
 */
export declare function createFluidRunner(opts: {
    threshold: number;
    silenceMs: number;
    wasmBytes?: Uint8Array;
}): Promise<SileroRunner>;
/** CDN sources for the Silero VAD wasm (pinned version; jsDelivr primary, unpkg fallback). */
export declare const FLUIDVAD_WASM_URLS: readonly ["https://cdn.jsdelivr.net/npm/@fluidinference/fluidvad@0.2.0/dist/fluidvad_bg.wasm", "https://unpkg.com/@fluidinference/fluidvad@0.2.0/dist/fluidvad_bg.wasm"];
export type { VadEvent };
export type { EnergyVad };
