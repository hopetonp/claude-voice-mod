/**
 * Clean sentence segments, retaining unresolved syntax until continuation or completion.
 * Code and table content survive cleanup; raw HTML follows strip-markdown's removal policy.
 * @param texts - Sentence segments supplied by the pipeline, or a complete read-back.
 * @returns Plain speech segments, also used as the playback caption source.
 */
export declare function speechMarkdown(texts: AsyncIterable<string> | Iterable<string>): AsyncGenerator<string>;
