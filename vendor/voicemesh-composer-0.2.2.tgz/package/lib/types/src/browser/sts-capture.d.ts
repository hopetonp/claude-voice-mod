/**
 * Load the audio processor and create a disconnected microphone node.
 * @param context - owned microphone context at the negotiated PCM rate.
 * @param frames - validated batching size, between 128 and 16384 frames.
 * @param sampleRate - negotiated provider input rate.
 * @returns node whose port emits mono Float32Array batches.
 */
export declare function createStsCapture(context: AudioContext, frames: number, sampleRate?: number): Promise<AudioWorkletNode>;
