/** Browser STS microphone, provider connection, and scheduled playback lifetime. */
import type { createVoiceLifecycle, VoiceLifecycleSink } from '../voice-lifecycle.ts';
import type { StsWebRtcAdapter } from './sts-webrtc.ts';
/**
 * Whether one captured microphone batch carries speech.
 * @param samples - mono float samples from the microphone.
 * @returns true when the batch's average loudness is at speech level.
 */
export declare function inputHasSpeech(samples: Float32Array): boolean;
/** Playback evidence for one result supplied to a native Live session. */
export interface LiveResultPlayback {
    readonly turn: number;
    readonly accepted: boolean;
    readonly idleBaseline: boolean;
    readonly started: boolean;
    readonly ended: boolean;
    readonly caption: boolean;
}
/** Begin retaining result playback evidence before the provider acknowledges its command. */
export declare function pendingLiveResultPlayback(turn: number, liveOutputSpeaking: boolean): LiveResultPlayback;
/** Apply one browser observation to a pending result playback record. */
export declare function observeLiveResultPlayback(playback: LiveResultPlayback, event: 'accepted' | 'caption' | {
    readonly speaking: boolean;
}): LiveResultPlayback;
/** Whether the browser observed a complete, captioned result response after its delivery was accepted. */
export declare function liveResultPlaybackSettled(playback: LiveResultPlayback): boolean;
/** Resolved browser timing and playback limits; application settings may extend these. */
export interface RealtimeSettings {
    muted: boolean;
    /** Whether the speaker is muted; read live, so a toggle applies without reconnecting. */
    speakerMuted?: boolean;
    stsSchedulingLeadSeconds: number;
    stsMaxQueuedSeconds: number;
    stsMaxResponseSeconds: number;
    stsFadeInSeconds: number;
    stsCaptionCharactersPerSecond: number;
    stsMaxQueuedBytes: number;
    stsCloseTimeoutMs: number;
    stsConnectTimeoutMs: number;
    stsCaptureFrames: number;
}
/** Provider media negotiation, without credentials or application identity. */
export interface RealtimeProvider {
    provider: string;
    transport: 'websocket' | 'webrtc';
    inputSampleRate: number;
    outputSampleRate: number;
    nativePlayback: boolean;
    rtcAdapter?: () => StsWebRtcAdapter;
}
/** Application signaling and transcript projection around the voice controller. */
export interface RealtimeApplication<Settings extends RealtimeSettings, Id extends string> {
    /** Localized notice for rejected or unconfirmed context; the conversation stays connected. */
    commandFailureText: string;
    resolve(settings: Settings): RealtimeProvider;
    socket(): WebSocket;
    start(id: Id, settings: Settings, provider: RealtimeProvider, offer?: string): Readonly<Record<string, unknown>>;
    refresh(settings: Settings): Readonly<Record<string, unknown>>;
    /** Subscribe after provider readiness, publishing initial facts synchronously; disposer releases the observation. */
    watchContext?(id: Id, provider: RealtimeProvider, send: (event: Readonly<Record<string, unknown>>) => void): () => void;
    canEnd(settings: Settings): boolean;
}
/** Application-owned runtime view. */
export interface RealtimeStateSink extends VoiceLifecycleSink {
    setTranscript(text: string): void;
    setLastReply(text: string): void;
    /**
     * Optional transient, non-failure notice. Used for a recoverable command
     * outcome, where nothing is replayed and the session stays live: the
     * application shows it briefly instead of entering a failure state. Absent →
     * recoverable outcomes use {@link setError} like every other outcome.
     */
    setNotice?(message: string): void;
}
/** One command acceptance outcome as the channel reports it, without provider text. */
export interface StsCommandOutcomeReport {
    /** Provider acceptance of one acknowledged command. */
    readonly status: 'accepted' | 'rejected' | 'unknown';
    /** Sanitized local reason: an acknowledgment timeout, a queue limit, or a transport outcome. */
    readonly code: string | null;
}
/**
 * Whether a non-accepted command outcome is recoverable rather than a failure.
 * A command the provider never confirmed inside its deadline, or one refused
 * because the pending-command queue was saturated, costs only that update: it is
 * never replayed and the session stays live. A provider refusal or a session
 * that closed while the command waited is not recoverable.
 * @param outcome - acceptance evidence reported by the channel.
 */
export declare function commandOutcomeIsRecoverable(outcome: StsCommandOutcomeReport): boolean;
/** The failing step of a realtime session, reported to the application for diagnostics. */
export type StsFailureReason = 
/** The browser signaling socket failed. */
'socket'
/** The signaling socket closed; the close code and reason follow as detail. */
 | 'socket-closed'
/** Activation failed while acquiring media or opening the provider session. */
 | 'start'
/** The WebRTC answer was rejected or timed out. */
 | 'signaling'
/** A browser media device refused or stopped. */
 | 'media'
/** The playback engine failed. */
 | 'playback'
/** Web Audio setup (context, worklet, or processor) failed. */
 | 'audio'
/** A provider event did not match the documented protocol. */
 | 'protocol'
/** Session renewal failed; the failed step follows as detail. */
 | 'renew'
/** The host reported a channel error. */
 | 'channel'
/** The provider reported that the connection was lost. */
 | 'connection-lost'
/** Caption or playback bookkeeping failed. */
 | 'caption'
/** The outbound queue exceeded its configured limit. */
 | 'queue';
/** One realtime failure: a stable reason plus bounded transport evidence. */
export interface StsFailure {
    /** The failing step. */
    readonly reason: StsFailureReason;
    /** Transport evidence such as a socket close code, DOMException name, or the failed renewal step. */
    readonly detail?: string;
}
/** Application-supplied failure wording, either fixed text or composed from the reported reason. */
export type StsFailureText = string | ((failure: StsFailure) => string);
/** Realtime browser controller with application-owned signaling. */
export interface StsController<SessionId extends string = string> {
    /**
     * Start voice for the user-selected Session.
     * @param sessionId - application conversation.
     * @param source - read-back suppresses the connection chime; omitted for user activation.
     * Activity observations preserve connecting status until microphone, media, and provider setup complete.
     * @returns readiness after microphone and provider setup.
     */
    start(sessionId: SessionId, source?: 'read-back'): Promise<void>;
    /** Stop realtime voice and release its browser audio resources without changing another mode's state.
     * @returns completion after pending acquisition and release.
     */
    stop(): Promise<void>;
    /**
     * Park immediately (manual pause): close the live provider session and stop
     * its audio without ending voice, so the elapsed clock and the session binding
     * survive and the next `start` resumes them. Applies while a reply is still
     * playing, which the inactivity deadline never does.
     */
    standby(): void;
    /**
     * Read saved output through STS without starting application work.
     * @param sessionId - application conversation.
     * @param turn - completed turn for automatic result delivery; omitted for manual last-output read-back.
     * @returns completion after sending the request.
     */
    readBackOutput(sessionId: SessionId, turn?: number): Promise<void>;
    /** Apply changes to the inactivity duration without reconnecting. */
    settingsChanged(): void;
}
/**
 * Create an STS controller without acquiring browser resources until a user gesture.
 * @param config - current normalized settings, including live mute state.
 * @param voice - runtime state shared with the microphone dock.
 * @param failureText - localized terminal connection error, or a formatter that includes the reported reason.
 * @param watchCompletion - subscribes to completed application turns; its disposer releases the subscription.
 * @param transcriptionFailureText - localized warning when speech continues without an input caption.
 * @param lifecycle - shared lifecycle implementation for status, timing, and feedback.
 * @param application - provider resolution and application signaling.
 * @returns the start/stop controller.
 */
export declare function createStsController<Settings extends RealtimeSettings, SessionId extends string>(config: () => Settings, voice: RealtimeStateSink, failureText: StsFailureText, watchCompletion: (sessionId: SessionId, notify: (turn: number) => void) => () => void, transcriptionFailureText: string, lifecycle: ReturnType<typeof createVoiceLifecycle>, application: RealtimeApplication<Settings, SessionId>): StsController<SessionId>;
