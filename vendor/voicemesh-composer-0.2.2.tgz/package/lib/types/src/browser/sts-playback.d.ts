declare const voiceIdentity: unique symbol;
type Branded<Name extends string> = string & {
    readonly [voiceIdentity]: Name;
};
/** Provider response identity; the wire parser owns validation. */
export type StsResponseId = Branded<'voice-sts-response'>;
/** Provider conversation item identity; the wire parser owns validation. */
export type StsItemId = Branded<'voice-sts-item'>;
/** Played prefix of one provider audio content part. */
export interface StsPlaybackPosition {
    readonly itemId: StsItemId;
    readonly contentIndex: number;
    readonly receivedFrames: number;
    /** Conservative device-rendered prefix, rounded down to whole milliseconds. */
    readonly audioEndMs: number;
}
/** Per-connection playback limits, resolved from voice configuration. */
export interface StsPlaybackLimits {
    readonly sampleRate: number;
    /** Scheduling headroom for initial audio and recovery after a buffer underrun. */
    readonly schedulingLeadSeconds: number;
    /** Opening and post-underrun recovery fade duration; never applied at contiguous chunk boundaries. */
    readonly fadeInSeconds: number;
    readonly maxQueuedSeconds: number;
    readonly maxResponseSeconds: number;
}
/** One audio output connection; response changes require an explicit stop. */
export declare class StsPlayback {
    private readonly limits;
    private readonly onError;
    private readonly createContext;
    private readonly volume;
    private context;
    private response;
    private segments;
    private pending;
    private stoppedPositions;
    private readonly sources;
    private readonly meters;
    private gain;
    private nextStart;
    private receivedFrames;
    private closed;
    private closing;
    /**
     * @param limits - negotiated sample rate and bounded buffering policy.
     * @param onError - owner notification when asynchronous device scheduling fails.
     * @param createContext - browser AudioContext factory, replaceable by a device fixture.
     * @param volume - output amplitude sampled as each chunk is scheduled; 0 mutes the speaker.
     */
    constructor(limits: StsPlaybackLimits, onError: () => void, createContext?: () => AudioContext, volume?: () => number);
    /**
     * Resume output inside the user's microphone or playback gesture.
     * @returns completion after the audio context is running.
     */
    unlock(): Promise<void>;
    /**
     * Arm a fresh provider response after the previous response was stopped.
     * @param responseId - response whose audio may be scheduled.
     */
    begin(responseId: StsResponseId): void;
    /**
     * Buffer PCM16 within the response quota and schedule a bounded window ahead of playback.
     * @param responseId - originating response; obsolete responses are ignored.
     * @param itemId - provider conversation item owning the audio.
     * @param contentIndex - provider audio content part within the item.
     * @param pcm - sample-aligned little-endian mono PCM16.
     * @returns false for obsolete output, otherwise true after accepting the audio.
     */
    push(responseId: StsResponseId, itemId: StsItemId, contentIndex: number, pcm: Uint8Array): boolean;
    private pump;
    private schedule;
    /**
     * Read the played prefix without counting future scheduled samples.
     * @returns one position per item/content pair in first-arrival order.
     */
    position(): readonly StsPlaybackPosition[];
    /** Whether every received sample has reached the output device. */
    get drained(): boolean;
    /**
     * Silence all scheduled sources and invalidate the response before late callbacks.
     * @returns playback positions captured before stopping the sources.
     */
    stop(): readonly StsPlaybackPosition[];
    /**
     * Stop playback and release the browser audio device; repeated calls share completion.
     * @returns completion after the owned AudioContext closes.
     */
    close(): Promise<void>;
    private assertOpen;
    private deviceTime;
}
export {};
