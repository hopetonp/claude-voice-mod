/** OpenAI data-channel events translated for the shared STS controller. */
import type { StsWebRtcAdapter } from './sts-webrtc.ts';
/** @returns a connection-local OpenAI event adapter. */
export declare function createOpenaiWebRtcAdapter(): StsWebRtcAdapter;
