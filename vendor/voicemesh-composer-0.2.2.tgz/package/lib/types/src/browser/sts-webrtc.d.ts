/** Provider-independent browser WebRTC audio, signaling, and resource lifetime. */
/** Provider data-channel naming and connection-local event translation. */
export interface StsWebRtcAdapter {
    readonly channelLabel: string;
    readonly activity?: {
        readonly pollMs: number;
        readonly threshold: number;
        readonly idleMs: number;
    };
    /** Translate provider events. @param event - parsed wire JSON. @returns normalized controller events. */
    decode(event: unknown): readonly Readonly<Record<string, unknown>>[];
}
/** Browser media transport; the controller owns conversation and standby state. */
export declare class StsWebRtcMedia {
    private readonly outputMuted;
    private readonly peer;
    private readonly audio;
    private readonly data;
    private stream;
    private inputMeter;
    private outputMeter;
    private closed;
    private suspended;
    private startedAt;
    private played;
    private ended;
    private readonly connected;
    private activityTimer;
    /**
     * @param adapter - provider event translation.
     * @param receive - shared controller events.
     * @param fail - owner failure notification.
     * @param outputMuted - live speaker-mute state, sampled while the call runs; the
     * remote track is played through this class's own audio element, so muting it here
     * is the only way the application can silence the speaker without closing the call.
     */
    constructor(adapter: StsWebRtcAdapter, receive: (event: Readonly<Record<string, unknown>>) => void, fail: () => void, outputMuted?: () => boolean);
    /**
     * Acquire microphone tracks and create SDP.
     * @param muted - initial microphone setting.
     * @returns browser SDP offer.
     */
    offer(muted: boolean): Promise<string>;
    /**
     * Apply provider SDP and await media readiness.
     * @param sdp - provider answer.
     * @param timeoutMs - media connection deadline.
     * @returns connected media readiness.
     */
    answer(sdp: string, timeoutMs: number): Promise<void>;
    /** Update microphone transmission. @param muted - whether microphone tracks are disabled. */
    mute(muted: boolean): void;
    /** Reset timing for the next response. */
    begin(): void;
    /** Mark provider playback start. */
    startPlayback(): void;
    /** Mark provider playback completion or interruption. */
    stopPlayback(): void;
    /** Approximate playback progress; provider events and media tracks have separate clocks. */
    get elapsedMs(): number;
    /** Whether the provider output buffer has stopped. */
    get drained(): boolean;
    /** Stop capture and local playback while retaining transports for provider finalization. */
    suspend(): void;
    /** Apply the live speaker-mute state to the remote audio element. */
    private applyOutputMute;
    /** Release microphone, remote audio, data channel, and peer connection. */
    close(): void;
}
