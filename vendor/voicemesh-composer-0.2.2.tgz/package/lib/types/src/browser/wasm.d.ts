/**
 * Helpers to load the VAD/AEC wasm bytes. We fetch them from a CDN (jsDelivr
 * primary, unpkg fallback) at runtime rather than inlining them — the inlined
 * approach bloated the plugin bundle ~30×. Both CDNs serve these wasm files
 * with `content-type: application/wasm` and `access-control-allow-origin: *`,
 * so a browser can `fetch()` and instantiate them.
 *
 * Production uses {@link fetchWasmBytes}; tests inject bytes directly.
 */
/** Decode a base64 string into a Uint8Array (browser + Node-safe, no node types). */
export declare function base64ToBytes(base64: string): Uint8Array;
/** Accepts a base64 string OR an already-decoded Uint8Array (idempotent). */
export declare function resolveWasm(base64OrBytes: string | Uint8Array): Uint8Array;
/**
 * Fetch wasm bytes from a list of CDN URLs (jsDelivr primary, unpkg fallback).
 * Returns the first that succeeds; throws if all fail. The wasm is immutable per
 * pinned version, so the browser caches it and it is fetched at most once.
 */
export declare function fetchWasmBytes(urls: readonly string[]): Promise<Uint8Array>;
