/** Transport-neutral, optional question the voice model can ask before routing speech. */
export declare const spokenRequestClassifierTool: {
    type: "function";
    name: string;
    description: string;
    parameters: {
        type: string;
        properties: {
            utterance: {
                type: string;
                description: string;
            };
        };
        additionalProperties: boolean;
    };
};
export type SpokenRequestRoute = 'voice' | 'coding' | 'clarify';
