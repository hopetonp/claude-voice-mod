/**
 * The end-of-turn semantic gate.
 *
 * Recognizers without a native streaming endpoint signal (Whisper, Deepgram
 * REST) finalize eagerly at each pause. These two predicates decide whether a
 * transcript fragment is genuinely a finished utterance (and should be
 * committed) or a mid-thought pause (and should keep listening).
 *
 * Ported from the Flutter `voice_provider.dart`. The constants and rules are
 * the hard-won part:
 *
 * - **Incomplete-clause flags only STRONGLY-incomplete endings**, so complete
 *   commands and barge-ins ("stop", "wait", "go ahead and check") still
 *   finalize instead of being silently held open.
 * - **Verbs are deliberately excluded** from the incomplete-last-words set,
 *   because commands and barge-ins routinely end on them. "do/does/did" too —
 *   they often end complete clauses ("I do", "please do").
 * - **Non-speech only triggers when stripping hallucination markers leaves no
 *   real words**, so a genuine sentence that merely contains a parenthetical
 *   is not discarded.
 */
/** Whether `text` sounds like an incomplete clause (the speaker paused mid-thought). */
export declare function isIncompleteClause(text: string): boolean;
/** Whether `text` is a hallucinated description of non-speech audio, not words. */
export declare function looksLikeNonSpeech(text: string): boolean;
