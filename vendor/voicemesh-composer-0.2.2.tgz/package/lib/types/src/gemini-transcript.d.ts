/**
 * Gemini reports transcription in pieces that normally continue what it already sent, but a report
 * can also restate it. Gluing every report together fabricates words, so only a genuine continuation
 * extends the text.
 */
/**
 * Merge one reported transcript into the text already on screen.
 * The provider reports a turn in pieces that normally continue what it sent, but a report can also
 * restate it (a superset, which replaces it) or repeat a prefix already shown (which adds nothing).
 * Gluing every report together fabricates words, so only a genuine continuation extends the text.
 * @param current - text already displayed for the turn.
 * @param reported - text just reported.
 * @returns the text to display, or undefined when the report adds nothing.
 */
export declare function mergeTranscriptText(current: string, reported: string): string | undefined;
