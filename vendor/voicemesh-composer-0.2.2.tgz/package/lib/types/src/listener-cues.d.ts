/** Playback admission and audible context for model-generated listener cues. */
export declare class ListenerCues {
    private pending;
    private admission;
    private generation;
    private played;
    private turnCues;
    /** Allow phrases again for the next user turn. */
    finishTurn(): void;
    /** Cues that reached the output device, oldest first. */
    get recent(): readonly string[];
    /** Invalidate a queued cue without forgetting audible context. */
    cancel(): void;
    /** Begin a new conversation. */
    reset(): void;
    /** Admit one cue; playback resolves at its end and confirms device start explicitly. */
    play(text: string, playback: (text: string, started: () => void) => Promise<void>, observe?: (event: 'cue' | 'cue-suppressed' | 'cue-played') => void): Promise<void>;
}
