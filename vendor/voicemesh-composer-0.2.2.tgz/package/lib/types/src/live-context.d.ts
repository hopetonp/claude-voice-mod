/** Bounded, replaceable application facts delivered independently of audio and task admission. */
import type { LiveContextTiming } from './live-delegation.ts';
/** Coalesce context snapshots; failed sends are reported once and never retried automatically. */
export declare class LiveContext {
    private readonly send;
    private readonly signal;
    private readonly timing;
    private readonly maxBytes;
    private readonly fail;
    private latest;
    private sent;
    private generation;
    private quiet;
    private deadline;
    private tail;
    private sending;
    private pending;
    private closed;
    private readonly abort;
    /**
     * @param send - persists and transmits a complete snapshot, checking eligibility for each chunk.
     * @param signal - connection lifetime.
     * @param timing - quiet interval and maximum burst delay.
     * @param maxBytes - retained UTF-8 snapshot limit.
     * @param fail - delivery failure callback; receives no context contents.
     * @param initialText - context already included in session creation; unchanged facts are not appended again.
     */
    constructor(send: (text: string, eligible: () => boolean) => Promise<void>, signal: AbortSignal, timing: LiveContextTiming, maxBytes: number, fail: () => void, initialText?: string);
    /** Replace pending facts without dispatching work. @param text - complete snapshot within the configured byte limit. */
    update(text: string): void;
    private clear;
    private flush;
    /** Stop timers and wait for any active delivery; application work is unaffected. @returns quiescent delivery. */
    close(): Promise<void>;
}
