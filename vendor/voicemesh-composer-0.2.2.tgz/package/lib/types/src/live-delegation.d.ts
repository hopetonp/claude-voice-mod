import type { StsMessage } from './server/sts-provider.ts';
import type { SpokenRequestRoute } from './classification-tool.ts';
/** Application work receipts and terminal results. */
export interface LiveTaskState {
    readonly requestId: string;
    readonly status: string;
    readonly text: string;
    /** Application revision invalidated by corrections or cancellation. */
    readonly revision: number;
    /** Revision consumed by the work that produced text; null when no result exists. */
    readonly resultRevision: number | null;
}
/** Resolved context quiet interval and maximum wait; silence is not a provider turn boundary. */
export interface LiveContextTiming {
    readonly waitMs: number;
    readonly quietMs: number;
}
/** Application owns admission, steering, and work lifetime independently of voice. */
export interface LiveTasks {
    dispatch(id: string, input: {
        instruction: string;
    }, signal: AbortSignal): Promise<{
        requestId: string;
    }>;
    steer(id: string, input: {
        instruction: string;
    }, signal: AbortSignal): Promise<unknown>;
    states(): readonly LiveTaskState[];
}
/** Application-owned transcript projection or persistence. */
export interface LiveTranscriptSink {
    recordTranscript(role: 'user' | 'assistant', text: string, signal: AbortSignal, id: string, phase: 'start' | 'update' | 'final'): Promise<unknown>;
}
/** Application wording and task instructions; the voice runtime supplies no coding policy. */
export interface LiveDelegationPolicy {
    request(lines: readonly {
        role: string;
        text: string;
    }[]): string;
    readonly missingTranscript: string;
    readonly accepted: string;
    readonly rejected: string;
    result(state: LiveTaskState): {
        context: string;
        speech: string;
    };
    /** Optional application-configured routing advice before coding work is admitted. */
    readonly classification?: {
        classify(utterance: string, context: string, signal: AbortSignal): Promise<SpokenRequestRoute>;
        readonly voice: string;
        readonly clarify: string;
        readonly unavailable: string;
    };
}
/** One Live connection's fragments and deduplicated backend requests. */
export declare class LiveDelegation {
    private readonly tasks;
    private readonly recording;
    private readonly send;
    private readonly signal;
    private readonly maxContextBytes;
    private readonly fail;
    private readonly policy;
    private readonly timing;
    private readonly delivery?;
    private readonly fragments;
    private readonly seen;
    private readonly recorded;
    private readonly assigned;
    private readonly delegated;
    private readonly requests;
    private readonly announced;
    private readonly suppliedResults;
    private readonly deliveringResults;
    private generation;
    private assistantResponse;
    private offset;
    private pending;
    private deadline;
    private quiet;
    private closed;
    private readonly abort;
    /** Application admissions stay serialized and never wait for provider acknowledgments. */
    private admissions;
    /** Model-facing updates share one serialized chain so their order stays stable. */
    private deliveries;
    /** Durable transcript writes preserve their order without pacing provider events. */
    private transcriptWrites;
    private readonly rows;
    /**
     * @param tasks - application work owner.
     * @param recording - application transcript sink.
     * @param send - authenticated sender that rechecks eligibility immediately before transmission.
     * @param signal - voice connection lifetime.
     * @param maxContextBytes - maximum retained transcript context.
     * @param fail - connection owner failure callback.
     * @param policy - application instructions and result presentation.
     * @param timing - bounded wait and quiet interval for delayed fragments.
     * @param delivery - application notification before transmission and after provider acceptance, not playback.
     */
    constructor(tasks: LiveTasks, recording: LiveTranscriptSink, send: (event: StsMessage & {
        event_id: string;
    }, eligible: () => boolean) => Promise<unknown>, signal: AbortSignal, maxContextBytes: number, fail: () => void, policy: LiveDelegationPolicy, timing: LiveContextTiming, delivery?: ((state: LiveTaskState, phase: "pending" | "accepted") => void) | undefined);
    /** Consume a provider fragment and return the current display row. @param event - validated Live event. @returns caption row. */
    transcript(event: StsMessage): Promise<StsMessage | undefined>;
    /** Persist one displayed fragment in order after returning its live caption. */
    private recordTranscript;
    /** Retain the latest backend request once; fragments alone never request work. @param event - delegation metadata. */
    delegate(event: StsMessage): void;
    /** Suppress pending admission and results superseded by input already routed by the application. */
    invalidate(): void;
    private clearPending;
    private contextReady;
    private scheduleContext;
    private admit;
    /** Queue one model-facing delivery behind earlier ones without blocking application admissions. */
    private deliver;
    /** Forward terminal results only while their application revision and delegation remain current. */
    completed(): Promise<void>;
    /** Send bounded plain-text context. @param type - Live append kind. @param id - delegation identity or null. @param text - content. @param eligible - checked for each transmitted chunk. */
    append(type: string, id: string | null, text: string, eligible?: () => boolean): Promise<boolean>;
    /** Discard waiting context, finish active admission, and finalize display rows without cancelling application work. */
    close(): Promise<void>;
}
