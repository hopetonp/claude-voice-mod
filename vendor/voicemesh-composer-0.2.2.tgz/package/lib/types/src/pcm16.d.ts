/**
 * Decode a chunk of signed 16-bit little-endian mono PCM (as an AudioWorklet
 * emits) into normalized floats in [-1, 1).
 *
 * Unlike `Int16Array`, this never throws on an unaligned buffer: it copies the
 * bytes to an aligned view first, then reads them via a DataView. The Flutter
 * original hit this bug — `Int16List.asInt16List` throws on odd offsets, and
 * audio workers hand back precisely such buffers.
 */
/** One normalized sample: little-endian high byte shifted, / 32768. */
export declare function sampleFromBytes(bytes: Uint8Array, offset: number): number;
/** Decode a whole PCM16 chunk into normalized floats, skipping byte 0 only. */
export declare function pcm16ToFloats(bytes: Uint8Array): Float32Array;
