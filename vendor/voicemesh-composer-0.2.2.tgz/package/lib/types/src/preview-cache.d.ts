/** Optional application storage for completed provider previews. */
export interface PreviewCache<Sample> {
    load(key: string): Promise<readonly Sample[] | undefined>;
    save(key: string, samples: readonly Sample[]): Promise<void>;
}
/** Incremental preview synthesis supplied by a provider or application transport. */
export type PreviewGenerator<Selection, Sample> = (selection: Selection, voice: string, signal: AbortSignal, append: (sample: Sample) => void) => Promise<void>;
/**
 * Cache only completed, uncancelled previews; storage failure leaves synthesis available.
 * @param generate - underlying preview synthesis.
 * @param cache - application persistence implementation.
 * @param identify - includes all synthesis settings that distinguish a preview.
 * @returns incremental cached preview generation.
 */
export declare function cachedPreviews<Selection, Sample>(generate: PreviewGenerator<Selection, Sample>, cache: PreviewCache<Sample>, identify: (selection: Selection, voice: string) => string): PreviewGenerator<Selection, Sample>;
