/**
 * Deepgram Aura speech synthesis.
 *
 * Two paths, matching the Flutter `aura_synthesizer.dart`:
 *
 * - **Aura-2 (`/v1/speak`, REST)** is one-shot per request, so the reply is
 *   pipelined sentence-by-sentence: request sentence i+1 while sentence i
 *   plays, so the first sentence starts immediately and the reply flows.
 * - **Flux TTS (`/v2/speak`, WebSocket)** is turn-based streaming: send the
 *   whole reply as one `Speak` then `Flush`, and play audio as it streams back,
 *   so prosody stays continuous (no per-sentence seams).
 *
 * The HTTP client, the WebSocket connect, and the playback sink are injected,
 * so the protocol (URL, headers, chunk pipelining, frame handling) is testable
 * without a network or audio hardware.
 */
import { type KeyReader, type SpeechSynthesizer, type WebSocketConnect } from './speech.ts';
/** How synthesis requests are sent. Injectable so tests need no network. */
export type HttpPost = (url: string, options: {
    headers: Record<string, string>;
    body: string;
}) => Promise<{
    status: number;
    bodyBytes: Uint8Array;
    body: string;
}>;
/** The sink that receives synthesized audio. Injectable. */
export type AudioSink = (audio: Uint8Array, mimeType: string) => void | Promise<void>;
export declare function auraSpeakUrl(voiceModel: string, speakPath?: string): string;
export declare function auraStreamUrl(voiceModel: string, speakPath?: string): string;
export declare const DEFAULT_AURA_VOICE = "flux-haley-en";
export declare class DeepgramAuraSynthesizer implements SpeechSynthesizer {
    readonly outputSampleRate = 24000;
    readonly id = "deepgram";
    readonly label = "Deepgram Aura (cloud)";
    private readonly keyReader;
    private readonly http;
    private readonly connect;
    private readonly sink;
    private readonly voiceModel;
    private readonly path;
    private stopped;
    private activeSocket;
    constructor(keyReader: KeyReader, http: HttpPost, sink: AudioSink, connect: WebSocketConnect, voiceModel?: string, speakPath?: string);
    availabilityProblem(): Promise<string | null>;
    speak(text: string, sink?: AudioSink): Promise<void>;
    /** Consume incremental text; Flux keeps one socket and flushes once per response. */
    speakStream(texts: AsyncIterable<string> | Iterable<string>, sink?: AudioSink): Promise<void>;
    /** Speak over the Flux TTS WebSocket: one turn, audio streamed back as generated. */
    private speakStreaming;
    stop(): void;
    dispose(): void;
}
