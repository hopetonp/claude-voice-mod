/**
 * Deepgram Flux streaming speech recognition.
 *
 * Flux is a distinct conversational STT model on `/v2/listen?model=flux-general-en`.
 * It emits `TurnInfo` frames with an `event` of `EndOfTurn`/`EagerEndOfTurn` and
 * `TurnResumed`, which drive turn-taking natively. It is multilingual, so the
 * incomplete-clause gate is not applied; only non-speech hallucinations are
 * dropped.
 *
 * Ported from the Flutter `flux_recognizer.dart`. The transport is injected, so
 * the protocol (URL, frame handling, cumulative-transcript rule) is testable
 * without a socket or an API key.
 */
import { type KeyReader, type RecognizedTurn, type TurnStreamingRecognizer, type WebSocketConnect } from './speech.ts';
/** The live turn-tracking URL: eot tuning drives native turn-taking. */
export declare const FLUX_LISTEN_URL: string;
/**
 * The one-shot batch URL used by `transcribe`/`checkEndpoint`: no end-of-turn
 * tuning. Flux finalizes the turn the moment the client sends `CloseStream`,
 * so the eot window never delays the final transcript (matching the Flutter
 * `fluxListenUrl()`, which omits the eot params).
 */
export declare const FLUX_LISTEN_BATCH_URL: string;
export declare class DeepgramFluxRecognizer implements TurnStreamingRecognizer {
    private readonly timeoutMs;
    readonly inputSampleRate = 16000;
    readonly id = "deepgram-flux";
    readonly label = "Deepgram Flux (cloud)";
    private readonly connect;
    private readonly keyReader;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, timeoutMs?: number);
    availabilityProblem(): Promise<string | null>;
    transcribe(pcm16: Uint8Array): Promise<string>;
    checkEndpoint(pcm16: Uint8Array): Promise<{
        text: string;
        isEndpoint: boolean;
    }>;
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
    /** Stream `pcm16` over one WebSocket and resolve when the stream closes. */
    private stream;
    dispose(): void;
}
