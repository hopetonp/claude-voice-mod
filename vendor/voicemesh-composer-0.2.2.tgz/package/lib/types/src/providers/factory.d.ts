/**
 * Resolve a provider from the config's engine id.
 *
 * This is the factory the plugin calls once it has a config and a key reader.
 * It keeps the rest of the codebase from ever importing a vendor directly — the
 * engine id is the only coupling, mirroring the Flutter `VoiceRegistry`.
 */
import type { SpeechRecognizer, SpeechSynthesizer, WebSocketConnect, KeyReader } from './speech.ts';
import { type HttpPost, type AudioSink } from './deepgram-aura.ts';
/** Build a recognizer for the selected provider.
 * @param engineId - recognition provider ID.
 * @param connect - authenticated socket transport.
 * @param keyReader - host credential reader.
 * @param model - selected model; required by OpenAI.
 * @returns provider recognizer, or null for an unknown engine.
 */
export declare function buildRecognizer(engineId: string, connect: WebSocketConnect, keyReader: KeyReader, model?: string): SpeechRecognizer | null;
/** Build a synthesizer for the selected provider.
 * @param engineId - synthesis provider ID.
 * @param connect - authenticated socket transport.
 * @param keyReader - host credential reader.
 * @param http - HTTP transport used by batch synthesis providers.
 * @param sink - receives generated PCM audio.
 * @param voiceModel - selected voice ID.
 * @param model - selected synthesis model; required by OpenAI.
 * @returns provider synthesizer, or null for an unknown engine.
 */
export declare function buildSynthesizer(engineId: string, connect: WebSocketConnect, keyReader: KeyReader, http: HttpPost, sink: AudioSink, voiceModel?: string, model?: string): SpeechSynthesizer | null;
