import type { AudioSink } from './deepgram-aura.ts';
import type { KeyReader, RecognizedTurn, SpeechSynthesizer, TurnStreamingRecognizer, WebSocketConnect } from './speech.ts';
/** Fish's upload API emits a final transcript after the local VAD finishes an utterance. */
export declare class FishRecognizer implements TurnStreamingRecognizer {
    private readonly keyReader;
    private readonly request;
    readonly inputSampleRate = 16000;
    readonly id = "fish";
    readonly label = "Fish Audio";
    private readonly lifetime;
    constructor(keyReader: KeyReader, request?: typeof fetch);
    availabilityProblem(): Promise<string | null>;
    transcribe(pcm: Uint8Array, signal?: AbortSignal): Promise<string>;
    checkEndpoint(pcm: Uint8Array): Promise<{
        text: string;
        isEndpoint: boolean;
    }>;
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
    dispose(): void;
}
/** One cancellable Fish synthesis turn, using the provider's default model. */
export declare class FishSynthesizer implements SpeechSynthesizer {
    private readonly connect;
    private readonly keyReader;
    private readonly sink;
    private readonly voice;
    readonly outputSampleRate = 44100;
    readonly id = "fish";
    readonly label = "Fish Audio";
    private active;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, sink: AudioSink, voice: string);
    availabilityProblem(): Promise<string | null>;
    speak(text: string, sink?: AudioSink): Promise<void>;
    speakStream(texts: AsyncIterable<string> | Iterable<string>, sink?: AudioSink): Promise<void>;
    stop(): void;
    dispose(): void;
}
