import type { KeyReader, RecognizedTurn, TurnStreamingRecognizer, SpeechSynthesizer, WebSocketConnect } from './speech.ts';
import type { AudioSink } from './deepgram-aura.ts';
/** Gemini's authenticated bidirectional speech endpoint. */
export declare const GEMINI_TRANSCRIPTION_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent";
/** Build the same transcription admission request for live audio and settings probes.
 * @param model - selected dedicated live transcription model.
 * @returns manual-turn, multilingual, verbatim transcription setup.
 */
export declare function geminiTranscriptionSetup(model: string): object;
/** Manual-turn recognition with interim hypotheses and authoritative finalized segments. */
export declare class GeminiRecognizer implements TurnStreamingRecognizer {
    private readonly connect;
    private readonly keyReader;
    private readonly model;
    readonly id = "gemini";
    readonly label = "Gemini";
    readonly inputSampleRate = 16000;
    private readonly lifetime;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, model: string);
    availabilityProblem(): Promise<string | null>;
    transcribe(pcm16: Uint8Array): Promise<string>;
    checkEndpoint(pcm16: Uint8Array): Promise<{
        text: string;
        isEndpoint: boolean;
    }>;
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
    dispose(): void;
}
/** Stream Gemini TTS PCM through the shared sentence synthesis and playback flow. */
export declare class GeminiSynthesizer implements SpeechSynthesizer {
    private readonly keyReader;
    private readonly sink;
    private readonly voice;
    private readonly model;
    readonly id = "gemini";
    readonly label = "Gemini";
    readonly outputSampleRate = 24000;
    private active;
    constructor(keyReader: KeyReader, sink: AudioSink, voice: string, model: string);
    availabilityProblem(): Promise<string | null>;
    private speak38;
    speak(text: string, sink?: AudioSink): Promise<void>;
    stop(): void;
    dispose(): void;
}
