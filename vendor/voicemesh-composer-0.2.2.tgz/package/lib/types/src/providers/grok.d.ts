/**
 * xAI Grok streaming speech recognition + synthesis.
 *
 * One provider pair under the shared xAI key:
 *   - **STT** (`/v1/stt`) is a turn-streaming recognizer: the voice loop keeps
 *     one persistent WebSocket open, streams live mic chunks, and drives
 *     turn-taking from Grok's own `transcript.partial`/`speech_final` events.
 *   - **TTS** (`/v1/tts`) streams audio back as base64 `audio.delta` chunks as
 *     it synthesizes the whole reply as one turn (`text.delta` then
 *     `text.done`), so prosody stays continuous. A `{type:'audio.done'}`
 *     completes the turn.
 *
 * Both authenticate with `Authorization: Bearer <key>`. The transport is
 * injected (WebSocketConnect + KeyReader + AudioSink), so the protocol is
 * testable without a socket or a secret.
 *
 * Ported from the Flutter `grok/grok_recognizer.dart` + `grok/grok_synthesizer.dart`.
 */
import { type KeyReader, type RecognizedTurn, type SpeechSynthesizer, type TurnStreamingRecognizer, type WebSocketConnect } from './speech.ts';
import type { AudioSink } from './deepgram-aura.ts';
/** The default Grok TTS voice id. */
export declare const DEFAULT_GROK_VOICE = "eve";
/** One Grok TTS voice: its `voice_id` plus display metadata. */
export interface GrokVoice {
    readonly id: string;
    readonly name: string;
    readonly tone: string;
}
/** The Grok TTS voice catalog (id, name, and tone from xAI's voice table). */
export declare const GROK_VOICES: readonly GrokVoice[];
/** The one-shot batch STT URL (no end-of-turn tuning). */
export declare const GROK_LISTEN_URL = "wss://api.x.ai/v1/stt?sample_rate=16000&encoding=pcm&language=en";
/** The persistent turn-streaming URL: interim results + Grok's native
 * end-of-turn detection (mirrors Deepgram Flux's turn-holding). */
export declare function grokTurnUrl(vadSilenceSec: number): string;
/** The streaming TTS URL for a given voice. */
export declare function grokTtsUrl(voice: string): string;
/**
 * xAI Grok streaming speech recognition (`/v1/stt`). A
 * `TurnStreamingRecognizer` for live captioning + native turn-taking, plus the
 * one-shot `transcribe`/`checkEndpoint` for batch / VAD fallback.
 */
export declare class GrokRecognizer implements TurnStreamingRecognizer {
    readonly inputSampleRate = 16000;
    readonly id = "grok";
    readonly label = "Grok (xAI)";
    private readonly connect;
    private readonly keyReader;
    private readonly timeoutMs;
    /** Silence (seconds) the server waits before finalizing a turn. Drives the
     * `endpointing` param (0-5000 ms), mirroring the user's "VAD silence pause". */
    vadSilenceSec: number;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, timeoutMs?: number);
    availabilityProblem(): Promise<string | null>;
    transcribe(pcm16: Uint8Array): Promise<string>;
    checkEndpoint(pcm16: Uint8Array): Promise<{
        text: string;
        isEndpoint: boolean;
    }>;
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
    /** Stream `pcm16` over one WebSocket and resolve when the stream closes. */
    private stream;
    dispose(): void;
}
/**
 * xAI Grok streaming speech synthesis (`/v1/tts`). Sends the whole reply as one
 * streamed turn (`text.delta` then `text.done`) and plays base64 `audio.delta`
 * chunks as they arrive, mirroring Deepgram Flux's continuous-prosody path.
 */
export declare class GrokSynthesizer implements SpeechSynthesizer {
    readonly outputSampleRate = 24000;
    readonly id = "grok";
    readonly label = "Grok (xAI)";
    private readonly connect;
    private readonly keyReader;
    private readonly defaultSink;
    private readonly voice;
    private stopped;
    private activeSocket;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, sink: AudioSink, voice?: string);
    availabilityProblem(): Promise<string | null>;
    speak(text: string, sink?: AudioSink): Promise<void>;
    /** Send incremental text on one TTS socket and finish the utterance once. */
    speakStream(texts: AsyncIterable<string> | Iterable<string>, sink?: AudioSink): Promise<void>;
    stop(): void;
    dispose(): void;
}
