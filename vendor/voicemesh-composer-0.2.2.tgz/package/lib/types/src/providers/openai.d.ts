/** OpenAI transcription sessions and streamed PCM speech synthesis. */
import type { KeyReader, RecognizedTurn, TurnStreamingRecognizer, SpeechSynthesizer, WebSocketConnect } from './speech.ts';
import type { AudioSink } from './deepgram-aura.ts';
/** Transcribe a single explicitly committed utterance, with cumulative live captions. */
export declare class OpenaiRecognizer implements TurnStreamingRecognizer {
    private readonly connect;
    private readonly keyReader;
    private readonly model;
    readonly id = "openai";
    readonly label = "OpenAI";
    readonly inputSampleRate = 24000;
    private readonly lifetime;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, model: string);
    availabilityProblem(): Promise<string | null>;
    transcribe(pcm16: Uint8Array): Promise<string>;
    checkEndpoint(pcm16: Uint8Array): Promise<{
        text: string;
        isEndpoint: boolean;
    }>;
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
    dispose(): void;
}
/** Stream OpenAI's 24 kHz little-endian PCM response with cancellation and sink backpressure. */
export declare class OpenaiSynthesizer implements SpeechSynthesizer {
    private readonly keyReader;
    private readonly sink;
    private readonly voice;
    private readonly model;
    readonly id = "openai";
    readonly label = "OpenAI";
    readonly outputSampleRate = 24000;
    private active;
    constructor(keyReader: KeyReader, sink: AudioSink, voice: string, model: string);
    availabilityProblem(): Promise<string | null>;
    speak(text: string, sink?: AudioSink): Promise<void>;
    stop(): void;
    dispose(): void;
}
