/**
 * The STT/TTS provider seam.
 *
 * The voice layer never hard-codes a vendor. Speech recognition (STT) and
 * speech synthesis (TTS) sit behind two interfaces, and the config's engine id
 * picks which one is built. The plugin wires the provider the harness will use
 * on the host side.
 *
 * Ported in shape from the Flutter `voice_provider.dart`. Each implementation
 * takes its transport injected, so the protocol and the credentials are
 * testable without opening a socket.
 */
/** The outcome of one transcribed utterance. */
export interface Transcription {
    readonly text: string;
    /** Whether the endpoint considers the utterance finished. */
    readonly isEndpoint: boolean;
}
/** A speech-recognition engine: PCM16 audio in, text out. */
export interface SpeechRecognizer {
    /** PCM16 mono input clock in Hz. */
    readonly inputSampleRate: number;
    /** Stable engine id referenced by config (`sttEngine`). */
    readonly id: string;
    /** Human label for a settings picker. */
    readonly label: string;
    /** Why the engine cannot run now, or null when ready. */
    availabilityProblem(): Promise<string | null>;
    /** Transcribe one utterance at inputSampleRate. */
    transcribe(pcm16: Uint8Array): Promise<string>;
    /** Transcribe and report whether it is a finished utterance. */
    checkEndpoint(pcm16: Uint8Array): Promise<Transcription>;
    dispose(): void;
}
/** A stage of a streaming turn from a turn-streaming recognizer. */
export type TurnStage = 'start' | 'update' | 'resumed' | 'end';
/** One streaming-turn observation: the stage plus the running transcript. */
export interface RecognizedTurn {
    readonly stage: TurnStage;
    readonly transcript: string;
}
/** A recognizer that drives turn-taking from its own native events. */
export interface TurnStreamingRecognizer extends SpeechRecognizer {
    /** Emit native turn observations until the input is drained and the provider confirms stream completion.
     * @param chunks - Audio input; ending it requests provider finalization.
     * @param signal - Cancellation, including the host-owned finalization deadline.
     * @returns Transcript observations; errors reject rather than promoting partial text to a final.
     */
    turnStream(chunks: AsyncIterable<Uint8Array>, signal?: AbortSignal): AsyncIterable<RecognizedTurn>;
}
/** A speech-synthesis engine: text in, audio out. */
export interface SpeechSynthesizer {
    /** Sample rate in Hz of emitted PCM16 mono audio; available before the first sink call. */
    readonly outputSampleRate: number;
    /** Synthesize incremental text through one provider turn when supported. */
    speakStream?(texts: AsyncIterable<string> | Iterable<string>, sink?: import('./deepgram-aura.ts').AudioSink): Promise<void>;
    /** Stable engine id referenced by config (`ttsEngine`). */
    readonly id: string;
    readonly label: string;
    availabilityProblem(): Promise<string | null>;
    /** Synthesize `text`, streaming audio to `sink`. Completes when done. */
    speak(text: string, sink?: (audio: Uint8Array) => void): Promise<void>;
    stop(): void;
    dispose(): void;
}
/** The injectable transport seam for a WebSocket provider.*/
export interface WebSocketLike {
    send(data: string | Uint8Array): void;
    close(): void;
    readonly ready: Promise<void>;
    onMessage(handler: (data: string) => void): void;
    /** Binary frames (e.g. streamed TTS audio). Optional: STT-only providers skip it. */
    onBinary?(handler: (data: Uint8Array) => void): void;
    onError(handler: (error: unknown) => void): void;
    onClose(handler: () => void): void;
}
/** Connects a WebSocket to `url` with `headers`. Injectable for tests. */
export type WebSocketConnect = (url: string, headers: Record<string, string>) => WebSocketLike;
/** How the provider reads its API key. Injectable so tests need no secrets. */
export type KeyReader = () => Promise<string | null> | string | null;
