import type { SpeechRecognizer, WebSocketConnect, KeyReader } from './speech.js';
export interface SttHttpResponse {
    ok: boolean;
    text: string;
    /** A human-readable error when not ok. */
    error?: string;
}
export declare class HostStt {
    readonly recognizer: SpeechRecognizer;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, recognizer?: SpeechRecognizer);
    /** Transcribe one PCM16 body and return a JSON-ready result. */
    transcribe(pcm16: Uint8Array): Promise<SttHttpResponse>;
}
