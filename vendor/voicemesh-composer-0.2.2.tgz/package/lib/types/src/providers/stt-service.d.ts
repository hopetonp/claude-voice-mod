import type { SpeechRecognizer, WebSocketConnect, KeyReader } from './speech.ts';
/** A downstream frame, in the host→client direction. */
export type SttFrame = {
    type: 'partial';
    text: string;
} | {
    type: 'transcript';
    text: string;
    ended: boolean;
};
/** A client connection the host services. */
export interface SttConnection {
    /** Send a frame to the client. */
    send(frame: SttFrame): void;
    /** Handle a binary/audio chunk from the client. */
    onAudio(handler: (pcm16: Uint8Array) => void): void;
    /** Handle the end-of-stream signal (the client said "done"). */
    onEnd(handler: () => void): void;
    /** Close the connection. */
    close(): void;
}
/**
 * The host-side STT service: buffers client audio, transcribes it with Flux
 * once the client ends the stream, and pushes a `transcript` frame back.
 *
 * The recognizer is injectable so tests can substitute a stub without a socket
 * or Deepgram.
 */
export declare class SttService {
    private readonly onTranscript?;
    readonly recognizer: SpeechRecognizer;
    constructor(connect: WebSocketConnect, keyReader: KeyReader, onTranscript?: ((text: string, ended: boolean) => void) | undefined, recognizer?: SpeechRecognizer);
    /**
     * Accept a client connection, buffer its audio, and transcribe once the
     * client ends the stream. Returns a disconnect that stops the session.
     */
    handle(conn: SttConnection): () => void;
}
