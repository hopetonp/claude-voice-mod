/**
 * Browser WebSocket transport for the provider seam.
 *
 * The core's providers take a `WebSocketConnect` so the protocol is testable
 * without a socket. In the browser this is a thin adapter over the platform
 * `WebSocket` API. The plugin will provide the host-side equivalent (or reuse
 * this, since the plugin runs on the web client).
 */
import type { WebSocketConnect, WebSocketLike } from '../providers/speech.ts';
/** Adapt the browser `WebSocket` to the core's `WebSocketLike`. */
export declare function connectBrowserWebSocket(url: string, headers: Record<string, string>): WebSocketLike;
export declare const browserConnect: WebSocketConnect;
