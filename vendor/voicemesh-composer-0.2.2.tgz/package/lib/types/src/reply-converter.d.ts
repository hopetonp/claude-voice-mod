/**
 * Strip common markdown into plain spoken prose, keeping the word order.
 *
 * The harness reply is markdown (bold, headers, links, code, tables); a
 * text-to-speech model reads the symbols aloud as nonsense. This removes that
 * decoration so the synthesizer gets clean spoken prose.
 *
 * Ported from the Flutter `reply_converter.dart`. The rules that would be got
 * wrong on a naive reimplementation:
 *
 * - **Code fences and SHAs are omitted entirely**, not read — reciting a commit
 *   hash or a file path aloud is nonsense in a voice reply.
 * - **File paths are omitted**, so the reply reads as prose instead of reciting
 *   `/Users/...` and `lib/src/...`.
 * - **A period that follows uppercase next-word is honoured**, but decoration
 *   is stripped so sentence boundaries survive.
 */
/** Strip markdown decoration into plain prose while keeping word order. */
export declare function stripMarkdown(text: string): string;
