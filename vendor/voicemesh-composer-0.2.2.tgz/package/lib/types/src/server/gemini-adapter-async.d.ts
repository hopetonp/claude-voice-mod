import type { StsChannelSettings } from './sts-channel.ts';
import type { GeminiThinkingConfig } from './gemini-adapter-metadata.ts';
import type { StsProviderConnection } from './sts-provider.ts';
/**
 * Create a Gemini session whose declared tools may run while model generation continues.
 *
 * The thinking configuration travels with it, because the extended-thinking model is async
 * *and* requires a thinking level: an adapter that dropped the second half would be unable to
 * start the one model that needs it most.
 */
export declare function createAsyncGeminiSession(settings: StsChannelSettings, thinking: GeminiThinkingConfig): StsProviderConnection;
