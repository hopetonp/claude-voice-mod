import type { StsChannelSettings } from './sts-channel.ts';
import type { GeminiThinkingConfig } from './gemini-adapter-metadata.ts';
import type { StsProviderConnection } from './sts-provider.ts';
/** Create a Gemini session whose declared tools complete before model generation continues. */
export declare function createBlockingGeminiSession(settings: StsChannelSettings, thinking: GeminiThinkingConfig): StsProviderConnection;
