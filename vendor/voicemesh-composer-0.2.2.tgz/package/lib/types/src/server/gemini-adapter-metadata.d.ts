/**
 * The one list of Gemini Live models, read by both the session router and the settings picker.
 *
 * Keeping two lists is how the two halves stopped agreeing: the picker filtered Google's
 * catalog for identifiers that looked conversational (`*-flash-live*`, `*-native-audio*`) and
 * the router matched a hand-written set of documented identifiers. So the picker offered
 * models the router had never heard of — which then took the generic path — and the router
 * knew the model the application defaults to, `gemini-3.8-live`, which the picker could not
 * show. A saved default was therefore a model the settings screen could not confirm.
 *
 * One list, and the agreement is structural: the picker may only offer a row that names an
 * adapter, so an offered model is always one the router can route.
 *
 * Entries are exact identifiers rather than family patterns on purpose. A pattern absorbs
 * identifiers whose behaviour nobody has checked, and the near-miss is real:
 * `gemini-3.8-live-extended-thinking` reads like the 3.8 family and shares neither its tool
 * behaviour nor its thinking field, which is what a wire probe against the Live API showed.
 * A new model is a line here, which is the cost of every offered model being one this
 * library has measured.
 */
/**
 * How one model wants thinking expressed, measured against the Live API rather than inferred
 * from its name.
 *
 * Every field is the exact `generationConfig.thinkingConfig` for that state, so the two states
 * a caller can be in are the two things the list states. `undefined` means "send nothing",
 * which is a real answer: `gemini-3.8-live` rejects a thinking level and `gemini-3.1-flash-live`
 * needs no thinking field at all.
 *
 * This is not a boolean because the fleet does not agree. Measured: the extended model closes
 * the socket with `Thinking level must be specified for this model` when the field is missing
 * and rejects `thinkingBudget` in every value; `gemini-3.8-live` answers `Thinking level is not
 * supported for this model` to a level and accepts a budget of zero; the 2.5 native-audio models
 * accept the budget the composer already sends them. A single dialect cannot serve all of them.
 */
export type GeminiThinkingConfig = Readonly<{
    /** Sent when the caller has not asked the model to think. */
    off?: Readonly<Record<string, unknown>> | undefined;
    /** Sent when the caller has asked the model to think. */
    on?: Readonly<Record<string, unknown>> | undefined;
}>;
/** What a session is told about one model identifier. */
export type GeminiLiveModelMetadata = Readonly<{
    adapter: 'blocking' | 'async' | 'unspecified';
    thinking: GeminiThinkingConfig;
}>;
/** One documented model, and everything Composer decides from its identifier. */
export type GeminiLiveModelRule = Readonly<{
    /** The identifier Google documents, without the `models/` prefix. */
    id: string;
    /** Blocking tools finish before generation continues; async tools may run while it does. */
    adapter: 'blocking' | 'async';
    /** The `thinkingConfig` to send in each caller state. */
    thinking: GeminiThinkingConfig;
    /**
     * Whether the settings picker may offer it.
     *
     * `false` is not "unsupported": the row still routes a session that saved this model. It
     * only means the list has moved on, which is the case for the 2.5 native-audio models —
     * routable so an existing setting keeps working, not offered to anybody new.
     */
    offered: boolean;
}>;
export declare const GEMINI_LIVE_MODEL_RULES: readonly GeminiLiveModelRule[];
/**
 * Route one model identifier to its adapter and thinking configuration.
 *
 * An identifier the list does not name still starts a session, on the generic path: a
 * setting saved by an older build must not become a session that refuses to connect. What
 * it cannot do is reach the settings picker, because the picker only offers listed rows.
 * @param modelName Model identifier as saved, with or without a `models/` prefix.
 * @returns The adapter and the thinking configuration for that identifier.
 */
export declare function resolveGeminiLiveModel(modelName: string): GeminiLiveModelMetadata;
/** The `thinkingConfig` for one caller state, or undefined when nothing is sent. */
export declare function geminiThinkingFor(thinking: GeminiThinkingConfig, callerAskedToThink: boolean): Readonly<Record<string, unknown>> | undefined;
/**
 * Whether the settings picker may offer one discovered model.
 *
 * The other half of the agreement: this is the only filter the list applies, so the picker
 * cannot offer a model the router would route generically.
 * @param modelName Model identifier from the provider's catalog, with or without a prefix.
 * @returns true only for a listed row the list marks as offered.
 */
export declare function geminiLiveModelOffered(modelName: string): boolean;
