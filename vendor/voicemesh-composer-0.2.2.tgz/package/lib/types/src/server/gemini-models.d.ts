/** Fetch Gemini model metadata without returning credentials or remote diagnostics.
 * @param key - host-owned Gemini credential.
 * @param signal - request cancellation and deadline.
 * @returns deduplicated models advertised by Google.
 */
export declare function geminiModels(key: string, signal: AbortSignal): Promise<{
    name: string;
    supportedGenerationMethods?: string[] | undefined;
}[]>;
/** Discover Gemini pipeline models with the required speech transport.
 * @param key - host-owned Gemini credential.
 * @param kind - recognition or synthesis.
 * @param signal - discovery cancellation and deadline.
 * @returns live transcription or streaming TTS models confirmed by individual lookup.
 */
export declare function listGeminiSpeechModels(key: string, kind: 'stt' | 'tts', signal: AbortSignal): Promise<string[]>;
