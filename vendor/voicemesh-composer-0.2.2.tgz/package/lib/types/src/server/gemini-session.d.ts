import type { StsChannelSettings } from './sts-channel.ts';
import { type GeminiThinkingConfig } from './gemini-adapter-metadata.ts';
import type { StsProviderConnection } from './sts-provider.ts';
/** Model-specific setup choices supplied by a private Gemini adapter. */
export type GeminiSessionStrategy = Readonly<{
    functionBehavior?: 'BLOCKING' | 'NON_BLOCKING';
    /** The thinking configuration this model speaks, in both caller states; see the model list. */
    thinking?: GeminiThinkingConfig;
}>;
/** Create one Gemini Live connection while keeping wire translation shared by every adapter. */
export declare function createGeminiSession(settings: StsChannelSettings, strategy: GeminiSessionStrategy): StsProviderConnection;
