import { z } from 'zod';
declare const requestSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        stt: "stt";
        tts: "tts";
        kws: "kws";
    }>;
    language: z.ZodEnum<{
        en: "en";
        zh: "zh";
    }>;
    precision: z.ZodEnum<{
        fp32: "fp32";
        int8: "int8";
    }>;
    sttEngine: z.ZodDefault<z.ZodEnum<{
        vosk: "vosk";
        parakeet: "parakeet";
    }>>;
    parakeetVersion: z.ZodDefault<z.ZodEnum<{
        v2: "v2";
        v3: "v3";
    }>>;
    kokoroVersion: z.ZodDefault<z.ZodEnum<{
        v1_0: "v1_0";
        v1_1: "v1_1";
    }>>;
}, z.core.$strict>;
export type LocalInstallRequest = z.input<typeof requestSchema>;
/** Runtime files bundled with Composer; harnesses only choose where to install them. */
export declare const localRuntimeTemplatePath: string;
/** Open-vocabulary keyword-spotting pack published with the sherpa-onnx KWS releases. */
export declare function kwsPackUrl(language: 'en' | 'zh'): string;
/** Observable installer progress; no subprocess environment or credentials are exposed. */
export interface LocalInstallStatus {
    running: boolean;
    phase: string;
    downloaded: number;
    total: number;
    error: string | null;
}
/** Fixed deployment locations and installer execution limit. */
export interface LocalInstallConfig {
    templatePath?: string;
    runtimePath: string;
    modelsPath: string;
    python: string;
    timeoutMs: number;
}
/** One installation at a time, surviving dialog closure and stopping with the plugin. */
export declare class LocalInstaller {
    private readonly config;
    private state;
    private child;
    private work;
    private disposed;
    constructor(config: LocalInstallConfig);
    /** Current installation state. @returns A snapshot safe to send to the settings UI. */
    status(): LocalInstallStatus;
    /** Read the selected provider archive size. @param input - Selected speech pack. @returns Download bytes, or null when unavailable. */
    size(input: unknown): Promise<number | null>;
    /** Start a validated model installation. @param input - Requested model kind, language and precision. */
    start(input: unknown): void;
    private run;
    private stopChild;
    /** Stop installation and wait for the owned subprocess to exit. */
    dispose(): Promise<void>;
}
export {};
