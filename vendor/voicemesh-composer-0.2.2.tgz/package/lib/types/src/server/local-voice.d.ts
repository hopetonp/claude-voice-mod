import { z } from 'zod';
import type { SpeechRecognizer, TurnStreamingRecognizer, SpeechSynthesizer } from '../providers/speech.ts';
declare const manifestSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        stt: "stt";
        tts: "tts";
    }>;
    name: z.ZodString;
    languages: z.ZodArray<z.ZodString>;
    sourceUrl: z.ZodURL;
    engine: z.ZodOptional<z.ZodEnum<{
        vosk: "vosk";
        parakeet: "parakeet";
    }>>;
    parakeet: z.ZodOptional<z.ZodObject<{
        encoder: z.ZodString;
        decoder: z.ZodString;
        joiner: z.ZodString;
        tokens: z.ZodString;
    }, z.core.$strip>>;
    voices: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        languages: z.ZodArray<z.ZodString>;
        gender: z.ZodDefault<z.ZodString>;
        region: z.ZodDefault<z.ZodString>;
    }, z.core.$strip>>>;
    kokoro: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strip>;
type LocalModel = z.infer<typeof manifestSchema> & {
    id: string;
    path: string;
};
/** Host configuration for explicitly installed native runtime and model packs. */
export interface LocalVoiceConfig {
    runtimePath: string;
    modelsPath: string;
    threads: number;
    idleMs: number;
    timeoutMs: number;
}
/** Local model discovery and worker ownership; cloud use does not load native libraries. */
export declare class LocalVoice {
    private readonly config;
    private workers;
    private disposed;
    private shutdown;
    private idle;
    constructor(config: LocalVoiceConfig);
    /** Native packages are optional; cloud-only installations remain small. */
    nativeAvailable(kind: 'stt' | 'tts', engine?: 'vosk' | 'parakeet'): boolean;
    /** Read installed model manifests.
     * @returns installed models with host-owned paths.
     */
    models(): Promise<LocalModel[]>;
    private assertActive;
    private acquire;
    private discard;
    private release;
    /** Build a native streaming recognizer.
     * @param id - Installed model ID.
     * @returns recognizer using cumulative transcripts.
     */
    recognizer(id: string): SpeechRecognizer & TurnStreamingRecognizer;
    /** Build a local speech synthesizer.
     * @param voice - Installed model ID and numeric speaker ID.
     * @param sink - Receives PCM16 mono audio chunks at outputSampleRate.
     * @returns cancellable PCM16 synthesis at the installed model rate.
     */
    synthesizer(voice: string, sink: (bytes: Uint8Array) => void): SpeechSynthesizer;
    /** Release all native workers, including idle model caches. */
    dispose(): Promise<void>;
}
/** Encode filtered mono 16kHz samples as PCM16.
 * @param samples - Resampled native audio.
 * @returns little-endian PCM16 bytes.
 */
export declare function localPcm16(samples: Float32Array): Uint8Array;
export {};
