/** Discover compatible speech model IDs for the saved credential.
 * @param key - host-owned OpenAI credential.
 * @param kind - recognition or synthesis.
 * @param signal - request deadline and cancellation.
 * @returns model IDs confirmed by individual model lookup.
 */
export declare function listOpenaiSpeechModels(key: string, kind: 'stt' | 'tts', signal: AbortSignal): Promise<string[]>;
