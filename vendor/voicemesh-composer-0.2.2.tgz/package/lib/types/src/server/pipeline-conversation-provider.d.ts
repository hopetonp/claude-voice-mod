export declare const conversationProviders: readonly [{
    readonly id: "openai";
    readonly label: "OpenAI";
    readonly baseUrl: "https://api.openai.com/v1";
}, {
    readonly id: "grok";
    readonly label: "Grok (xAI)";
    readonly baseUrl: "https://api.x.ai/v1";
}, {
    readonly id: "gemini";
    readonly label: "Google Gemini";
    readonly baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai";
}, {
    readonly id: "deepseek";
    readonly label: "DeepSeek";
    readonly baseUrl: "https://api.deepseek.com/v1";
}, {
    readonly id: "mistral";
    readonly label: "Mistral";
    readonly baseUrl: "https://api.mistral.ai/v1";
}, {
    readonly id: "openrouter";
    readonly label: "OpenRouter";
    readonly baseUrl: "https://openrouter.ai/api/v1";
}, {
    readonly id: "custom";
    readonly label: "Custom OpenAI-compatible";
    readonly baseUrl: "";
}];
/** Canonical endpoint for credential binding and outbound requests. */
export declare function conversationBase(value: string): string;
export declare function resolveConversationBase(provider: string, customBaseUrl?: string): string;
export declare function conversationCredentialSlot(provider: string, baseUrl: string): string;
export declare function listConversationModels(provider: string, baseUrl: string, key: string, signal: AbortSignal, fetcher?: typeof fetch): Promise<{
    id: string;
    label: string;
}[]>;
/** Forward a Composer conversation turn to the chosen endpoint; the harness streams the response. */
export declare function requestPipelineConversation(input: {
    provider: string;
    baseUrl?: string;
    model: string;
    key: string;
    body: unknown;
    signal: AbortSignal;
    fetcher?: typeof fetch;
}): Promise<Response>;
