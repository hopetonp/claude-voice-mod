import type { LocalVoice } from './local-voice.ts';
export interface PipelineEngineOption {
    id: string;
    label: string;
    available: boolean;
    reason?: string;
}
/** Composer's usable pipeline engines, including optional installed native models. */
export declare function listPipelineEngines(kind: 'stt' | 'tts', local: LocalVoice): Promise<PipelineEngineOption[]>;
