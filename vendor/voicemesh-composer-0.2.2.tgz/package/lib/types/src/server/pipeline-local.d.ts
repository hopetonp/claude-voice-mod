import type { SpeechRecognizer, WebSocketConnect } from '../providers/speech.ts';
import type { LocalVoice } from './local-voice.ts';
/** Select a cloud or installed native recognizer without teaching the harness provider internals. */
export declare function createPipelineRecognizer(engine: string, model: string, connect: WebSocketConnect, key: () => string | null, local: LocalVoice): SpeechRecognizer | null;
