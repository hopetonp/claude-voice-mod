import type { WebSocketConnect } from '../providers/speech.ts';
/** Provider credentials stay in connection headers; the harness never receives wire events. */
export declare const connectPipelineProvider: WebSocketConnect;
