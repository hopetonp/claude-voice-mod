/** The persistent browser-to-recognizer turn stream extracted from DeepSeek's voice host. */
import { WebSocket } from 'ws';
import type { TurnStreamingRecognizer } from '../providers/speech.ts';
/** The harness authenticates the socket and resolves the selected recognizer before calling this. */
export declare function attachPipelineSttSession(socket: WebSocket, recognizer: TurnStreamingRecognizer, options?: {
    finalizeTimeoutMs?: number;
    maxQueuedBytes?: number;
}): void;
