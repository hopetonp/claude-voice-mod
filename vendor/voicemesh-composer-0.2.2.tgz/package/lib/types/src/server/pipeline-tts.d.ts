import type { WebSocketConnect } from '../providers/speech.ts';
import type { LocalVoice } from './local-voice.ts';
export interface PipelineSynthesis {
    engine: string;
    model?: string;
    voice?: string;
    text: string;
    key(): string | null | Promise<string | null>;
    connect: WebSocketConnect;
    local?: LocalVoice;
}
/** The harness owns response authorization and streaming; Composer owns vendor synthesis. */
export declare function synthesizePipeline(selection: PipelineSynthesis, sink: (pcm: Uint8Array, sampleRate: number) => void, signal?: AbortSignal): Promise<void>;
