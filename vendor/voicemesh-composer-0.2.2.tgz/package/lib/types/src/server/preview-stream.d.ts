/** Stream a bounded PCM voice preview to any HTTP harness. */
import type { ServerResponse } from 'node:http';
export type PreviewPcmSink = (pcm: Uint8Array, sampleRate: number) => void;
/** Send audio on the first provider chunk, without waiting for synthesis to finish. */
export declare function streamPcmPreview(response: ServerResponse, generate: (sink: PreviewPcmSink) => Promise<void>, signal?: AbortSignal, maxBytes?: number): Promise<void>;
