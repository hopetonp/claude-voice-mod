import type { SpokenRequestRoute } from '../classification-tool.ts';
export declare const classifierProviders: readonly [{
    readonly id: "jev";
    readonly label: "Jev (TypeSafe)";
    readonly defaultModel: "jev-latest";
}, {
    readonly id: "openai";
    readonly label: "OpenAI Decisions";
    readonly defaultModel: "gpt-6-luna";
}];
export declare function classifySpokenRequest(input: {
    provider: 'jev' | 'openai';
    model: string;
    key: string;
    utterance: string;
    context?: string;
    signal: AbortSignal;
    fetcher?: typeof fetch;
}): Promise<SpokenRequestRoute>;
