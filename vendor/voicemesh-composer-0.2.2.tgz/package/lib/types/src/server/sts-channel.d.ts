import type { TranscriptHistoryRow } from '../transcript-history.ts';
import type { StsProvider, StsProviderConnection } from './sts-provider.ts';
import { type StsCommandLimits, type StsCommandOutcome } from './sts-commands.ts';
/** Realtime settings resolved before opening a connection. */
export interface StsChannelSettings {
    readonly key: string;
    readonly model: string;
    readonly voice: string;
    readonly silenceSec: number;
    readonly thinking: boolean;
    readonly instructions: string;
    readonly tools: readonly object[];
    /** Prepared harness-owned speech supplied to providers with structured startup-history support. */
    readonly startupHistory?: readonly TranscriptHistoryRow[];
    /** Optional application instruction used by a provider to keep history initialization silent. */
    readonly startupInstruction?: string;
    /** Key-resolved input-caption model for providers with separate transcription. */
    readonly transcriptionModel?: string;
    readonly connectTimeoutMs: number;
    readonly maxQueuedBytes: number;
    /** Track provider command acceptance by default; false makes sends transmission-only and disables command(). */
    readonly commandAcknowledgments?: boolean;
    /** Required when provider command acknowledgment tracking is enabled. */
    readonly commands?: StsCommandLimits;
    /** Required positive integer finalization deadline for providers with closeEvent. */
    readonly closeTimeoutMs?: number;
}
/** Persistence and consumer operations owned by the linked voice conversation. */
export interface StsChannelOwner {
    /** Observe acceptance separately from socket transmission and playback; must not wait for inbound events.
     * @param outcome - sanitized command result, with no provider body.
     */
    commandOutcome?(outcome: StsCommandOutcome): void;
    /** Optional sanitized diagnostics supplied by the application. */
    diagnostic?(message: string, ...values: unknown[]): void;
    /**
     * Durably record data before transmission or consumer delivery. Credentials are excluded.
     * Input and output calls may overlap; retain call order and acknowledge each event after its durable batch.
     * @param direction - connection metadata, outbound input, or inbound output.
     * @param event - JSON event or model connection metadata with transport credentials redacted.
     * @param signal - cancellation; writes must settle when aborted.
     * @returns completion after durability.
     */
    record(direction: 'connection' | 'input' | 'output', event: Readonly<Record<string, unknown>>, signal: AbortSignal): Promise<void>;
    /**
     * Consume one recorded provider event; failure closes the connection.
     * @param event - validated provider event envelope.
     * @param signal - conversation lifetime cancellation.
     * @returns completion after the event is handled.
     */
    receive(event: Readonly<Record<string, unknown>>, signal: AbortSignal): Promise<void>;
    /**
     * Return completed speaker-labelled conversation rows for a new provider session after an
     * unexpected transport loss. The result must exclude an interrupted response and tool calls.
     * @param signal - conversation lifetime cancellation.
     * @returns durable completed conversation context, or undefined when safe restoration is unavailable.
     */
    recoveryHistory?(signal: AbortSignal): Promise<readonly TranscriptHistoryRow[] | undefined>;
}
/** Sanitized terminal reason, without provider error bodies or credentials. */
export type StsChannelEnd = 'local-stop' | 'aborted' | 'provider-closed' | 'provider-error' | 'queue-limit' | 'recording-failed' | 'consumer-failed' | 'transmission-failed' | 'configuration-timeout' | 'invalid-event' | 'close-timeout';
/** Latest cumulative usage and independently confirmed provider finalization. */
export interface StsFinalization {
    readonly seconds: number | null;
    readonly confirmed: boolean;
    readonly reason: string | null;
}
/** An active provider socket; it owns neither coding execution nor browser playback. */
export interface StsChannel {
    /** Whether the active provider connection accepts non-generating tool-result scheduling. */
    readonly supportsToolResponseScheduling: boolean;
    /**
     * Record and send one provider event in call order.
     * @param event - provider input without credentials.
     * @returns completion after persistence and socket transmission; rejects when closure withholds input.
     */
    send(event: Readonly<Record<string, unknown>>): Promise<void>;
    /** Transmit an acknowledged command and expose its separate acceptance promise.
     * Never await acceptance inside owner.receive; that callback serializes inbound delivery.
     * @param event - command supported by the provider acknowledgment protocol, with a fresh event ID if supplied.
     * @returns transmission completion and independent provider acceptance; neither implies playback.
     */
    command(event: Readonly<Record<string, unknown>>): {
        transmitted: Promise<void>;
        accepted: Promise<void>;
    };
    /**
     * Send a response request only while its scheduling condition remains true.
     * @param event - input carrying a unique event_id for durable transmission accounting.
     * @param eligible - synchronous condition rechecked after persistence.
     * @returns false when withheld; a persisted input is paired with an input.withheld record.
     */
    sendWhen(event: Readonly<Record<string, unknown>> & {
        event_id: string;
    }, eligible: () => boolean): Promise<boolean>;
    /** Settles after provider close and all owned callbacks, including persistence, finish. */
    readonly closed: Promise<StsChannelEnd>;
    /** Latest recorded usage snapshot; null seconds means none was received. */
    readonly finalization: StsFinalization;
    /**
     * Stop admitting input and request provider finalization. Repeated calls share completion.
     * Never await inside owner.receive; the receiver must drain the final event.
     * @returns closure after final metadata is recorded; absent a final event, usage remains unconfirmed.
     */
    finish(): Promise<StsChannelEnd>;
    /**
     * Replace the provider connection without ending the conversation owner.
     * @param next - authenticated replacement adapter.
     * @param history - context items restored before queued input is released; never response requests.
     * @returns replacement readiness after restoration.
     */
    replace(next: StsProviderConnection, history?: readonly Readonly<Record<string, unknown>>[]): Promise<void>;
    /**
     * Abort queued work and release the socket. Repeated calls share completion.
     * Do not await this method inside owner.receive; close waits for that callback.
     * @returns completion after the socket and owned callbacks have quiesced.
     */
    close(): Promise<StsChannelEnd>;
}
/**
 * Open a recorded provider session, retaining its owner across provider-requested connection renewal.
 * @param settings - validated provider settings and resource limits.
 * @param owner - durable voice-conversation recorder and event consumer.
 * @param signal - owning voice connection's lifetime.
 * @param provider - connection-local protocol implementation; xAI is the default.
 * @param connection - negotiated sideband adapter; omitted for a standalone provider socket.
 * @returns the configured channel, or rejection after failed startup has fully closed.
 */
export declare function openStsChannel(settings: StsChannelSettings, owner: StsChannelOwner, signal: AbortSignal, provider?: StsProvider, connection?: StsProviderConnection): Promise<StsChannel>;
