/** Bounded command acceptance tracking, independent of transmission and playback. */
import type { StsMessage } from './sts-provider.ts';
declare const commandIdentity: unique symbol;
/** Opaque client command identity, validated when admitted to the channel. */
export type StsCommandId = string & {
    readonly [commandIdentity]: 'voice-command';
};
/** Resolved limits for commands whose provider acknowledges acceptance. */
export interface StsCommandLimits {
    readonly timeoutMs: number;
    readonly maxPending: number;
}
/** Acceptance evidence; unknown outcomes must never trigger automatic replay. */
export interface StsCommandOutcome {
    readonly eventId: StsCommandId;
    readonly status: 'accepted' | 'rejected' | 'unknown';
    readonly code: string | null;
}
/** Rejected or unconfirmed command, without provider text or payloads. */
export declare class StsCommandError extends Error {
    readonly outcome: StsCommandOutcome;
    /** @param outcome - sanitized acceptance evidence. */
    constructor(outcome: StsCommandOutcome);
}
/** One channel's outstanding acknowledgments; callers must use fresh command IDs. */
export declare class StsCommands {
    private readonly limits;
    private readonly outcome;
    private readonly pending;
    /** @param limits - validated deadline and queue capacity. @param outcome - synchronous acceptance observer. */
    constructor(limits: StsCommandLimits, outcome: (result: StsCommandOutcome) => void);
    /** Reserve before transmission. @param event - encoded command. @param acknowledgment - expected event type. @returns provider acceptance. */
    track(event: StsMessage, acknowledgment: string): Promise<void>;
    /** Reject transmission after its acceptance deadline expires. @param id - reserved command identity. */
    assertPending(id: string): void;
    /** Settle only correlated, recorded provider events. @param event - sanitized incoming message. */
    receive(event: StsMessage): void;
    /** Reject all unresolved work before releasing a connection. @param code - local sanitized termination reason. */
    close(code: string): void;
    private finish;
}
export {};
