/**
 * Render an isolated preview; silence after generated audio bounds this sample, not conversation turns.
 * @param key - host credential.
 * @param model - discovered Live model.
 * @param voice - discovered voice.
 * @param phrase - exact sample text.
 * @param signal - preview cancellation.
 * @param timeoutMs - total preview deadline.
 * @param maxBytes - audio size bound.
 * @param onAudio - optional incremental PCM sink, called before session closure.
 * @returns mono PCM16 at 24 kHz; streaming callers receive audio through the sink.
 */
export declare function previewLive(key: string, model: string, voice: string, phrase: string, signal: AbortSignal, timeoutMs: number, maxBytes: number, onAudio?: (pcm: Buffer) => void): Promise<{
    audio: string;
    sampleRate: number;
}>;
