import { type StsModelListing } from './sts-thinking.ts';
/** Fetch live models without returning provider errors or credentials.
 *
 * Each listing carries the two thinking states that model offers, or null when it offers none, so
 * the settings screen can show a level choice only where it changes the session and can label it
 * with the model's own words.
 * @param payload Provider and saved API key from the authenticated settings request.
 * @param signal Request cancellation and deadline.
 * @returns Sorted conversational STS models advertised by the provider.
 */
export declare function listStsModels(payload: unknown, signal: AbortSignal): Promise<StsModelListing[]>;
/** List key-accessible OpenAI transcription models for realtime input captions.
 * @param key - application-owned provider credential.
 * @param signal - cancellation and deadline.
 * @returns model IDs confirmed by individual lookup.
 */
export declare function listRealtimeTranscriptionModels(key: string, signal: AbortSignal): Promise<string[]>;
/** Discover text backend candidates from the OpenAI key's advertised models.
 * @param key - application credential.
 * @param signal - cancellation and deadline.
 * @returns text-model candidates; execution establishes Responses API compatibility.
 */
export declare function listLiveBackendModels(key: string, signal: AbortSignal): Promise<string[]>;
/** Discover OpenAI speech-synthesis models advertised to the application key.
 * @param key - application credential.
 * @param signal - cancellation and deadline.
 * @returns current synthesis model IDs.
 */
export declare function listOpenaiSynthesisModels(key: string, signal: AbortSignal): Promise<string[]>;
