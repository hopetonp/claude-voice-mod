import type { PreviewPcmSink } from './preview-stream.ts';
declare const providers: {
    openai: import("./sts-provider.ts").StsProvider;
    xai: import("./sts-provider.ts").StsProvider;
    gemini: import("./sts-provider.ts").StsProvider;
};
export declare function previewStsVoice(providerId: keyof typeof providers, settings: {
    key: string;
    model: string;
    voice: string;
    transcriptionModel?: string;
}, phrase: string, signal: AbortSignal, onAudio?: PreviewPcmSink): Promise<{
    audio: string;
    sampleRate: number;
}>;
export {};
