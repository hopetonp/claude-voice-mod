import type { StsProvider } from './sts-provider.ts';
/** Gemini Live uses 16 kHz microphone input and 24 kHz generated PCM. */
export declare const geminiStsProvider: StsProvider;
