import type { StsProvider } from './sts-provider.ts';
/** Live uses WebRTC media and a host-authenticated sideband for transcripts and delegation. */
export declare const openaiLiveProvider: StsProvider;
