import type { StsProvider } from './sts-provider.ts';
/** OpenAI accepts and emits mono 24 kHz PCM16 through the GA WebSocket API. */
export declare const openaiStsProvider: StsProvider;
