import type { StsProvider } from './sts-provider.ts';
/** xAI uses the voice session's event vocabulary and 16 kHz input and 24 kHz output PCM. */
export declare const xaiStsProvider: StsProvider;
