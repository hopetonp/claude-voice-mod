/** Provider wire translation for a recorded STS connection. */
import type { StsChannelSettings } from './sts-channel.ts';
/** JSON messages owned by the provider protocol or the shared voice session. */
export type StsMessage = Readonly<Record<string, unknown>>;
/** Server-owned WebRTC call and its authenticated control connection. */
export interface StsWebRtcCall {
    readonly answer: string;
    readonly connection: StsProviderConnection;
    /** End the remote call; completion includes provider acknowledgement. */
    close(): Promise<void>;
}
/** Provider signaling; browser media and server task ownership remain transport-independent. */
export interface StsWebRtcSignaling {
    /**
     * Create a call from browser SDP.
     * @param settings - resolved session configuration.
     * @param offer - browser SDP.
     * @param signal - startup cancellation.
     * @returns owned call and SDP answer.
     */
    connect(settings: StsChannelSettings, offer: string, signal: AbortSignal): Promise<StsWebRtcCall>;
}
/** Provider-classified inbound event; only sanitized metadata may accompany errors. */
export interface StsInbound {
    readonly kind: 'event' | 'recoverable-error' | 'fatal-error' | 'closed';
    readonly event: StsMessage;
    /** Whether a closure reports failure rather than an ordinary session end. */
    readonly failed?: boolean;
    /** Cumulative provider duration, never an increment. */
    readonly usageSeconds?: number;
    /** Provider reason accompanying confirmed finalization. */
    readonly closeReason?: string;
}
/** One connection's protocol adapter; state must not be shared between sessions. */
export interface StsProviderConnection {
    /** Provider WebSocket endpoint. Credentials must not appear in this URL. */
    readonly url: string;
    /** Authentication headers, excluded from recording and diagnostics. */
    readonly headers: Readonly<Record<string, string>>;
    /** Whether this session accepts non-generating function-result scheduling. */
    readonly supportsToolResponseScheduling?: boolean;
    /**
     * Provider setup message; private resumption handles must be redacted from recording.
     * An already-created, sideband-attached provider session omits it and becomes ready from
     * the provider's native startup event.
     */
    readonly setup?: StsMessage;
    /** Provider-encoded history sent after setup acknowledgment and before initial readiness. */
    readonly startup?: readonly StsMessage[];
    /** Request finalization while retaining the receiver; omission means immediate close. */
    readonly closeEvent?: StsMessage;
    /**
     * Consume a pending renewal only when the provider reports a safe checkpoint.
     * @returns replacement setup, or undefined if subsequent activity made renewal unsafe.
     */
    renew?(): StsMessage | undefined;
    /**
     * Build the setup that continues this conversation on a replacement connection.
     * A dropped socket is not the provider asking to move, so this ignores a pending renewal request
     * and any reply the drop cut off; resumption state alone decides it.
     * @returns replacement setup, or undefined when the provider holds no resumption state.
     */
    resume?(): StsMessage | undefined;
    /**
     * Exclude private transport credentials from a durable event.
     * @param event - incoming or outgoing wire message.
     * @returns the message with transport credentials removed.
     */
    redact?(event: StsMessage): StsMessage;
    /** Classify and sanitize before recording. Omission retains terminal error handling.
     * @param event - parsed wire event.
     * @returns sanitized event and its lifecycle effect.
     */
    classify?(event: StsMessage): StsInbound;
    /** Identify acknowledged commands; audio frames do not have acknowledgments.
     * @param event - encoded outbound message.
     * @returns expected acknowledgment event type, or undefined for transmission-only messages.
     */
    acknowledgment?(event: StsMessage): string | undefined;
    /**
     * Translate a shared session command into ordered provider messages.
     * @param event - session command.
     * @returns provider messages to record and transmit.
     */
    encode(event: StsMessage): readonly StsMessage[];
    /**
     * Translate a recorded provider message into shared session events.
     * @param event - parsed provider message.
     * @returns ordered session events, including session.updated on readiness.
     */
    decode(event: StsMessage): readonly StsMessage[];
}
/** Speech-to-speech protocol implementation consumed by the durable channel. */
export interface StsProvider {
    readonly webrtc?: StsWebRtcSignaling;
    /** Published provider session duration; renewal is scheduled before this limit. */
    readonly maxSessionMs?: number;
    /** Stable provider identifier used in connection records. */
    readonly id: string;
    /** Whether the adapter maps provider-neutral saved speech into structured startup turns. */
    readonly supportsStartupHistory: boolean;
    /** Mono PCM16 rate accepted from the microphone. */
    readonly inputSampleRate: 16000 | 24000;
    /** Mono PCM16 rate produced by the provider. */
    readonly outputSampleRate: 16000 | 24000;
    /** Whether sending tool results starts the next response without an explicit request. */
    readonly toolResponseStartsResponse: boolean;
    /** Whether provider JSON may arrive in binary WebSocket frames. */
    readonly binaryJsonFrames: boolean;
    /**
     * Create an isolated protocol adapter.
     * @param settings - resolved connection settings.
     * @returns connection-local translation and authentication.
     */
    create(settings: StsChannelSettings): StsProviderConnection;
}
