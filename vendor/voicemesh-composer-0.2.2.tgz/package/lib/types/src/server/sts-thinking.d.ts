/**
 * The thinking levels one model offers, and therefore whether the settings screen may offer a
 * choice at all.
 *
 * A control that changes nothing is worse than no control: the user picks a level, hears no
 * difference, and stops trusting the panel. So the model catalog carries the two states beside
 * each model id — named the way the model itself names them — and this module is the one place
 * that decides, using the same predicates the providers use when they build a session.
 *
 * Measured per provider rather than assumed from the name:
 *
 *   * Gemini answers from the model list's thinking dialect. Only `gemini-3.8-live-extended-thinking`
 *     offers a level pair: a thinking level is mandatory there, `low` and `high` are both accepted,
 *     and it is the only Gemini model Composer routes that ships one. `gemini-3.8-live` answers a
 *     level with "Thinking level is not supported for this model", and 3.1 starts with no thinking
 *     field at all. The 2.5 native-audio rows express thinking as a budget rather than a level, so
 *     they offer no pair — and they are not offered to anybody either.
 *   * OpenAI honours a reasoning effort only for the realtime-2 family, which is the same
 *     condition its provider applies before sending one.
 *   * Grok maps the preference onto a reasoning effort for every voice model it serves, and its
 *     two states are `none` and `high`.
 *   * The WebRTC Live transport carries no reasoning setting today, so there is no pair to offer
 *     whatever the model is.
 */
/** The provider names the catalog and the settings screen agree on. */
export type StsModelProvider = 'xai' | 'gemini' | 'openai' | 'openai-live';
/**
 * The two thinking states one model selects between, named as the model names them.
 *
 * The names travel to the settings screen so the panel can label the choice with the model's own
 * vocabulary instead of inventing "on" and "off" for a pair that is really `low` and `high`.
 */
export interface StsThinkingLevels {
    /** The state the preference selects when it is off. */
    readonly off: string;
    /** The state the preference selects when it is on. */
    readonly on: string;
}
/** One discovered model: its id, and the thinking pair it offers or null when it offers none. */
export interface StsModelListing {
    readonly id: string;
    readonly thinking: StsThinkingLevels | null;
}
/** Whether OpenAI applies a reasoning effort to this realtime model. */
export declare function openaiSupportsReasoningEffort(model: string): boolean;
/** The reasoning levels OpenAI selects between for this model, or null when it ignores the flag. */
export declare function openaiThinkingLevels(model: string): StsThinkingLevels | null;
/**
 * The thinking levels this Gemini model offers, or null when its setup ignores the preference.
 *
 * A pair is offered only when the setup genuinely differs between the two states *and* the model
 * names a level: a budget of zero is "off", not the lower of two levels, so the 2.5 rows answer
 * null here even though they can be switched off.
 */
export declare function geminiThinkingLevels(model: string): StsThinkingLevels | null;
/**
 * The thinking levels one provider's model offers.
 * @param provider Provider the model was discovered from.
 * @param model Model identifier as discovered.
 * @returns the two states, or null when the settings screen must not offer a choice.
 */
export declare function stsThinkingLevels(provider: StsModelProvider, model: string): StsThinkingLevels | null;
/** Whether toggling the preference changes how Composer sets this model up. */
export declare function stsModelSupportsThinking(provider: StsModelProvider, model: string): boolean;
