/** OpenAI unified WebRTC signaling and authenticated sideband ownership. */
import type { StsChannelSettings } from './sts-channel.ts';
import type { StsProviderConnection, StsWebRtcCall } from './sts-provider.ts';
/**
 * Exchange an SDP offer without exposing the provider credential in signaling output.
 * @param settings - resolved provider configuration and connection deadline.
 * @param protocol - OpenAI session configuration and event adapter.
 * @param offer - browser SDP offer.
 * @param signal - owning connection cancellation.
 * @returns SDP answer and a sideband connection for the same call.
 */
export declare function openOpenaiWebRtc(settings: StsChannelSettings, protocol: StsProviderConnection, offer: string, signal: AbortSignal): Promise<StsWebRtcCall>;
