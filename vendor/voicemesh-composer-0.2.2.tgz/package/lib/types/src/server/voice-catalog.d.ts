/** Live provider voice catalogs; documentation extraction has no bundled fallback list. */
import { z } from 'zod';
/** Authenticated voice discovery and preview selection. */
export declare const voiceRequest: z.ZodObject<{
    provider: z.ZodEnum<{
        deepgram: "deepgram";
        gemini: "gemini";
        openai: "openai";
        fish: "fish";
        xai: "xai";
        "openai-live": "openai-live";
    }>;
    mode: z.ZodEnum<{
        tts: "tts";
        sts: "sts";
    }>;
    key: z.ZodString;
    model: z.ZodString;
    voice: z.ZodOptional<z.ZodString>;
    language: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** Provider metadata preserved without inferring unsupported demographic attributes. */
export interface CatalogVoice {
    readonly id: string;
    readonly name: string;
    readonly description: string;
    readonly languages: readonly string[];
    readonly gender: string;
    readonly region: string;
}
/** Current discovery result and its provenance. */
export interface VoiceCatalog {
    readonly voices: readonly CatalogVoice[];
    readonly source: 'api' | 'documentation';
    readonly sourceUrl: string;
    readonly fetchedAt: string;
    readonly supplementalSourceUrl?: string;
}
/**
 * Read a bounded remote body.
 * @param response - upstream response.
 * @param maxBytes - body limit.
 * @returns response bytes.
 */
export declare function readVoiceBody(response: Response, maxBytes: number): Promise<Uint8Array>;
/**
 * Extract only the published voice section; changed markup fails without guessing.
 * @param provider - documentation owner.
 * @param body - current official document.
 * @param mode - speech-to-speech or text-to-speech catalog.
 * @param model - selected model, including legacy TTS voice restrictions.
 * @returns voice identifiers and published metadata.
 */
export declare function parseDocumentVoices(provider: 'openai' | 'openai-live' | 'gemini' | 'deepgram', body: string, mode?: 'sts' | 'tts', model?: string): CatalogVoice[];
/**
 * Discover voices from the provider API or its current official documentation.
 * @param input - provider, mode, model, and saved key.
 * @param signal - caller cancellation and deadline.
 * @param maxBytes - maximum fetched document or API body.
 * @returns current catalog with explicit source attribution.
 */
export declare function discoverVoices(input: unknown, signal: AbortSignal, maxBytes: number): Promise<VoiceCatalog>;
