/** Coalesces partial transcripts while withholding prepared replies until finalization. */
export declare class SpeculativeTurn<T> {
    private readonly prepare;
    private readonly cue;
    private latest;
    private listening;
    private active?;
    /** @param prepare - Generate without executing application actions. @param cue - Observe a result while the user is still speaking. */
    constructor(prepare: (text: string, signal: AbortSignal) => Promise<T>, cue: (value: T) => void);
    /** Coalesce changed partials; only one generation runs at a time. @param text - Complete current partial transcript. @param restart - Generate again for the same text, after observed activity changed. */
    update(text: string, restart?: boolean): void;
    private start;
    /** Stop cues and follow-up generation while recognition finalizes. */
    finish(): void;
    /** Consume only an exact final-transcript match. @param text - Authoritative transcript. @param signal - Final response cancellation. @returns Matching draft, or undefined for a fresh request. */
    take(text: string, signal: AbortSignal): Promise<T | undefined> | undefined;
    /** Discard pending replies and prevent late cues after stop or context changes. */
    cancel(): void;
}
