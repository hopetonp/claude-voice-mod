/**
 * Split a reply into small speakable chunks for streaming TTS.
 *
 * Both the on-device Kokoro synthesizer and the cloud Deepgram Aura
 * synthesizer chunk a reply so the first piece starts playing while the rest is
 * still being synthesized. A chunk is normally a sentence; a very long sentence
 * or a run of short ones is broken at a word boundary so no single chunk
 * exceeds {@link MAX_CHUNK_CHARS}.
 *
 * Ported from the Flutter `speech_chunking.dart`. Two rules would be got wrong
 * on a naive reimplementation:
 *
 * - **A period only ends a sentence when followed by whitespace AND the next
 *   word begins uppercase.** Otherwise "U.S.A", "e.g.", "3.14", and "Dr." are
 *   chopped mid-token; the TTS then reads the pieces as separate non-words.
 * - **A chunk reaching the cap is cut at its LAST word boundary**, so a long
 *   sentence still streams in small pieces. A single unbroken token longer
 *   than the cap is force-split at the cap.
 */
/** Split `text` into small speakable chunks (sentence-sized, ≤ MAX_CHUNK_CHARS). */
export declare function splitSentences(text: string): string[];
