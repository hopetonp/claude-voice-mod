/** Async text queue connecting model generation to independent TTS consumption. */
export declare class SpeechTextQueue implements AsyncIterable<string> {
    private values;
    private done;
    private failure;
    private wake;
    push(text: string): void;
    close(): void;
    fail(error: unknown): void;
    [Symbol.asyncIterator](): AsyncGenerator<string>;
}
