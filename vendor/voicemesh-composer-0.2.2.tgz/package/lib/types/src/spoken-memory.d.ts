/**
 * What the assistant has said out loud, kept so a question can be answered
 * from memory instead of making the coding agent redo work.
 *
 * The voice loop previously remembered exactly one string — the last reply —
 * which served only "what did you say?". But many questions are already
 * answered by something said a minute ago: "what was that file again?", "how
 * many were there?". Sending those to the agent costs a full turn and risks it
 * re-running work to reconstruct an answer it already gave.
 *
 * Ported from the Flutter `spoken_history.dart`. This module holds the pure
 * bounds and partition logic. Durable storage is a seam (the `store` callbacks)
 * supplied by the plugin layer, so this stays harness- and store-agnostic.
 */
/** Tracks how many memories to keep and ages them for the router. */
export interface MemoryClock {
    now(): Date;
}
/** One thing the assistant spoke, and when. */
export declare class SpokenEntry {
    readonly text: string;
    constructor(text: string, at?: Date);
    readonly at: Date;
    /** Whole minutes since this was spoken, for the router's staleness judgement. */
    minutesAgo(now?: Date): number;
}
/** The durability seam: the plugin layer provides an implementation. */
export interface SpokenStore {
    append(sessionKey: string, entry: SpokenEntry): void;
    load(sessionKey: string, limit: number): SpokenEntry[];
    forget(sessionKey: string): void;
    forgetAll(): void;
    prune(opts: {
        maxAgeMs: number;
        maxPerSession: number;
    }): void;
}
/** A bounded, newest-last window of spoken replies. */
export declare class SpokenHistory {
    private readonly opts;
    constructor(opts?: {
        maxEntries?: number;
        maxChars?: number;
        onAppend?: (entry: SpokenEntry) => void;
    });
    readonly maxEntries: number;
    readonly maxChars: number;
    readonly onAppend?: (entry: SpokenEntry) => void;
    private readonly _entries;
    get entries(): readonly SpokenEntry[];
    get latest(): SpokenEntry | undefined;
    get isEmpty(): boolean;
    /** Seed from storage without re-notifying onAppend. */
    hydrate(stored: Iterable<SpokenEntry>): void;
    /**
     * Record `text`. Blank text is ignored; an exact repeat of the previous entry
     * is not recorded twice, so replaying a reply must not distort the memory.
     */
    add(text: string): void;
    private trim;
    clear(): void;
    /** Render for the router prompt, newest last, each line tagged with its age. */
    transcript(now?: Date): string;
}
/** Spoken memory partitioned by session. */
export declare class SpokenMemory {
    private readonly opts;
    constructor(opts?: {
        maxSessions?: number;
        maxEntriesPerSession?: number;
        maxCharsPerSession?: number;
        store?: SpokenStore;
    });
    readonly maxSessions: number;
    readonly maxEntriesPerSession: number;
    readonly maxCharsPerSession: number;
    readonly store?: SpokenStore;
    /** Notified whenever something substantive is spoken, on any session. */
    onSpoken?: (sessionKey: string, entry: SpokenEntry) => void;
    /** Insertion-ordered; first key is least recently used. */
    private readonly bySession;
    static readonly kNoSession = "__none__";
    /** The history for `sessionKey`, hydrating from store on first access, marked most recently used. */
    of(sessionKey: string | null | undefined): SpokenHistory;
    private create;
    /** Sessions currently in the working set, least recently used first. */
    get sessions(): Iterable<string>;
    /** Forget one session's memory, in the working set and storage. */
    forget(sessionKey: string): void;
    /** Apply retention to durable storage and drop the working set. */
    prune(opts: {
        maxAgeMs: number;
    }): void;
    /** Forget everything in the working set. Storage untouched. */
    clear(): void;
    /** Forget everything, in the working set and storage. */
    forgetAll(): void;
}
