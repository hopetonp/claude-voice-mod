/**
 * The steer judgement: does an interruption redirect the agent, or not?
 *
 * A barge-in parks whatever the agent was saying. Whether that speech is stale
 * or still wanted is a semantic question — "no, do the other one" redirects,
 * "sorry, that wasn't for you" does not — so it is asked of a model rather than
 * pattern-matched.
 *
 * Ported from the Flutter `steer_judge.dart`. This module holds the pure,
 * transport-free logic: the two tokens, the decision rule (only an explicit
 * STEER redirects; anything else keeps the parked speech), and the system
 * instruction that encodes the tie-break. The model call is a protocol-client
 * concern for the plugin layer, not here.
 */
/** The answer meaning the interruption redirects the agent. */
export declare const STEER_TOKEN = "STEER";
/** The answer meaning the parked speech is still wanted. */
export declare const ASIDE_TOKEN = "ASIDE";
/**
 * Decide whether an LLM answer redirects the agent.
 *
 * Only an explicit STEER redirects; an unparseable or empty answer keeps the
 * parked speech, matching the prompt's tie-break. This is the load-bearing
 * rule: resuming speech the user did not want is recoverable (they simply
 * interrupt again), while dropping speech they did want destroys it with no
 * way to ask for it back.
 */
export declare function steersFromAnswer(answer: string): boolean;
