/** A generation result; cues require a classified intent and never become completed answers. Missing intent suppresses playback. */
export interface ConversationReply {
    text: string;
    cue?: string;
    cueIntent?: 'acknowledgment' | 'encouragement' | 'silence';
}
/** Application transport receives provisional policy only for preparation. */
export interface ConversationRequest {
    text: string;
    history: readonly {
        role: 'user' | 'assistant';
        content: string;
    }[];
    recentCues: readonly string[];
    preparationPrompt?: string;
    /** Observed activity; partial text never establishes a pause. */
    speechState?: 'speaking' | 'paused';
}
/** Injectable generation and playback observers; no credentials or application tools are owned here. */
export interface StreamingConversationOptions {
    request(input: ConversationRequest, emit: (text: string) => void, signal: AbortSignal): Promise<ConversationReply>;
    /** Resolve when playback ends; invoke started only when audio reaches the device. */
    cue(text: string, started: () => void): Promise<void>;
    /** Required for hosts using paused preparation: stop listener audio when observed activity changes. */
    stopCue?(): void;
    observe?(event: 'preparing' | 'cue' | 'reused' | 'generating' | 'cue-suppressed' | 'cue-played'): void;
}
/** One in-memory conversation with exact-transcript draft reuse and bounded context. */
export declare class StreamingConversation {
    private readonly options;
    private history;
    private readonly cues;
    private speechState;
    private readonly draft;
    /** @param options - Model transport and listener playback. */
    constructor(options: StreamingConversationOptions);
    /** @param text - Current cumulative provisional transcript.
     * @param speechState - Activity reported by the host's speech detector, never inferred from text.
     */
    prepare(text: string, speechState?: 'speaking' | 'paused'): void;
    /** Stop cues while authoritative recognition completes. */
    finish(): void;
    /** Discard pending work on mute, interruption, standby or stop. */
    cancel(): void;
    /** Clear conversation context when the application starts a new conversation. */
    reset(): void;
    /** Generate or reuse a reply only after the transcript is authoritative.
     * @param text - Final transcript.
     * @param emit - Receives answer text, never listener cues.
     * @param signal - Final-turn cancellation.
     * @returns Completed spoken answer.
     */
    run(text: string, emit: (text: string) => void, signal: AbortSignal): Promise<string>;
}
