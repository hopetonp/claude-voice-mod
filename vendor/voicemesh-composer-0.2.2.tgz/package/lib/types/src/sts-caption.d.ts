/** Playback-paced captions for voice providers without word timestamps. */
/** Measured audio progress and the estimate used while synthesis is incomplete. */
export interface CaptionPosition {
    playedMs: number;
    durationMs: number;
    complete: boolean;
    charactersPerSecond: number;
}
/**
 * Reveal spoken text using the same timing policy for STS and Pipeline.
 * @param text - Generated speech text.
 * @param position - Output-device progress and synthesis completion.
 * @param previous - Prefix already displayed.
 * @param final - Playback has stopped.
 * @param interrupted - Playback stopped before completion.
 * @returns Monotonic visible prefix length.
 */
export declare function playbackCaptionLength(text: string, position: CaptionPosition, previous: number, final?: boolean, interrupted?: boolean): number;
/**
 * Estimate a whole-word prefix from played audio and the estimated response duration.
 * @param text - generated transcript.
 * @param playedMs - audio already rendered by the output device.
 * @param durationMs - conservative response duration estimate, measured after generation completes.
 * @returns number of UTF-16 code units to reveal; unfinished words remain hidden.
 */
export declare function captionPrefixLength(text: string, playedMs: number, durationMs: number): number;
