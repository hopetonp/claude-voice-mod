/**
 * Prefer whole sentences, then words and graphemes, within a byte limit.
 * @param text - application-supplied text; whitespace and punctuation are preserved.
 * @param maxBytes - integer payload limit of at least four UTF-8 bytes.
 * @returns ordered pieces whose concatenation equals the input; oversized graphemes split at code points.
 */
export declare function segmentText(text: string, maxBytes: number): string[];
