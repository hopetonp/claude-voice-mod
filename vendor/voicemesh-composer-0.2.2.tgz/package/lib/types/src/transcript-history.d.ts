/** Conversation history assembled from display rows without treating pauses as new messages. */
/** One retained speech row or combined history message. */
export interface TranscriptHistoryRow {
    readonly role: 'user' | 'assistant';
    readonly text: string;
}
/** Limits applied to the complete prepared startup history. */
export interface TranscriptHistoryLimits {
    readonly maxBytes: number;
    readonly maxMessages: number;
}
/**
 * Combine adjacent rows from the same speaker without changing their order or text.
 * @param rows - chronological display rows, already selected within the consumer's history budget.
 * @returns independent messages with one newline between combined rows; consumers must budget those separators.
 */
export declare function mergeTranscriptRows(rows: readonly TranscriptHistoryRow[]): TranscriptHistoryRow[];
/**
 * Retain the newest complete speech rows within text and resulting-message limits.
 * @param rows - chronological provider-neutral speech rows.
 * @param limits - UTF-8 text budget and maximum messages after adjacent speakers are combined.
 * @returns chronological independent messages without modifying the input rows.
 */
export declare function prepareTranscriptHistory(rows: readonly TranscriptHistoryRow[], limits: TranscriptHistoryLimits): TranscriptHistoryRow[];
