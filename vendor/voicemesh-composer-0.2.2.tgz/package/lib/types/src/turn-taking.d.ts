/**
 * The turn-taking state machine and the barge-in decision.
 *
 * This is the heart of the voice loop: what state it is in, whether an
 * interruption redirects the agent or merely pauses it, and the discipline that
 * governs the speech queue.
 *
 * Ported from the Flutter `voice_controller.dart`, with the audio/TTS concerns
 * removed so the *decision* logic is pure and testable. The load-bearing rules,
 * carried verbatim:
 *
 * - **A reply never cuts a reply.** Cutting the agent off is the user's
 *   privilege alone; barge-in and stop discard the queue outright.
 * - **A barge-in is a steer, not a cancel.** It parks the queue, and the parked
 *   speech is only dropped if the user's words redirect the agent. A steer
 *   resolves via a judge if available, else the conservative rule.
 * - **The rule is conservative about "not a steer".** Only non-speech and bare
 *   acknowledgments count as *not* a steer — so a genuine redirect is never
 *   mistaken for an aside when no judge is available.
 */
export declare enum VoiceState {
    idle = 0,
    listening = 1,
    transcribing = 2,
    speaking = 3,
    standby = 4
}
/** Whether `utterance` redirects the agent, by the conservative built-in rule. */
export declare function isSteerByRule(utterance: string): boolean;
export type SteerSource = 'rule' | 'judge';
export interface BargeInResolution {
    /** Whether the utterance redirects the agent away from the parked speech. */
    readonly steers: boolean;
    /** Whether the judgement came from the model or the conservative rule. */
    readonly source: SteerSource;
}
/**
 * Resolve a barge-in. Prefers a judge when one is configured; falls back to
 * the rule when it is missing or throws, so a broken endpoint degrades to the
 * old behavior instead of stalling the loop.
 */
export declare function resolveBargeIn(utterance: string, parked: string, judge?: (utterance: string, parked: string) => Promise<boolean> | boolean): Promise<BargeInResolution>;
/** One unit of queued speech. */
export interface QueuedSpeech {
    /** The exact text to speak. */
    readonly text: string;
}
/**
 * The pure turn state: the speech queue and the parked set, and the two
 * transitions that decide barge-in outcomes. Audio playback is not modelled
 * here; this is the decision surface only.
 */
export declare class TurnState {
    private readonly queue;
    private readonly parked;
    private resumingFlag;
    /** Speech waiting to be spoken, oldest first. */
    get queuedSpeech(): readonly QueuedSpeech[];
    /** Whether a reply is on the mouth or queued — the backchannel must stay quiet. */
    get replyBusy(): boolean;
    /** Queue a speech unit at the tail (a reply never cuts a reply). */
    enqueue(text: string): void;
    /** Park the queue on barge-in: the user has the floor. */
    parkQueue(): void;
    /**
     * Resolve parked speech against what the user said. A steer drops it; anything
     * else resumes it, marked as picking up (not starting cold).
     */
    settle(steers: boolean): {
        resumed: boolean;
        dropped: boolean;
    };
    /** Whether the next drained utterance is a resumption after a barge-in. */
    get resuming(): boolean;
    clear(): void;
}
