/**
 * Energy-based voice activity detection over a PCM16 16 kHz mono stream.
 *
 * This is the hands-free trigger: it decides utterance boundaries locally (no
 * push-to-talk) and doubles as the barge-in detector while the agent speaks.
 * A window is "voiced" when its RMS exceeds the mic's noise floor by
 * {@link voiceRatio} (or an absolute {@link rmsMin}).
 *
 * Ported from the Flutter `EnergyVad`. The tuning is not a guess — it is the
 * result of live debugging against a real mic. Two rules are load-bearing and
 * would be got wrong on a naive reimplementation:
 *
 * - **The noise floor tracks only the quiet baseline and holds still during
 *   speech.** Raising it during speech makes the threshold chase the signal
 *   and oscillate voiced/unvoiced on every other window, which starves the
 *   hangover so utterances never end.
 * - **A priming period seeds the floor from ambient noise** so a capture-start
 *   transient or a loud room does not read as speech on the first window.
 */
export type VadEvent = {
    type: 'speechStart';
} | {
    type: 'utteranceEnd';
};
/**
 * The voice-activity-detection contract a voice loop drives. Both the
 * lightweight {@link EnergyVad} and any model-based VAD (for example a browser
 * Silero VAD) implement this, so the loop is VAD-agnostic: which detector runs
 * is a composition choice, not hardcoded, and it does not depend on the STT/TTS
 * provider. A reference (post-AEC) mic signal can be fed to the same interface,
 * so echo cancellation slots in below the VAD without changing the detector.
 */
export interface Vad {
    /** Feed normalized samples (see {@link pcm16ToFloats}) at the configured rate. */
    feed(samples: ArrayLike<number>): void;
    /** Subscribe to `{type:'speechStart'}` / `{type:'utteranceEnd'}` events. Returns a disposer. */
    onEvent(listener: (event: VadEvent) => void): () => void;
    /** Reset internal state without closing. */
    reset(): void;
    /** Stop emitting events. Idempotent. */
    close(): void;
    /** Whether speech is currently in progress. */
    readonly inSpeechNow: boolean;
}
export interface EnergyVadOptions {
    sampleRate?: number;
    windowMs?: number;
    hangoverMs?: number;
    primeMs?: number;
    noiseFloorCap?: number;
    voiceRatio?: number;
    rmsMin?: number;
}
export declare class EnergyVad implements Vad {
    readonly sampleRate: number;
    readonly windowMs: number;
    readonly hangoverMs: number;
    readonly primeMs: number;
    readonly noiseFloorCap: number;
    readonly voiceRatio: number;
    readonly rmsMin: number;
    private readonly windowSamples;
    private readonly window;
    private noiseFloor;
    private inSpeech;
    private silentMs;
    private windowCount;
    private closed;
    private readonly listeners;
    constructor(options?: EnergyVadOptions);
    onEvent(listener: (event: VadEvent) => void): () => void;
    get inSpeechNow(): boolean;
    /** Reset VAD internal state without closing it. */
    reset(): void;
    /** Stop emitting events. Idempotent. */
    close(): void;
    /**
     * Feed normalized samples (see {@link pcm16ToFloats}) at the configured rate.
     */
    feed(samples: ArrayLike<number>): void;
    private processWindow;
}
