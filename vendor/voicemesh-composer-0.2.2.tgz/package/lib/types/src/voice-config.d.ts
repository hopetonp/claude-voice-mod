/**
 * The voice configuration object.
 *
 * In the Flutter app these were scattered (provider IDs, model IDs, engine
 * pickers, thresholds, and toggles). Here they are one plain, serializable
 * `VoiceConfig` — the knobs. The plugin reads it; a future settings UI is just
 * a view that edits it. Nothing here knows about how it is rendered or
 * persisted; it is the data model only.
 *
 * Defaults are taken verbatim from the Flutter app so behaviour is unchanged on
 * first load.
 */
/** The default STT engine (the one the Flutter app defaulted to). */
export declare const DEFAULT_STT_ENGINE = "deepgram-flux";
/** The default TTS engine. */
export declare const DEFAULT_TTS_ENGINE = "aura";
/** Default provider voice/model ids. */
export declare const DEFAULT_DEEPGRAM_VOICE_MODEL = "aura-2-apollo-en";
export declare const DEFAULT_DEEPGRAM_FLUX_VOICE = "flux-haley-en";
export declare const DEFAULT_GROK_VOICE = "eve";
export declare const DEFAULT_REPLY_CONVERTER = "verbatim";
/** A serializable configuration object for the voice layer. */
export interface VoiceConfig {
    /** Whether voice is enabled at all. */
    enabled: boolean;
    /** Speech recognition engine id. */
    sttEngine: string;
    /** Speech synthesis engine id. */
    ttsEngine: string;
    /** Deepgram Aura voice model id. */
    deepgramVoiceModel: string;
    /** Deepgram Flux voice id. */
    deepgramFluxVoice: string;
    /** Grok voice id. */
    grokVoice: string;
    /** Seconds of idle before the loop drops its socket and enters standby. */
    standbySec: number;
    /** Whether background acknowledgments ("mhmm") are enabled. */
    backchannelEnabled: boolean;
    /** Backchannel gain, 0..1 (kept under the user's voice). */
    backchannelVolume: number;
    /** Whether replies are read tersely. */
    terseVoice: boolean;
    /** Reply converter id (e.g. "verbatim"). */
    replyConverter: string;
    /** Whether a conversational model rewrites/answers from memory. */
    conversationalEnabled: boolean;
    /** The conversational model id. */
    conversationalModel: string;
    /** The OpenAI-compatible base URL for the conversational model. */
    conversationalBaseUrl: string;
}
/** The default configuration, matching the Flutter defaults. */
export declare const DEFAULT_VOICE_CONFIG: VoiceConfig;
/**
 * Clamp and fill a partial config to a complete, valid one. Missing keys get
 * defaults; out-of-range values are normalised (volume, standby floor).
 */
export declare function normalizeVoiceConfig(partial?: Partial<VoiceConfig>): VoiceConfig;
/** Merge a patch onto a config, returning a new object. */
export declare function mergeVoiceConfig(config: VoiceConfig, patch: Partial<VoiceConfig>): VoiceConfig;
