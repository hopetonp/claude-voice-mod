/** Shared voice activation, inactivity, elapsed time, and status feedback for both speech modes. */
/** Observable voice session phase. */
export type VoicePhase = 'idle' | 'connecting' | 'listening' | 'preparing' | 'transcribing' | 'speaking' | 'standby' | 'error';
/** Application state projection; no reactive framework is required. */
export interface VoiceLifecycleSink {
    setPhase(phase: VoicePhase): void;
    setError(error: string | null): void;
    setLevel(level: number): void;
    setActiveSeconds(seconds: number): void;
}
/** Optional platform status feedback. */
export interface VoiceStatusSounds {
    play(tone: 'connected' | 'disconnected' | 'standby'): void;
    stop(): void;
}
/** Mode-owned resources and activity checks for one activation. */
export interface VoiceActivationOptions {
    /** Preserve elapsed time when reconnecting from standby. */
    resume?: boolean;
    /** Suppress the ready sound for automatic or manual read-back. */
    silent?: boolean;
    /**
     * Synchronously release local microphone/capture ownership, then optionally return remote
     * provider finalization. Standby publishes after this function returns and never waits for that
     * finalization, so another local capture can safely take ownership without a provider timeout.
     */
    standby(): void | Promise<void>;
    /**
     * Whether this activation refuses an inactivity park right now: audio is in
     * flight (an utterance the microphone is still capturing, or output the
     * listener is still hearing), or the activation is already ending. A mode with
     * audio to protect must implement this; one that omits it parks freely. Turn and
     * job state must never be consulted here — the deadline exists to park while a
     * reply or a job is still running, so only audio and an ending activation hold
     * it back. An explicit user pause ignores this.
     */
    parkBlocked?(): boolean;
    /** Optional playback completion check for background tabs. */
    tick?(): void;
}
/**
 * Create one mode's lifecycle owner; inactive owners cannot change the shared UI.
 * @param store - runtime state rendered by all voice controls.
 * @param settings - current inactivity duration and sound preference.
 * @param sounds - shared plugin-owned status player.
 * @returns activation and shutdown operations; old activations ignore late callbacks.
 */
export declare function createVoiceLifecycle(store: VoiceLifecycleSink, settings: () => {
    voiceStandbySec: number;
    statusSounds: boolean;
}, sounds: VoiceStatusSounds): {
    start(options: VoiceActivationOptions): VoiceActivation;
    stop(): void;
    dispose(): void;
};
/** One activation's UI operations; callbacks become inert after replacement or shutdown. */
export interface VoiceActivation {
    /** Whether inactivity has initiated resource release. */
    readonly parked: boolean;
    /** Publish a processing phase and reevaluate inactivity. @param next - current input/output phase. */
    phase(next: VoicePhase): void;
    /** Mark microphone and provider readiness, start the clock, and play the connection cue once. */
    ready(): void;
    /** Reevaluate the inactivity deadline after input, output, or settings changes. */
    activity(): void;
    /** Freeze time and cancel inactivity while resources are closing. */
    pause(): void;
    /**
     * Park now: release microphone and provider resources and publish standby.
     * The inactivity deadline uses this, and so does an explicit user pause, which
     * forces the park through audio that is still in flight. Parking never cancels
     * the voice session.
     * @param force - Skip the in-flight audio check so a user pause applies at once.
     */
    park(force?: boolean): void;
    /** Publish explicit voice-off once and invalidate this activation. */
    stop(): void;
}
