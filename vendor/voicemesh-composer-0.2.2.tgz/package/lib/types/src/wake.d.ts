/**
 * The wake module's public surface.
 *
 * Everything outside the module reaches it through this file. Nothing inside
 * `src/wake/` imports the pipeline, recognition, synthesis, or a Node built-in,
 * so the module stays portable and independently testable.
 *
 * The module's single responsibility is to turn microphone audio into a wake
 * detection. What happens next — resuming a session, playing a tone, deciding
 * how a trailing request is handled — belongs to the caller.
 */
export type { WakeAudioFormat, WakeBackend, WakeCreationResult, WakeDetection, WakeKeyword, WakeReadiness, WakeSpotter, WakeSpotterCore, WakeSpotterOptions, WakeSpotterResult, WakeTokenizer, WakeUnavailableReason, } from './wake/types.ts';
export type { WakeKeywordProblem } from './wake/keywords.ts';
export { buildKeywordsFile, isThresholdInRange, parseKeywordsFile, renderKeywordLine, renderKeywordsFile, validateKeyword, } from './wake/keywords.ts';
export type { WakeReadinessFacts } from './wake/readiness.ts';
export { evaluateReadiness } from './wake/readiness.ts';
export type { WakeResumeDecision, WakeResumeGate, WakeResumeRefusal } from './wake/session.ts';
export { createWakeResumeGate } from './wake/session.ts';
export type { WakePreroll } from './wake/preroll.ts';
export { WAKE_PREROLL_BYTES, createWakePreroll } from './wake/preroll.ts';
export type { WakeTriggerGuard } from './wake/trigger.ts';
export { createWakeTriggerGuard } from './wake/trigger.ts';
export type { WakeDownDetection, WakeDownFailure, WakeDownFrame, WakeUpFrame, WakeUpFrameUnion, WakeUpPark } from './wake/channel.ts';
export { parseWakeDownFrame, parseWakeUpFrame } from './wake/channel.ts';
export type { WakePath, WakePathDeps, WakeResumeContext } from './wake/path.ts';
export { createWakePath } from './wake/path.ts';
export type { WakeClientPath, WakeClientPathDeps, WakeClientTransport } from './wake/client-path.ts';
export { createWakeClientPath } from './wake/client-path.ts';
export { WAKE_AUDIO_FORMAT, WAKE_SAMPLE_RATE, createWakeSpotter, wrapSpotter } from './wake/spotter.ts';
export type { WakeSocketLike, WakeSocketTransport } from './wake/socket-transport.ts';
export { createWakeSocketTransport } from './wake/socket-transport.ts';
