/**
 * Wake channel frames.
 *
 * The wake path needs its own channel: while the voice is parked the conversation
 * connection is closed by design, and reopening it would resurrect conversation state
 * and invite a double resume. So audio travels one way and detections the other over a
 * connection whose whole vocabulary is this file.
 *
 * Parsing never throws. A malformed frame is ignored rather than allowed to tear down
 * the wake path, because a channel that is only fed by our own host is still a place
 * where a half-written or hostile frame can arrive.
 */
/** Audio on its way to the spotter. */
export interface WakeUpFrame {
    readonly type: 'audio';
    /** Mono PCM16 at 16 kHz. */
    readonly pcm: Uint8Array;
}
/**
 * The client opening a park cycle.
 *
 * The token travels **up** as well as down. Without this the host would have to invent
 * one, and a detection stamped with a host-side token could never match the client's
 * gate — so the exactly-once guarantee would hold only within one side.
 */
export interface WakeUpPark {
    readonly type: 'park';
    /** The park-cycle token the client's gate issued. */
    readonly token: string;
}
/** Anything the client may send. */
export type WakeUpFrameUnion = WakeUpFrame | WakeUpPark;
/** A fired phrase, carrying the park-cycle token that authorises the resume. */
export interface WakeDownDetection {
    readonly type: 'detection';
    /** The park cycle this detection belongs to. */
    readonly token: string;
    /** The phrase that fired, as the spotter reported it. */
    readonly keyword: string;
}
/** A terminal failure, which the caller answers by closing and re-checking readiness. */
export interface WakeDownFailure {
    readonly type: 'failure';
    readonly message: string;
}
/** Anything the client may receive. */
export type WakeDownFrame = WakeDownDetection | WakeDownFailure;
/**
 * Parse a frame the host sent.
 * @param raw - whatever arrived.
 * @returns the frame, or null when it is not one.
 */
export declare function parseWakeDownFrame(raw: unknown): WakeDownFrame | null;
/**
 * Parse a frame the client built before sending.
 * @param raw - whatever is about to be sent.
 * @returns the frame, or null when it is not one.
 */
export declare function parseWakeUpFrame(raw: unknown): WakeUpFrameUnion | null;
