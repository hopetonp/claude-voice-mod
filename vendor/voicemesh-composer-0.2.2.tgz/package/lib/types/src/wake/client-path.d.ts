/**
 * The client-side wake path.
 *
 * While the voice is parked the client owns capture, but **not** the spotter: inference
 * runs in the host (§9, §10). So this shape has no spotter. It retains audio, honours the
 * self-trigger guard, sends audio frames up, and on a detection frame claims the park
 * cycle and hands back the retained window to replay.
 *
 * The order inside `feed` mirrors the host variant: audio is retained *before* the guard
 * decides, because a phrase spoken as the voice stops still belongs to the request that
 * follows. The guard suppresses what the *host* hears, so the voice cannot wake itself.
 */
import type { WakeUpFrameUnion } from './channel.ts';
import type { WakePreroll } from './preroll.ts';
import type { WakeResumeGate } from './session.ts';
import type { WakeTriggerGuard } from './trigger.ts';
/** The channel the client sends on. */
export interface WakeClientTransport {
    /** Send one frame to the host: a park announcement, or audio. */
    send(frame: WakeUpFrameUnion): void;
    /** Release the channel. */
    close(): Promise<void>;
}
/** What the client path needs. */
export interface WakeClientPathDeps {
    readonly transport: WakeClientTransport;
    readonly preroll: WakePreroll;
    readonly gate: WakeResumeGate;
    readonly guard: WakeTriggerGuard;
    /**
     * Called at most once per park cycle, with the phrase that fired and the retained audio
     * to replay into the recognition stream before live frames resume.
     */
    onResume(context: {
        readonly keyword: string;
        readonly replay: Uint8Array;
    }): void;
    /** A terminal condition: the caller closes wake-owned resources and re-checks readiness. */
    onFailure(error: Error): void;
    /** Clock in milliseconds; defaults to `Date.now`. */
    now?(): number;
}
/** The running client-side path. */
export interface WakeClientPath {
    /** Open a park cycle: the caller starts capture. */
    park(): void;
    /** Abandon the cycle without resuming: the caller releases capture. */
    unpark(): void;
    /** Capture produced audio. */
    feed(pcm16: Uint8Array): void;
    /** The voice started speaking. */
    speaking(): void;
    /** The voice stopped speaking. */
    quiet(): void;
    /** A frame arrived from the host. Unrecognised frames are ignored. */
    receive(raw: unknown): void;
    /** Release the channel. */
    close(): Promise<void>;
}
/**
 * Build the client-side wake path.
 * @param deps - transport and the three guards, plus the resume and failure callbacks.
 * @returns the path.
 */
export declare function createWakeClientPath(deps: WakeClientPathDeps): WakeClientPath;
