/**
 * Keywords-file rendering, parsing and validation.
 *
 * sherpa-onnx open-vocabulary keyword spotting takes one keyword per line: the
 * encoded tokens separated by spaces, then an optional `:boost` and an optional
 * `#threshold`. There is no space between a marker and its value.
 *
 *   ▁HE LL O ▁WORLD :1.5 #0.35
 *   ▁HI ▁GO O G LE :1.0 #0.25
 *   ▁HE Y ▁S I RI
 *
 * Tokenisation itself is model-dependent — it needs the model's `tokens.txt`,
 * and for BPE types a `bpe.model` — so it arrives through {@link WakeTokenizer}
 * rather than being implemented here. This file owns the text format and the
 * vocabulary check, not the encoder.
 */
import type { WakeKeyword, WakeTokenizer } from './types.ts';
/** One problem found while validating a keyword. */
export interface WakeKeywordProblem {
    /** The phrase that failed. */
    readonly phrase: string;
    /** A machine-readable category. */
    readonly problem: 'not-tokenizable' | 'unknown-token' | 'no-tokens' | 'threshold-range';
    /** A human-readable explanation, suitable for a settings row. */
    readonly detail: string;
}
/** Render one keyword as a keywords-file line, with no trailing newline. */
export declare function renderKeywordLine(keyword: WakeKeyword): string;
/** Render a complete keywords file. Every line, including the last, ends with a newline. */
export declare function renderKeywordsFile(keywords: readonly WakeKeyword[]): string;
/**
 * Parse a keywords file back into entries.
 *
 * A line beginning with `#` is a comment. Blank lines are skipped. Items are
 * recognized by their leading marker, so token order does not matter for
 * parsing even though rendering always emits tokens, then `:boost`, then
 * `#threshold`, then `@original`.
 */
export declare function parseKeywordsFile(text: string): WakeKeyword[];
/** Whether a trigger threshold is in the range the decoder accepts. */
export declare function isThresholdInRange(value: number): boolean;
/**
 * Validate one phrase against a model's vocabulary.
 *
 * A phrase the model cannot encode is reported rather than silently dropped: an
 * unsupported phrase would otherwise produce a keywords file that simply never
 * fires, which is the hardest kind of failure to notice.
 */
export declare function validateKeyword(phrase: string, tokenizer: WakeTokenizer): {
    readonly keyword: WakeKeyword;
} | {
    readonly problem: WakeKeywordProblem;
};
/**
 * Build a keywords file from phrases, reporting every phrase that failed.
 *
 * The caller writes the returned text; this module performs no I/O.
 */
export declare function buildKeywordsFile(phrases: readonly string[], tokenizer: WakeTokenizer, options?: {
    readonly boost?: number;
    readonly threshold?: number;
}): {
    readonly text: string;
    readonly problems: readonly WakeKeywordProblem[];
};
