/**
 * The wake path.
 *
 * It joins the pieces built separately — the trigger guard, the spotter, the resume
 * gate and the pre-roll window — into the one object the transport drives. Keeping the
 * join here means the transport only has to move audio and call two methods, and the
 * rules stay testable without a microphone or a channel.
 *
 * The order inside `feed` is deliberate: audio is retained *before* the guard decides,
 * because a phrase spoken just before the voice finished speaking still belongs to the
 * request that follows it.
 */
import type { WakePreroll } from './preroll.ts';
import type { WakeResumeGate } from './session.ts';
import type { WakeSpotter } from './types.ts';
import type { WakeTriggerGuard } from './trigger.ts';
/** What a resume is handed. */
export interface WakeResumeContext {
    /** The phrase that fired. */
    readonly keyword: string;
    /** The retained audio to replay into the recognition stream, phrase included. */
    readonly replay: Uint8Array;
}
/** What the path needs. */
export interface WakePathDeps {
    readonly spotter: WakeSpotter;
    readonly preroll: WakePreroll;
    readonly gate: WakeResumeGate;
    readonly guard: WakeTriggerGuard;
    /** Called at most once per park cycle, with the detection that resumed it. */
    onResume(context: WakeResumeContext): void;
    /** Clock in milliseconds; defaults to `Date.now`. */
    now?(): number;
}
/** The running wake path. */
export interface WakePath {
    /** Open a park cycle and start retaining audio. */
    park(): void;
    /** Abandon the cycle without resuming. */
    unpark(): void;
    /** Feed captured audio. */
    feed(pcm16: Uint8Array): void;
    /** The voice started speaking, so the spotter must not act on its own voice. */
    speaking(): void;
    /** The voice stopped speaking. */
    quiet(): void;
    /** Observe a terminal failure. Returns an unsubscribe function. */
    onFailure(handler: (error: Error) => void): () => void;
    /** Close the spotter. */
    close(): Promise<void>;
}
/**
 * Build the wake path.
 * @param deps - the spotter and the three guards, plus the resume callback.
 * @returns the path.
 */
export declare function createWakePath(deps: WakePathDeps): WakePath;
