/** Two seconds of 16 kHz mono PCM16 — long enough for a short request to begin. */
export declare const WAKE_PREROLL_BYTES: number;
/** A rolling window of the most recent audio. */
export interface WakePreroll {
    /** Bytes currently retained. */
    readonly bytes: number;
    /** Maximum bytes retained. */
    readonly limit: number;
    /** Retain a chunk, dropping the oldest audio once the limit is exceeded. */
    push(chunk: Uint8Array): void;
    /** Take the retained window, oldest first, and clear it. */
    take(): Uint8Array;
    /** Drop everything retained. */
    clear(): void;
}
/**
 * Create a pre-roll window.
 * @param limitBytes - maximum bytes retained; defaults to {@link WAKE_PREROLL_BYTES}.
 * @returns the window.
 */
export declare function createWakePreroll(limitBytes?: number): WakePreroll;
