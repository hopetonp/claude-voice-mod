/**
 * Readiness evaluation: what must be true before a spotter can run, in order.
 *
 * The order matters. Model assets are validated *before* the initialization
 * probe, so an incomplete download reports as `model-invalid` rather than as a
 * confusing initialization failure. The probe is last because it is the only
 * check that proves the model is coherent with the installed library: a
 * capability marker can lie, a successful construction cannot.
 *
 * This file interprets facts the host gathered; it performs no I/O.
 */
import type { WakeReadiness } from './types.ts';
/** Facts the host gathers. */
export interface WakeReadinessFacts {
    /** Runtime directory belonging to the running app home. */
    readonly runtimePath: string;
    /** Whether the runtime's worker entry exists. */
    readonly runtimePresent: boolean;
    /** Operations the runtime advertises, or null when it advertises none. */
    readonly runtimeOps: readonly string[] | null;
    /** Capability version, for diagnostics. */
    readonly runtimeCapability: string | null;
    /** The operation this feature needs the runtime to support. */
    readonly requiredOp: string;
    readonly modelId: string;
    readonly modelPath: string;
    /** Whether the model directory and its manifest could be read. */
    readonly modelPresent: boolean;
    /** Whether the manifest parsed and its kind is recognised. */
    readonly modelValid: boolean;
    /** Whether the tokenisation assets this model needs exist and are non-empty. */
    readonly assetsPresent: boolean;
    /**
     * State of the phrase tokeniser. Omitted when the caller does not check it, so the field is
     * additive rather than a new requirement on every caller.
     */
    readonly tokenizer?: 'ready' | 'missing' | 'incomplete';
    /**
     * Result of constructing the spotter once. `not-run` means an earlier check
     * already failed, so probing would have been pointless.
     */
    readonly probe: 'ok' | 'failed' | 'not-run';
    /** Whether the platform can host the spotter at all. */
    readonly platformSupported: boolean;
}
/**
 * Evaluate readiness in the required order.
 *
 * `probe: 'not-run'` alongside otherwise-passing checks reports `init-failed`
 * rather than ready: readiness cannot be asserted when initialization was never
 * confirmed.
 */
export declare function evaluateReadiness(facts: WakeReadinessFacts): WakeReadiness;
