/**
 * The wake resume gate.
 *
 * While the voice is parked, a detection is a request to start the session again. The
 * hard requirement is *exactly once*: the spotter may report several detections, a
 * resume may already be in flight, and a late detection may arrive carrying a token
 * from a park cycle that has already ended.
 *
 * This is deliberately a small state machine with no I/O, so the rule is testable
 * without a microphone, a worker or an app.
 */
/** Why a detection did not resume. */
export type WakeResumeRefusal = 'not-parked' | 'already-resumed' | 'in-flight' | 'stale-token';
/** The gate's answer for one detection. */
export type WakeResumeDecision = {
    readonly resume: true;
} | {
    readonly resume: false;
    readonly reason: WakeResumeRefusal;
};
/** Drives exactly-once resume across park cycles. */
export interface WakeResumeGate {
    /** Whether a park cycle is currently open. */
    readonly parked: boolean;
    /**
     * Open a park cycle and return its token. Detections are matched against it, so a
     * detection from an earlier cycle cannot resume a later one.
     */
    park(): string;
    /** Decide whether a detection carrying `token` resumes. Claims the right when it does. */
    claim(token: string): WakeResumeDecision;
    /**
     * The resume finished. The session is now active, so the gate is no longer parked and
     * further detections are refused until the next park.
     */
    settle(): void;
    /** Abandon the cycle without resuming (mute, stop, or an explicit unpark). */
    release(): void;
}
/**
 * Create a resume gate.
 * @returns a gate that starts unparked.
 */
export declare function createWakeResumeGate(): WakeResumeGate;
