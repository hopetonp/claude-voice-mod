import type { WakeClientTransport } from './client-path.ts';
/** The socket surface this needs. */
export interface WakeSocketLike {
    /** Send one message: a string for control frames, bytes for audio. */
    send(data: string | Uint8Array): void;
    /** Close the socket. */
    close(): void;
}
/** The transport plus the hook the caller drives from its socket's message event. */
export interface WakeSocketTransport {
    /** Hand to `createWakeClientPath` as its transport. */
    readonly transport: WakeClientTransport;
    /** Forward one inbound socket message. Binary messages carry no down frame and are ignored. */
    deliver(data: unknown, isBinary: boolean): void;
}
/**
 * Build a transport over a socket.
 * @param socket - the connected socket.
 * @param onFrame - called with each parsed inbound control frame.
 * @returns the transport and the inbound hook.
 */
export declare function createWakeSocketTransport(socket: WakeSocketLike, onFrame: (raw: unknown) => void): WakeSocketTransport;
