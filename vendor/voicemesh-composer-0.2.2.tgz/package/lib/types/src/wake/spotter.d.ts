/**
 * Spotter construction and the public guarantees around a backend's spotter.
 *
 * Readiness is checked first, so a missing model or runtime is a normal,
 * reportable outcome rather than a throw. The guarantees the public interface
 * promises — ignoring empty chunks, an idempotent `close`, and an unsubscribe
 * that is safe to call twice — are owned here rather than by each backend, so
 * every backend behaves the same.
 */
import type { WakeBackend, WakeCreationResult, WakeSpotter, WakeSpotterCore, WakeSpotterOptions } from './types.ts';
/** The input rate the sherpa-onnx keyword spotter expects. */
export declare const WAKE_SAMPLE_RATE = 16000;
/** The audio contract this module accepts. */
export declare const WAKE_AUDIO_FORMAT: {
    readonly sampleRate: 16000;
    readonly channels: 1;
    readonly encoding: "pcm-s16le";
};
/**
 * Wrap a backend spotter so the public guarantees hold regardless of backend.
 *
 * The wrapper owns three of them: an idempotent `close`, an unsubscribe that is
 * safe to call twice, and the terminal-failure contract — at most one report per
 * subscription, a retained error handed to a subscriber that attaches after the
 * failure, and no report at all for an explicit `close()`.
 *
 * @param core - the backend's raw spotter.
 * @returns the public spotter.
 */
export declare function wrapSpotter(core: WakeSpotterCore): WakeSpotter;
/**
 * Build a spotter through `backend`.
 *
 * Never throws for a missing model, a missing runtime, or a failed
 * initialization: those return `ok: false` with the readiness that explains
 * why, so the caller can offer an install or an update. Throws only on
 * programmer error, such as malformed options.
 *
 * Readiness is a snapshot, so creation is guarded: the files can change between
 * the check and the build, and that race reports `init-failed` instead of
 * escaping as an exception.
 *
 * @param options - model path, keywords file, and optional defaults.
 * @param backend - the injected implementation.
 * @returns the spotter, or the readiness that prevented it.
 */
export declare function createWakeSpotter(options: WakeSpotterOptions, backend: WakeBackend): Promise<WakeCreationResult>;
