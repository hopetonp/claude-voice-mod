/**
 * Self-trigger guard.
 *
 * The spotter hears whatever leaves the speakers, including the assistant's own voice.
 * Without a guard the voice can wake itself by saying the phrase. A detection is
 * therefore ignored while playback is active and for a short cooldown afterwards,
 * because the tail of speech and speaker decay outlive the playback flag.
 *
 * Pure logic with an injected clock reading, so the rule is testable without audio.
 */
/** Decides whether a detection must be ignored. */
export interface WakeTriggerGuard {
    /** Playback started. */
    speaking(): void;
    /** Playback ended at `atMs`. */
    quiet(atMs: number): void;
    /** Whether a detection observed at `atMs` must be ignored. */
    ignore(atMs: number): boolean;
}
/**
 * Create a self-trigger guard.
 * @param cooldownMs - silence required after playback before a detection counts.
 * @returns the guard.
 */
export declare function createWakeTriggerGuard(cooldownMs?: number): WakeTriggerGuard;
