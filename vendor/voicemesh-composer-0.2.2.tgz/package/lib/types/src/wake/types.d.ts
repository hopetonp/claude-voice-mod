/**
 * Types for the isolated wake module.
 *
 * This module turns microphone audio into a wake detection and nothing else: it
 * does not resume sessions, play tones, or decide what a detection means. It
 * carries no recognition, synthesis or pipeline dependency, and it imports no
 * Node built-ins, so the source stays portable.
 */
/** The audio contract for {@link WakeSpotter.feed}. */
export interface WakeAudioFormat {
    /** Input sample rate the spotter requires, in Hz. */
    readonly sampleRate: number;
    /** Always mono. */
    readonly channels: 1;
    /** Signed 16-bit little-endian samples. */
    readonly encoding: 'pcm-s16le';
}
/** One keyword, as it appears in a keywords file. */
export interface WakeKeyword {
    /** The phrase as the user typed it, for display and diagnostics. */
    readonly phrase: string;
    /** Encoded tokens in the model's vocabulary, in order. */
    readonly tokens: readonly string[];
    /** Boosting score (`:x`). Larger makes the keyword easier to trigger. */
    readonly boost?: number;
    /** Trigger threshold (`#x`), 0..1. Lower makes the keyword easier to trigger. */
    readonly threshold?: number;
    /**
     * The original phrase carried as an `@` item. Required by the pinyin token
     * types, where the phrase cannot contain spaces.
     */
    readonly original?: string;
}
/** Why a spotter cannot run. Each reason maps to a different user action. */
export type WakeUnavailableReason = 'model-missing' | 'model-invalid' | 'runtime-missing' | 'runtime-outdated' | 'tokenizer-missing' | 'tokenizer-incomplete' | 'init-failed' | 'unsupported-platform';
/** What readiness examined, and what it concluded. */
export interface WakeReadiness {
    readonly ready: boolean;
    readonly reason: WakeUnavailableReason | null;
    /** The model this check was scoped to. */
    readonly modelId: string;
    readonly modelPath: string;
    /** The runtime directory belonging to the running app home. */
    readonly runtimePath: string;
    /** Capability version observed on the runtime, or null when there is none. */
    readonly runtimeCapability: string | null;
}
/** One detection. */
export interface WakeDetection {
    /** The keyword that fired, as the spotter reported it. */
    readonly keyword: string;
    /**
     * Start of the decoded segment, in seconds, as the spotter reported it.
     * This is the segment start, not necessarily the phrase onset: the backend's
     * per-token timestamps are the finer signal.
     */
    readonly startTime: number;
    /** Decoded token sequence, when the backend reports one. */
    readonly tokens?: readonly string[];
}
/** What the caller supplies to build a spotter. */
export interface WakeSpotterOptions {
    /** Absolute path to the installed keyword model directory. */
    readonly modelPath: string;
    /** Absolute path to a keywords file the caller has already written. */
    readonly keywordsFile: string;
    /** Default trigger threshold for keywords that do not carry their own. */
    readonly threshold?: number;
    /** Default boosting score for keywords that do not carry their own. */
    readonly score?: number;
}
/** A running spotter. */
export interface WakeSpotter {
    readonly format: WakeAudioFormat;
    /**
     * Feed one chunk of mono pcm-s16le audio at {@link WakeAudioFormat.sampleRate}.
     * Empty chunks are ignored rather than forwarded.
     */
    feed(pcm16: Uint8Array): void;
    /** Observe detections. Returns an unsubscribe function. */
    onDetect(handler: (detection: WakeDetection) => void): () => void;
    /**
     * Observe a terminal backend failure. Returns an unsubscribe function.
     *
     * Delivery semantics are owned by the wrapper: at most one report per
     * subscription, a subscriber attached after the failure still receives the
     * retained error, and an explicit `close()` never reports one.
     */
    onError(handler: (error: Error) => void): () => void;
    /** Idempotent. Safe to call more than once. */
    close(): Promise<void>;
}
/** The backend's raw spotter. The module wraps it to own the public guarantees. */
export interface WakeSpotterCore {
    /** Feed audio. The backend may throw; the wrapper does not swallow it. */
    feed(pcm16: Uint8Array): void;
    /** Observe raw detections. */
    onDetect(handler: (detection: WakeDetection) => void): () => void;
    /** Observe a terminal backend failure. The wrapper owns delivery semantics. */
    onError(handler: (error: Error) => void): () => void;
    /** Release native resources. The wrapper guarantees this runs at most once. */
    dispose(): Promise<void>;
}
/**
 * The injectable backend seam, so the module is testable without native code
 * and the host can supply the sherpa-onnx implementation.
 */
export interface WakeBackend {
    /** Never throws for absent assets; reports through the reason union. */
    readiness(options: WakeSpotterOptions): Promise<WakeReadiness>;
    /** Called only when `readiness` reported ready. */
    create(options: WakeSpotterOptions): WakeSpotterCore;
}
/**
 * Turns a phrase into model tokens.
 *
 * Tokenisation is model-dependent — it needs the model's `tokens.txt`, and for
 * BPE types a `bpe.model` — so it is injected rather than implemented here.
 */
export interface WakeTokenizer {
    /** The vocabulary this tokenizer knows, for validation and diagnostics. */
    readonly vocabulary: ReadonlySet<string>;
    /** Tokens for `phrase`, or null when the phrase cannot be encoded. */
    tokenize(phrase: string): readonly string[] | null;
}
/** The result of building a spotter. */
export type WakeCreationResult = {
    readonly ok: true;
    readonly spotter: WakeSpotter;
} | {
    readonly ok: false;
    readonly readiness: WakeReadiness;
};
/** @deprecated Use {@link WakeCreationResult}. */
export type WakeSpotterResult = WakeCreationResult;
