import type { ReactElement } from 'react'

export interface VoicePreferences {
  provider: string
  model: string
  voice: string
  configured: boolean
  voiceStandbySec: number
  statusSounds: boolean
  assistantOrbEnabled: boolean
  responseDetail: 'concise' | 'detailed'
  progressMode: 'outcome' | 'milestones'
  backchannelEnabled: boolean
  endConversationEnabled: boolean
}

export interface VoiceSelection {
  readonly provider: 'xai' | 'deepgram' | 'openai' | 'openai-live' | 'gemini' | 'kokoro' | 'fish'
  readonly mode: 'sts' | 'tts'
  readonly model: string
  readonly language?: string
}

export interface VoiceCatalog {
  readonly voices: readonly {
    readonly id: string
    readonly name: string
    readonly description: string
    readonly languages: readonly string[]
    readonly gender: string
    readonly region: string
  }[]
  readonly source: 'api' | 'documentation'
  readonly sourceUrl: string
  readonly fetchedAt: string
  readonly supplementalSourceUrl?: string
  readonly filterLanguage?: string
}

export interface VoiceSample { readonly audio: string; readonly sampleRate: number }

/** The harness owns credentials and persistence. Saved keys are never returned to the editor. */
export interface VoiceSettingsBackend {
  load(): Promise<VoicePreferences>
  loadDisplay?(): Promise<boolean>
  saveDisplay?(chatBubbles: boolean): Promise<boolean>
  selectProvider(provider: string): Promise<VoicePreferences>
  saveCredential(key: string): Promise<VoicePreferences>
  saveSelection(model: string, voice: string): Promise<VoicePreferences>
  saveStandby(seconds: number): Promise<VoicePreferences>
  saveOptions(options: Partial<Pick<VoicePreferences, 'statusSounds' | 'assistantOrbEnabled' | 'responseDetail' | 'progressMode' | 'backchannelEnabled' | 'endConversationEnabled'>>): Promise<VoicePreferences>
  listModels(signal: AbortSignal): Promise<string[]>
  listVoices(selection: VoiceSelection, signal: AbortSignal): Promise<VoiceCatalog>
  previewVoice(selection: VoiceSelection, voice: string, signal: AbortSignal,
    onAudio: (sample: VoiceSample) => void): Promise<void>
  probeConnection(): Promise<boolean>
  probeAudioTools(): Promise<boolean>
}

export function VoiceSettingsEditor(props: {
  backend: VoiceSettingsBackend
  title?: string
  providers?: Record<string, string>
}): ReactElement
