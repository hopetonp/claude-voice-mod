# VoiceMesh settings editor

Optional React UI for VoiceMesh provider and voice setup. It is packaged separately from the Composer voice runtime. A harness supplies a `VoiceSettingsBackend` that saves preferences and credentials, fetches Composer's model and voice catalogs, and runs previews and diagnostics. Saved credentials are represented only by `configured`; the editor never reads a stored key.

Import `VoiceSettingsEditor` and the package stylesheet. The `title` and `providers` props let each harness name the editor and advertise its supported providers. `loadDisplay` and `saveDisplay` are optional harness-specific display settings.

The package does not choose a desktop window technology. A harness may embed the editor in its own web UI or open the built page in a web-capable desktop window.

Set `voiceSelector="dropdown"` for a compact native voice dropdown with a preview button. The default, `"detailed"`, keeps the voice browser and preview dialog. Both versions use the same `VoiceSettingsBackend` catalog, preview, and save methods; the harness still owns credentials and persistence.
