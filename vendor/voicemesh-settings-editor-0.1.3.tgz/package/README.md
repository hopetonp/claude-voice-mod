# VoiceMesh settings editor

Optional React UI for VoiceMesh provider and voice setup. It is packaged separately from the Composer voice runtime. A harness supplies a `VoiceSettingsBackend` that saves preferences and credentials, fetches Composer's model and voice catalogs, and runs previews and diagnostics. Saved credentials are represented only by `configured`; the editor never reads a stored key.

Import `VoiceSettingsEditor` and the package stylesheet. The `title` and `providers` props let each harness name the editor and advertise its supported providers. `loadDisplay` and `saveDisplay` are optional harness-specific display settings.

Pass the host's display locale through `locale` (for example, `en-US`). All editor interface copy, including English, resolves through Composer's translation catalog. English is the only catalog shipped so far; unsupported locales currently display English. Provider names, model identifiers, voice names, and service error messages come from their data sources and are not translated by the editor.

The package does not choose a desktop window technology. A harness may embed the editor in its own web UI or open the built page in a web-capable desktop window.

Set `voiceSelector="dropdown"` for a compact native voice dropdown with a preview button. The default, `"detailed"`, keeps the voice browser and preview dialog. Both versions use the same `VoiceSettingsBackend` catalog, preview, and save methods; the harness still owns credentials and persistence.

The editor can show DeepSeek-style pipeline settings when a backend supplies `selectVoiceMode`, `savePipeline`, and `listPipelineOptions`. The pipeline form separates recognition, synthesis, conversation, and speech detection. The backend must connect those saved choices to a working Composer pipeline before exposing this mode. Merely implementing the editor methods does not start a pipeline.
