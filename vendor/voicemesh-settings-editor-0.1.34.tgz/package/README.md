# VoiceMesh settings editor

Optional React UI for VoiceMesh provider and voice setup. It is packaged separately from the Composer voice runtime. A harness supplies a `VoiceSettingsBackend` that saves preferences and credentials, fetches Composer's model and voice catalogs, and runs previews and diagnostics. Saved credentials are represented only by `configured`; the editor never reads a stored key.

Import `VoiceSettingsEditor` and the package stylesheet. The `title` and `providers` props let each harness name the editor and advertise its supported providers. `loadDisplay` and `saveDisplay` are optional harness-specific display settings.

Pass the host's display locale through `locale` (for example, `en-US`). All editor interface copy, including English, resolves through Composer's translation catalog. The package ships catalogs for Claude's 35 current display-language choices; unsupported locales display English. Provider names, model identifiers, voice names, and service error messages come from their data sources and are not translated by the editor.

### Generate display translations

The development-only generator reads the English catalog in `src/messages.ts` and writes saved translations to `src/generated-catalogs.json`. It never runs when users open settings. Claude's 35 current display-language choices are listed in `scripts/claude-locales.mjs`; the English choice uses the source catalog, so `--all` generates 34 translations.

1. Set `GEMINI_API_KEY` in the development environment to a Gemini API key with access to Gemini 3.8 Flash. Do not commit the key.
2. Preview the work with `npm run translations:generate -- --all --dry-run`.
3. Generate with `npm run translations:generate -- --all`, or pass a specific Claude locale such as `zh-Hant`.
4. Review the saved wording and check the full editor in each language before publishing. Build with `npm run build` afterward.

The generator updates only entries whose English source changed or whose translation is missing. It checks that each translated string retains its interpolation placeholders. A failed locale leaves previously completed locales saved and can be retried. The editor falls back to English for a missing or stale entry. Translation generation uses Gemini during development only; opening settings never calls the model.

The package does not choose a desktop window technology. A harness may embed the editor in its own web UI or open the built page in a web-capable desktop window.

For a complete reusable settings layout, render `VoiceSettingsShell` with the same backend. It supplies the sidebar, section headings, controls, and optional close button. Pass `locale`, an optional `hostName`, and an `onClose` callback if the window has a close action. Harnesses can continue using `VoiceSettingsEditor` alone. The shell's styling ships in the package stylesheet.

Set `voiceSelector="dropdown"` for a compact native voice dropdown with a preview button. The default, `"detailed"`, keeps the voice browser and preview dialog. Both versions use the same `VoiceSettingsBackend` catalog, preview, and save methods; the harness still owns credentials and persistence.

The editor can show DeepSeek-style pipeline settings when a backend supplies `selectVoiceMode`, `savePipeline`, and `listPipelineOptions`. The pipeline form separates recognition, synthesis, conversation, and speech detection. The backend must connect those saved choices to a working Composer pipeline before exposing this mode. Merely implementing the editor methods does not start a pipeline.
