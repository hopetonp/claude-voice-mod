import type { ReactElement, ReactNode } from 'react'

export interface VoicePreferences {
  voiceMode: 'pipeline' | 'sts'
  pipeline: PipelinePreferences
  classifier?: ClassifierPreferences
  provider: string
  model: string
  voice: string
  configured: boolean
  voiceStandbySec: number
  statusSounds: boolean
  assistantOrbEnabled: boolean
  responseDetail: 'concise' | 'detailed'
  progressMode: 'outcome' | 'milestones'
  plainLanguageSummaries: boolean
  backchannelEnabled: boolean
  endConversationEnabled: boolean
}

export interface PipelinePreferences {
  sttEngine: string
  sttModel: string
  ttsEngine: string
  ttsModel: string
  ttsVoice: string
  conversationalProvider: string
  conversationalModel: string
  conversationalBaseUrl: string
  vadSilenceSec: number
}

export interface ClassifierPreferences {
  enabled: boolean
  provider: string
  model: string
}

export interface PipelineOption { id: string; label: string }
export type PipelineCatalogKind = 'stt-engine' | 'stt-model' | 'tts-engine' | 'tts-model' | 'tts-voice' | 'conversation-provider' | 'conversation-model'

export interface VoiceSelection {
  readonly provider: 'xai' | 'deepgram' | 'openai' | 'openai-live' | 'gemini' | 'kokoro' | 'fish'
  readonly mode: 'sts' | 'tts'
  readonly model: string
  readonly language?: string
}

export interface VoiceCatalog {
  readonly voices: readonly {
    readonly id: string
    readonly name: string
    readonly description: string
    readonly languages: readonly string[]
    readonly gender: string
    readonly region: string
  }[]
  readonly source: 'api' | 'documentation'
  readonly sourceUrl: string
  readonly fetchedAt: string
  readonly supplementalSourceUrl?: string
  readonly filterLanguage?: string
}

export interface VoiceSample { readonly audio: string; readonly sampleRate: number }

/** The harness owns credentials and persistence. Saved keys are never returned to the editor. */
export interface VoiceSettingsBackend {
  load(): Promise<VoicePreferences>
  loadDisplay?(): Promise<boolean>
  saveDisplay?(chatBubbles: boolean): Promise<boolean>
  selectProvider(provider: string): Promise<VoicePreferences>
  selectVoiceMode?(mode: 'pipeline' | 'sts'): Promise<VoicePreferences>
  savePipeline?(changes: Partial<PipelinePreferences>): Promise<VoicePreferences>
  saveClassifier?(changes: Partial<ClassifierPreferences>): Promise<VoicePreferences>
  saveClassifierCredential?(provider: string, key: string): Promise<void>
  classifierCredentialStatus?(provider: string): Promise<boolean>
  listPipelineOptions?(kind: PipelineCatalogKind, selection: PipelinePreferences, signal: AbortSignal): Promise<PipelineOption[]>
  savePipelineCredential?(provider: string, key: string): Promise<VoicePreferences>
  pipelineCredentialStatus?(provider: string): Promise<boolean>
  saveCredential(key: string): Promise<VoicePreferences>
  saveSelection(model: string, voice: string): Promise<VoicePreferences>
  saveStandby(seconds: number): Promise<VoicePreferences>
  saveOptions(options: Partial<Pick<VoicePreferences, 'statusSounds' | 'assistantOrbEnabled' | 'responseDetail' | 'progressMode' | 'plainLanguageSummaries' | 'backchannelEnabled' | 'endConversationEnabled'>>): Promise<VoicePreferences>
  listModels(signal: AbortSignal): Promise<string[]>
  listVoices(selection: VoiceSelection, signal: AbortSignal): Promise<VoiceCatalog>
  previewVoice(selection: VoiceSelection, voice: string, signal: AbortSignal,
    onAudio: (sample: VoiceSample) => void, sampleText?: string): Promise<void>
  probeConnection(): Promise<boolean>
  probeAudioTools(): Promise<boolean>
}

export function VoiceSettingsEditor(props: {
  backend: VoiceSettingsBackend
  title?: string
  providers?: Record<string, string>
  voiceSelector?: 'detailed' | 'dropdown'
  /** Host display locale, such as en-US. Unknown locales use English. */
  locale?: string
  activeSection?: 'provider' | 'conversation' | 'display'
  footerRight?: ReactNode
}): ReactElement

/** Translate shared editor and optional host shell labels with the same catalog. */
export function createTranslator(locale?: string): (key: string, values?: Record<string, string | number>) => string

/** Optional complete settings layout; hosts can continue using VoiceSettingsEditor directly. */
export function VoiceSettingsShell(props: {
  backend: VoiceSettingsBackend
  locale?: string
  hostName?: string
  providers?: Record<string, string>
  voiceSelector?: 'detailed' | 'dropdown'
  onClose?: () => void
  theme?: 'light' | 'dark'
}): ReactElement

export function VoiceDropdown(props: {
  selection: VoiceSelection
  selectedVoice: string
  enabled: boolean
  busy: boolean
  listVoices: VoiceSettingsBackend['listVoices']
  previewVoice: VoiceSettingsBackend['previewVoice']
  onSelect: (voice: string) => void
}): ReactElement
